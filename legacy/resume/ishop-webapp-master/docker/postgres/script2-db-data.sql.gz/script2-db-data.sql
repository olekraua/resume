INSERT INTO category (id, "name", url, product_count)
VALUES (1, 'E-book', '/e-book', 98)
     , (2, 'Mp3-player', '/mp3-player', 83)
     , (3, 'Notebook', '/notebook', 138)
     , (4, 'Phone', '/phone', 134)
     , (5, 'Smartphone', '/smartphone', 223)
     , (6, 'Smartwatch', '/smartwatch', 57)
     , (7, 'Tablet', '/tablet', 176);
INSERT INTO public.producer (id, "name", product_count)
VALUES (1, 'Dell', 77)
     , (2, 'FiiO', 10)
     , (3, 'HP', 26)
     , (4, 'Gigabyte', 23)
     , (5, 'Transcend', 9)
     , (6, 'Jeka', 23)
     , (7, 'Fly', 12)
     , (8, 'Sony', 43)
     , (9, 'Lenovo', 72)
     , (10, 'Prestigio', 67)
     , (11, 'AirOn', 26)
     , (12, 'EvroMedia', 32)
     , (13, 'Asus', 35)
     , (14, 'Acer', 14)
     , (15, 'Apple', 87)
     , (16, 'FixiTime', 7)
     , (17, 'PocketBook', 37)
     , (18, 'Philips', 30)
     , (19, 'HTC', 37)
     , (20, 'AirBook', 11)
     , (21, 'LG', 66)
     , (22, 'Samsung', 88)
     , (23, 'Amazon', 26)
     , (24, 'Huawei', 14)
     , (25, 'Nokia', 37);
INSERT INTO product (id, "name", description, image_link, price, id_category, id_producer)
VALUES (278009, 'Asus AB6831915', 'Monitor 7" / RAM 2 GB / HDD 610 GB / Blue / Weight 300 g / Bluetooth / GPS / 3G',
        '/media/7461626c6574.jpg', 1930.00, 7, 13)
     , (278015, 'Apple SS37207', 'Memory 16 Gb / Weight 23 g / Blue / MP3 / Bluetooth / FM receiver / WMA / WAV',
        '/media/6d70332d706c61796572.jpg', 1970.00, 2, 15)
     , (278018, 'EvroMedia SI7719',
        'Monitor diagonal 10" / Matrix type: E lnk Pearl / Resolution: 1600x1200 / Memory 4 GB / Weight 185 g',
        '/media/652d626f6f6b.jpg', 1990.00, 1, 12)
     , (278024, 'Philips VL8750267',
        'Monitor diagonal 2.0" / Camera: 1.8Mp / RAM 32 Mb / 1000 mA/h / Orange / Weight 340 g / Dictophone / Bluetooth / USB / SD',
        '/media/70686f6e65.jpg', 740.00, 4, 18)
     , (278028, 'Dell VBG9533',
        'Monitor 11" / Intel Core I7 (2.8 GHz) / RAM 13 GB / HDD 300 GB / Weight 3.2 kg / Webcam / WiFi / Bluetooth / Intel HD Graphics / USB',
        '/media/6e6f7465626f6f6b.jpg', 870.00, 3, 1)
     , (278032, 'Acer TJD90636550',
        'Monitor 13" / Intel Core I5 (2.4 GHz) / RAM 3 GB / HDD 570 GB / Weight 6.0 kg / LAN / DVD+/-RW / HDMI',
        '/media/6e6f7465626f6f6b.jpg', 2340.00, 3, 14)
     , (278039, 'Amazon LM7023266',
        'Monitor diagonal 10" / Matrix type: E lnk / Resolution: 1200x800 / Memory 12 GB / Weight 165 g',
        '/media/652d626f6f6b.jpg', 790.00, 1, 23)
     , (278041, 'LG GM7723405',
        'Monitor diagonal 2.4" / Camera: 2.2Mp / RAM 48 Mb / 2000 mA/h / Silver / Weight 340 g / 2 Sim cards / USB / SD / Dictophone',
        '/media/70686f6e65.jpg', 1860.00, 4, 21)
     , (278045, 'Prestigio MUL06280',
        'Monitor diagonal 4.4" / Camera: 3.0Mp / RAM: 4 Gb / White / 1000 mA/h / Weight 800 g / WiFi / USB / Bluetooth / FM receiver / 3G / 2 Sim cards / GPS',
        '/media/736d61727470686f6e65.jpg', 700.00, 5, 10)
     , (278048, 'Apple NC1230587',
        'Monitor diagonal 1.1" / RAM: 256 Mb / Blue / 1500 mA/h / Weight 100 g / Bluetooth / WiFi / Dictophone',
        '/media/736d6172747761746368.jpg', 2450.00, 6, 15)
     , (278051, 'Apple MIS1799120',
        'Monitor diagonal 6.0" / Camera: 4.0Mp / RAM: 1 Gb / Silver / 2000 mA/h / Weight 600 g / 2 Sim cards / WiFi / FM receiver / 3G / Dictophone / Bluetooth / GPS',
        '/media/736d61727470686f6e65.jpg', 570.00, 5, 15)
     , (278055, 'Samsung QQ3586',
        'Monitor diagonal 1.8" / Camera: 2.2Mp / RAM 32 Mb / 1300 mA/h / Blue / Weight 400 g / SD / Dictophone / Bluetooth',
        '/media/70686f6e65.jpg', 120.00, 4, 22)
     , (278060, 'Prestigio PKF3053144',
        'Monitor diagonal 4.4" / Camera: 3.0Mp / RAM: 1 Gb / Black / 1000 mA/h / Weight 680 g / GPS / 2 Sim cards / USB / Bluetooth / WiFi / Dictophone',
        '/media/736d61727470686f6e65.jpg', 1260.00, 5, 10)
     , (278062, 'Apple OIO57462',
        'Memory 16 Gb / Weight 59 g / Blue / MP3 / AVI / FM receiver / WAV / Dictophone / WMA / MPEG-4 / USB / SD slot / OGG',
        '/media/6d70332d706c61796572.jpg', 80.00, 2, 15)
     , (278068, 'Philips GLN55401',
        'Monitor diagonal 1.8" / Camera: 2.6Mp / RAM 16 Mb / 1400 mA/h / White / Weight 100 g / Bluetooth / Dictophone / 2 Sim cards / SD',
        '/media/70686f6e65.jpg', 1560.00, 4, 18)
     , (278069, 'Lenovo NJ28222002',
        'Monitor 10" / RAM 3 GB / HDD 680 GB / Blue / Weight 220 g / Webcam / USB / HDMI / GPS / WiFi',
        '/media/7461626c6574.jpg', 1300.00, 7, 9)
     , (278070, 'Prestigio JNH06915',
        'Monitor 10" / RAM 1 GB / HDD 190 GB / White / Weight 100 g / Webcam / HDMI / Bluetooth',
        '/media/7461626c6574.jpg', 810.00, 7, 10)
     , (278071, 'Sony PE046015',
        'Monitor 8" / RAM 2 GB / HDD 140 GB / Blue / Weight 100 g / Webcam / GPS / USB / Bluetooth / HDMI',
        '/media/7461626c6574.jpg', 1240.00, 7, 8)
     , (278081, 'Sony PEU2182', 'Memory 16 Gb / Weight 80 g / Black / MP3 / AMV / AVI / WAV / FM receiver / Bluetooth',
        '/media/6d70332d706c61796572.jpg', 420.00, 2, 8)
     , (278090, 'Lenovo AF390993', 'Monitor 10" / RAM 2 GB / HDD 130 GB / White / Weight 100 g / 3G / USB / WiFi',
        '/media/7461626c6574.jpg', 2180.00, 7, 9)
     , (278100, 'Lenovo NR73839479', 'Monitor 9" / RAM 3 GB / HDD 200 GB / White / Weight 100 g / USB / Webcam / GPS',
        '/media/7461626c6574.jpg', 1560.00, 7, 9)
     , (278106, 'Samsung VK01155',
        'Monitor diagonal 3.2" / Camera: 3.2Mp / RAM: 1 Gb / Orange / 1200 mA/h / Weight 800 g / FM receiver / WiFi / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 920.00, 5, 22)
     , (278110, 'Prestigio BHU07339777',
        'Monitor diagonal 2.6" / Camera: 2.2Mp / RAM 32 Mb / 1900 mA/h / Silver / Weight 160 g / 2 Sim cards / Dictophone / SD / Bluetooth',
        '/media/70686f6e65.jpg', 1570.00, 4, 10)
     , (278119, 'Lenovo KFD7467',
        'Monitor diagonal 6.0" / Camera: 2.2Mp / RAM: 4 Gb / White / 1400 mA/h / Weight 560 g / 3G / USB / WiFi',
        '/media/736d61727470686f6e65.jpg', 2290.00, 5, 9)
     , (278125, 'Philips AP4810118',
        'Monitor diagonal 1.8" / Camera: 1Mp / RAM 48 Mb / 1600 mA/h / White / Weight 160 g / USB / 2 Sim cards / Dictophone / SD',
        '/media/70686f6e65.jpg', 2860.00, 4, 18)
     , (278131, 'Amazon VBL1440300',
        'Monitor diagonal 10" / Matrix type: E lnk Pearl / Resolution: 1024x758 / Memory 6 GB / Weight 200 g',
        '/media/652d626f6f6b.jpg', 660.00, 1, 23)
     , (278141, 'Samsung MUO5989019',
        'Monitor diagonal 3.0" / Camera: 1Mp / RAM 32 Mb / 1400 mA/h / Black / Weight 160 g / Dictophone / 2 Sim cards / Bluetooth',
        '/media/70686f6e65.jpg', 1710.00, 4, 22)
     , (278149, 'Asus IF5374',
        'Monitor 14" / Intel Core I7 (3.0 GHz) / RAM 6 GB / HDD 590 GB / Weight 2.4 kg / HDMI / Bluetooth / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 1720.00, 3, 13)
     , (278153, 'Jeka HO63140', 'Memory 12 Gb / Weight 41 g / Orange / MP3 / WMA / Bluetooth / Dictophone / OGG',
        '/media/6d70332d706c61796572.jpg', 690.00, 2, 6)
     , (278156, 'Lenovo MA4750548',
        'Monitor diagonal 5.0" / Camera: 3.0Mp / RAM: 2 Gb / Blue / 1900 mA/h / Weight 600 g / Bluetooth / USB / FM receiver',
        '/media/736d61727470686f6e65.jpg', 360.00, 5, 9)
     , (278157, 'LG OA63704678',
        'Monitor diagonal 5.0" / Camera: 2.2Mp / RAM: 512 Mb / Blue / 1300 mA/h / Weight 520 g / Dictophone / 3G / GPS / FM receiver / WiFi',
        '/media/736d61727470686f6e65.jpg', 770.00, 5, 21)
     , (278165, 'Apple QKB0572308',
        'Monitor 23" / Intel Core I3 (1.6 GHz) / RAM 14 GB / HDD 710 GB / Weight 5.8 kg / HDMI / DVD+/-RW / LAN / Intel HD Graphics / Bluetooth / WiFi / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 660.00, 3, 15)
     , (278167, 'Amazon JEA1185',
        'Monitor diagonal 12" / Matrix type: E lnk / Resolution: 1024x758 / Memory 11 GB / Weight 180 g',
        '/media/652d626f6f6b.jpg', 2660.00, 1, 23)
     , (278173, 'Asus NDA534077',
        'Monitor 16" / Intel Core I7 (2.8 GHz) / RAM 4 GB / HDD 530 GB / Weight 2.4 kg / Intel HD Graphics / HDMI / WiFi',
        '/media/6e6f7465626f6f6b.jpg', 1650.00, 3, 13)
     , (278179, 'Gigabyte IK06812',
        'Monitor diagonal 1.8" / Camera: 1Mp / RAM 64 Mb / 1700 mA/h / Blue / Weight 180 g / Bluetooth / SD / USB',
        '/media/70686f6e65.jpg', 1340.00, 4, 4)
     , (278184, 'Prestigio ETC0651',
        'Monitor diagonal 5.0" / Camera: 4.0Mp / RAM: 4 Gb / Silver / 1100 mA/h / Weight 640 g / 3G / GPS / Dictophone',
        '/media/736d61727470686f6e65.jpg', 330.00, 5, 10)
     , (278193, 'Amazon BEB889531',
        'Monitor diagonal 8" / Matrix type: E lnk Carta / Resolution: 1200x800 / Memory 11 GB / Weight 200 g',
        '/media/652d626f6f6b.jpg', 100.00, 1, 23)
     , (278198, 'Philips IHI825869',
        'Monitor diagonal 2.2" / Camera: 1Mp / RAM 48 Mb / 1200 mA/h / Black / Weight 180 g / Bluetooth / Dictophone / USB',
        '/media/70686f6e65.jpg', 1140.00, 4, 18)
     , (278205, 'LG QC185669',
        'Monitor diagonal 2.6" / Camera: 2.2Mp / RAM 16 Mb / 1800 mA/h / White / Weight 380 g / 2 Sim cards / Dictophone / USB',
        '/media/70686f6e65.jpg', 20.00, 4, 21)
     , (278211, 'PocketBook RHV50501',
        'Monitor diagonal 11" / Matrix type: E lnk Carta / Resolution: 1200x800 / Memory 5 GB / Weight 185 g',
        '/media/652d626f6f6b.jpg', 2170.00, 1, 17)
     , (278216, 'Jeka IK41639435', 'Memory 4 Gb / Weight 44 g / Black / MP3 / AMV / AVI / Dictophone',
        '/media/6d70332d706c61796572.jpg', 1690.00, 2, 6)
     , (278219, 'Samsung PR7385639',
        'Monitor diagonal 1.4" / RAM: 512 Mb / Silver / 1100 mA/h / Weight 140 g / GPS / USB / Bluetooth',
        '/media/736d6172747761746368.jpg', 1180.00, 6, 22)
     , (278225, 'Fly ANP933582',
        'Monitor diagonal 3.8" / Camera: 3.0Mp / RAM: 512 Mb / Orange / 1100 mA/h / Weight 680 g / GPS / Dictophone / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 1910.00, 5, 7)
     , (278229, 'PocketBook RS3695241', 'Monitor 8" / RAM 1 GB / HDD 240 GB / Black / Weight 300 g / WiFi / HDMI / GPS',
        '/media/7461626c6574.jpg', 750.00, 7, 17)
     , (278232, 'Prestigio EF96449553',
        'Monitor 8" / RAM 3 GB / HDD 250 GB / Black / Weight 260 g / GPS / Webcam / HDMI', '/media/7461626c6574.jpg',
        10.00, 7, 10)
     , (278234, 'Dell OHF76696259', 'Monitor 9" / RAM 4 GB / HDD 70 GB / Black / Weight 260 g / WiFi / Webcam / 3G',
        '/media/7461626c6574.jpg', 1990.00, 7, 1)
     , (278241, 'Dell GO9938',
        'Monitor 7" / RAM 4 GB / HDD 510 GB / Orange / Weight 220 g / Webcam / HDMI / Bluetooth / 3G / USB / GPS',
        '/media/7461626c6574.jpg', 1290.00, 7, 1)
     , (278247, 'PocketBook BP3379',
        'Monitor diagonal 6" / Matrix type: E lnk Carta / Resolution: 800x600 / Memory 11 GB / Weight 185 g',
        '/media/652d626f6f6b.jpg', 2830.00, 1, 17)
     , (278255, 'Philips CGA99336',
        'Monitor diagonal 1.8" / Camera: 1Mp / RAM 48 Mb / 1400 mA/h / White / Weight 320 g / Dictophone / SD / Bluetooth',
        '/media/70686f6e65.jpg', 730.00, 4, 18)
     , (278258, 'Dell UB681571',
        'Monitor 7" / RAM 2 GB / HDD 320 GB / Black / Weight 260 g / Webcam / 3G / HDMI / Bluetooth / GPS',
        '/media/7461626c6574.jpg', 1800.00, 7, 1)
     , (278268, 'Apple UT51106212',
        'Monitor 16" / Intel Core I3 (2.2 GHz) / RAM 11 GB / HDD 160 GB / Weight 6.0 kg / LAN / HDMI / USB',
        '/media/6e6f7465626f6f6b.jpg', 980.00, 3, 15)
     , (278275, 'Amazon KPB2295012',
        'Monitor diagonal 8" / Matrix type: E lnk Pearl / Resolution: 800x600 / Memory 12 GB / Weight 160 g',
        '/media/652d626f6f6b.jpg', 210.00, 1, 23)
     , (278278, 'Philips UJR442707',
        'Monitor diagonal 1.8" / Camera: 2.2Mp / RAM 16 Mb / 2000 mA/h / White / Weight 100 g / 2 Sim cards / SD / Dictophone / USB',
        '/media/70686f6e65.jpg', 1070.00, 4, 18)
     , (278280, 'Apple TLK7345319',
        'Monitor diagonal 4.4" / Camera: 4.0Mp / RAM: 512 Mb / Blue / 2000 mA/h / Weight 480 g / 3G / 2 Sim cards / GPS',
        '/media/736d61727470686f6e65.jpg', 1430.00, 5, 15)
     , (278283, 'Apple LE16570',
        'Monitor diagonal 1.4" / RAM: 512 Mb / Blue / 1200 mA/h / Weight 180 g / USB / GPS / Dictophone',
        '/media/736d6172747761746368.jpg', 1820.00, 6, 15)
     , (278289, 'Philips HV6440',
        'Monitor diagonal 2.6" / Camera: 2.2Mp / RAM 48 Mb / 1200 mA/h / Black / Weight 80 g / Dictophone / 2 Sim cards / Bluetooth / SD',
        '/media/70686f6e65.jpg', 2560.00, 4, 18)
     , (278294, 'AirOn JQV55338',
        'Monitor diagonal 1.6" / RAM: 512 Mb / Black / 1600 mA/h / Weight 220 g / Bluetooth / GPS / USB',
        '/media/736d6172747761746368.jpg', 1450.00, 6, 11)
     , (278301, 'HTC MM4320',
        'Monitor diagonal 5.0" / Camera: 3.2Mp / RAM: 4 Gb / Orange / 1000 mA/h / Weight 320 g / WiFi / USB / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 2070.00, 5, 19)
     , (278311, 'HTC FU34223452',
        'Monitor diagonal 5.6" / Camera: 3.0Mp / RAM: 1 Gb / Orange / 1800 mA/h / Weight 640 g / FM receiver / 2 Sim cards / WiFi / USB',
        '/media/736d61727470686f6e65.jpg', 2970.00, 5, 19)
     , (278319, 'Amazon FJA772238',
        'Monitor diagonal 10" / Matrix type: E lnk / Resolution: 800x600 / Memory 7 GB / Weight 175 g',
        '/media/652d626f6f6b.jpg', 870.00, 1, 23)
     , (278326, 'PocketBook BML63505',
        'Monitor diagonal 11" / Matrix type: E lnk Pearl / Resolution: 1024x758 / Memory 5 GB / Weight 155 g',
        '/media/652d626f6f6b.jpg', 780.00, 1, 17)
     , (278332, 'Sony FBI51704304',
        'Monitor 7" / RAM 2 GB / HDD 250 GB / White / Weight 60 g / 3G / USB / GPS / WiFi / Bluetooth / HDMI',
        '/media/7461626c6574.jpg', 1850.00, 7, 8)
     , (278340, 'Samsung HK169107',
        'Monitor diagonal 1.8" / Camera: 1.8Mp / RAM 32 Mb / 1500 mA/h / Blue / Weight 360 g / 2 Sim cards / Dictophone / Bluetooth',
        '/media/70686f6e65.jpg', 60.00, 4, 22)
     , (278341, 'Apple KEB801902',
        'Monitor diagonal 1.4" / RAM: 256 Mb / White / 1200 mA/h / Weight 140 g / USB / GPS / WiFi',
        '/media/736d6172747761746368.jpg', 600.00, 6, 15)
     , (278344, 'Lenovo VNE50520',
        'Monitor diagonal 3.2" / Camera: 2.2Mp / RAM: 1 Gb / Black / 1500 mA/h / Weight 400 g / Dictophone / 2 Sim cards / 3G',
        '/media/736d61727470686f6e65.jpg', 1260.00, 5, 9)
     , (278345, 'Sony AKG199088', 'Monitor 9" / RAM 2 GB / HDD 150 GB / Blue / Weight 260 g / WiFi / 3G / GPS / HDMI',
        '/media/7461626c6574.jpg', 1060.00, 7, 8)
     , (278351, 'Apple KQ01100',
        'Monitor diagonal 3.2" / Camera: 3.0Mp / RAM: 4 Gb / Blue / 1500 mA/h / Weight 360 g / GPS / WiFi / FM receiver / 3G / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 540.00, 5, 15)
     , (278361, 'Samsung AC1823',
        'Monitor diagonal 1.8" / Camera: 2.2Mp / RAM 64 Mb / 1100 mA/h / Silver / Weight 60 g / Bluetooth / Dictophone / 2 Sim cards',
        '/media/70686f6e65.jpg', 520.00, 4, 22)
     , (278362, 'Lenovo GHS8138515',
        'Monitor 8" / RAM 3 GB / HDD 90 GB / White / Weight 180 g / Webcam / Bluetooth / GPS',
        '/media/7461626c6574.jpg', 1910.00, 7, 9)
     , (278365, 'Prestigio VQT657957',
        'Monitor diagonal 5.0" / Camera: 3.2Mp / RAM: 1 Gb / Silver / 1300 mA/h / Weight 320 g / Dictophone / 3G / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 2110.00, 5, 10)
     , (278375, 'Sony FLV1145', 'Monitor 9" / RAM 4 GB / HDD 600 GB / Silver / Weight 140 g / WiFi / Webcam / 3G',
        '/media/7461626c6574.jpg', 2730.00, 7, 8)
     , (278381, 'Prestigio AO27156',
        'Monitor diagonal 2.8" / Camera: 2.2Mp / RAM 48 Mb / 1900 mA/h / Black / Weight 340 g / USB / Bluetooth / SD / Dictophone',
        '/media/70686f6e65.jpg', 750.00, 4, 10)
     , (278391, 'Apple NTO78370', 'Monitor 10" / RAM 2 GB / HDD 200 GB / Blue / Weight 220 g / 3G / USB / WiFi',
        '/media/7461626c6574.jpg', 1440.00, 7, 15)
     , (278398, 'Sony OQO9237198',
        'Monitor diagonal 4.4" / Camera: 3.2Mp / RAM: 1 Gb / White / 1500 mA/h / Weight 520 g / 3G / Dictophone / WiFi / GPS / FM receiver / USB',
        '/media/736d61727470686f6e65.jpg', 1940.00, 5, 8)
     , (278403, 'Prestigio EL37640',
        'Monitor diagonal 2.8" / Camera: 2.2Mp / RAM 16 Mb / 1200 mA/h / Orange / Weight 160 g / Bluetooth / SD / USB',
        '/media/70686f6e65.jpg', 920.00, 4, 10)
     , (278407, 'Acer QLT23067',
        'Monitor 11" / Intel Core I3 (1.6 GHz) / RAM 13 GB / HDD 580 GB / Weight 5.2 kg / HDMI / Intel HD Graphics / WiFi',
        '/media/6e6f7465626f6f6b.jpg', 2510.00, 3, 14)
     , (278409, 'Sony NL166528', 'Monitor 8" / RAM 1 GB / HDD 500 GB / Blue / Weight 260 g / GPS / HDMI / Webcam',
        '/media/7461626c6574.jpg', 1820.00, 7, 8)
     , (278413, 'Nokia RJ25973',
        'Monitor diagonal 6.0" / Camera: 4.0Mp / RAM: 512 Mb / Black / 1300 mA/h / Weight 680 g / WiFi / Dictophone / 3G / 2 Sim cards / GPS / FM receiver',
        '/media/736d61727470686f6e65.jpg', 2640.00, 5, 25)
     , (278414, 'PocketBook BI1811485',
        'Monitor diagonal 9" / Matrix type: E lnk / Resolution: 800x600 / Memory 7 GB / Weight 195 g',
        '/media/652d626f6f6b.jpg', 200.00, 1, 17)
     , (278415, 'Prestigio BJ9390', 'Monitor 8" / RAM 1 GB / HDD 310 GB / White / Weight 220 g / Webcam / USB / HDMI',
        '/media/7461626c6574.jpg', 50.00, 7, 10)
     , (278418, 'EvroMedia IPT475643',
        'Monitor diagonal 10" / Matrix type: E lnk Carta / Resolution: 800x600 / Memory 10 GB / Weight 200 g',
        '/media/652d626f6f6b.jpg', 0.00, 1, 12)
     , (278623, 'Apple PNO15365586',
        'Monitor 8" / RAM 1 GB / HDD 80 GB / Silver / Weight 100 g / USB / GPS / Bluetooth / 3G / HDMI',
        '/media/7461626c6574.jpg', 20.00, 7, 15)
     , (278424, 'LG BET88184795',
        'Monitor diagonal 3.8" / Camera: 3.0Mp / RAM: 512 Mb / Silver / 1600 mA/h / Weight 600 g / GPS / USB / FM receiver / Dictophone / WiFi / 3G / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 410.00, 5, 21)
     , (278430, 'Huawei PLR60001',
        'Monitor diagonal 3.8" / Camera: 3.0Mp / RAM: 1 Gb / Orange / 1800 mA/h / Weight 560 g / WiFi / FM receiver / USB',
        '/media/736d61727470686f6e65.jpg', 1370.00, 5, 24)
     , (278432, 'HTC LJO9384744',
        'Monitor diagonal 3.2" / Camera: 3.2Mp / RAM: 512 Mb / Black / 1800 mA/h / Weight 440 g / Bluetooth / 2 Sim cards / FM receiver',
        '/media/736d61727470686f6e65.jpg', 2930.00, 5, 19)
     , (278440, 'Prestigio FF460543',
        'Monitor 10" / RAM 2 GB / HDD 780 GB / White / Weight 100 g / GPS / WiFi / USB / Webcam / HDMI',
        '/media/7461626c6574.jpg', 2070.00, 7, 10)
     , (278445, 'Apple VVA632134',
        'Monitor 23" / Intel Core I5 (2.4 GHz) / RAM 13 GB / HDD 140 GB / Weight 5.6 kg / Bluetooth / LAN / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 1430.00, 3, 15)
     , (278447, 'HTC RT5805',
        'Monitor diagonal 3.8" / Camera: 3.0Mp / RAM: 512 Mb / Silver / 1500 mA/h / Weight 360 g / FM receiver / WiFi / 2 Sim cards / Dictophone / Bluetooth / GPS',
        '/media/736d61727470686f6e65.jpg', 2480.00, 5, 19)
     , (278453, 'Prestigio PK3695', 'Monitor 9" / RAM 1 GB / HDD 310 GB / White / Weight 100 g / HDMI / GPS / WiFi',
        '/media/7461626c6574.jpg', 820.00, 7, 10)
     , (278455, 'AirOn OMG059282',
        'Monitor diagonal 1.8" / RAM: 1 Gb / White / 1800 mA/h / Weight 140 g / USB / Bluetooth / Dictophone',
        '/media/736d6172747761746368.jpg', 700.00, 6, 11)
     , (278460, 'LG LID5120',
        'Monitor diagonal 3.0" / Camera: 2.6Mp / RAM 48 Mb / 1600 mA/h / Silver / Weight 340 g / SD / Dictophone / 2 Sim cards',
        '/media/70686f6e65.jpg', 1140.00, 4, 21)
     , (278462, 'HTC RA406875',
        'Monitor diagonal 5.0" / Camera: 3.0Mp / RAM: 2 Gb / Orange / 1800 mA/h / Weight 600 g / USB / 3G / Dictophone',
        '/media/736d61727470686f6e65.jpg', 260.00, 5, 19)
     , (278472, 'Amazon KQ391237',
        'Monitor diagonal 8" / Matrix type: E lnk Carta / Resolution: 1024x758 / Memory 8 GB / Weight 175 g',
        '/media/652d626f6f6b.jpg', 170.00, 1, 23)
     , (278474, 'Gigabyte VHD23703437',
        'Monitor diagonal 2.2" / Camera: 1.8Mp / RAM 32 Mb / 1700 mA/h / Black / Weight 360 g / SD / Bluetooth / USB / 2 Sim cards',
        '/media/70686f6e65.jpg', 130.00, 4, 4)
     , (278481, 'AirOn OP07865469',
        'Monitor diagonal 1.1" / RAM: 1 Gb / Orange / 1000 mA/h / Weight 140 g / GPS / USB / Bluetooth',
        '/media/736d6172747761746368.jpg', 570.00, 6, 11)
     , (278484, 'Apple UT12453450',
        'Monitor 11" / Intel Core I5 (2.2 GHz) / RAM 2 GB / HDD 530 GB / Weight 4.2 kg / WiFi / Intel HD Graphics / HDMI',
        '/media/6e6f7465626f6f6b.jpg', 2000.00, 3, 15)
     , (278487, 'Philips KDN24042',
        'Monitor diagonal 2.6" / Camera: 1Mp / RAM 64 Mb / 1200 mA/h / White / Weight 100 g / 2 Sim cards / Bluetooth / SD',
        '/media/70686f6e65.jpg', 900.00, 4, 18)
     , (278489, 'Dell EE290890',
        'Monitor 7" / RAM 2 GB / HDD 100 GB / Black / Weight 140 g / HDMI / Webcam / WiFi / GPS',
        '/media/7461626c6574.jpg', 1030.00, 7, 1)
     , (278490, 'Apple UJ3016316', 'Memory 20 Gb / Weight 56 g / Orange / MP3 / AVI / FM receiver / WMA / WAV / OGG',
        '/media/6d70332d706c61796572.jpg', 460.00, 2, 15)
     , (278496, 'Asus QO27082456',
        'Monitor 16" / Intel Core I5 (2.4 GHz) / RAM 8 GB / HDD 740 GB / Weight 2.6 kg / Intel HD Graphics / LAN / Bluetooth / Webcam / USB / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 780.00, 3, 13)
     , (278500, 'Sony OND7337674',
        'Monitor diagonal 5.6" / Camera: 4.0Mp / RAM: 1 Gb / Orange / 2000 mA/h / Weight 400 g / USB / 2 Sim cards / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 1410.00, 5, 8)
     , (278506, 'Dell USS831683',
        'Monitor 18" / Intel Core I5 (2.0 GHz) / RAM 1 GB / HDD 500 GB / Weight 3.2 kg / Webcam / USB / DVD+/-RW / LAN / Bluetooth',
        '/media/6e6f7465626f6f6b.jpg', 2230.00, 3, 1)
     , (278513, 'EvroMedia EP4022750',
        'Monitor diagonal 7" / Matrix type: E lnk Pearl / Resolution: 1024x758 / Memory 4 GB / Weight 180 g',
        '/media/652d626f6f6b.jpg', 970.00, 1, 12)
     , (278515, 'Fly ECC885631',
        'Monitor diagonal 4.4" / Camera: 2.2Mp / RAM: 4 Gb / Blue / 1800 mA/h / Weight 760 g / 3G / 2 Sim cards / Dictophone / USB',
        '/media/736d61727470686f6e65.jpg', 510.00, 5, 7)
     , (278519, 'Sony EO5507706',
        'Memory 8 Gb / Weight 32 g / Blue / MP3 / Dictophone / Bluetooth / AVI / WMA / MPEG-4 / WAV',
        '/media/6d70332d706c61796572.jpg', 1950.00, 2, 8)
     , (278528, 'Prestigio OO4622',
        'Monitor 9" / RAM 2 GB / HDD 680 GB / Silver / Weight 100 g / GPS / HDMI / Bluetooth / 3G / WiFi',
        '/media/7461626c6574.jpg', 2550.00, 7, 10)
     , (278536, 'Nokia GSE6673562',
        'Monitor diagonal 3.8" / Camera: 2.2Mp / RAM: 4 Gb / Black / 1600 mA/h / Weight 560 g / Dictophone / Bluetooth / GPS / USB',
        '/media/736d61727470686f6e65.jpg', 900.00, 5, 25)
     , (278541, 'HP VL618482',
        'Monitor 18" / Intel Core I7 (2.0 GHz) / RAM 5 GB / HDD 750 GB / Weight 2.8 kg / WiFi / Bluetooth / LAN / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 2140.00, 3, 3)
     , (278547, 'HTC LQ68057515',
        'Monitor diagonal 3.8" / Camera: 3.0Mp / RAM: 512 Mb / Black / 1900 mA/h / Weight 680 g / 3G / Dictophone / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 2970.00, 5, 19)
     , (278557, 'Acer OM08435148', 'Monitor 7" / RAM 2 GB / HDD 390 GB / White / Weight 220 g / Bluetooth / WiFi / USB',
        '/media/7461626c6574.jpg', 960.00, 7, 14)
     , (278561, 'HTC MG57383113',
        'Monitor diagonal 6.0" / Camera: 3.2Mp / RAM: 2 Gb / Blue / 1900 mA/h / Weight 720 g / USB / WiFi / FM receiver',
        '/media/736d61727470686f6e65.jpg', 1980.00, 5, 19)
     , (278564, 'Huawei CG8064',
        'Monitor diagonal 3.2" / Camera: 3.2Mp / RAM: 512 Mb / White / 1700 mA/h / Weight 760 g / GPS / USB / FM receiver',
        '/media/736d61727470686f6e65.jpg', 1950.00, 5, 24)
     , (278565, 'AirBook JOJ04656',
        'Monitor diagonal 10" / Matrix type: E lnk Carta / Resolution: 1200x800 / Memory 8 GB / Weight 175 g',
        '/media/652d626f6f6b.jpg', 730.00, 1, 20)
     , (278566, 'Samsung IO3275837',
        'Monitor diagonal 2.8" / Camera: 1.8Mp / RAM 48 Mb / 1700 mA/h / White / Weight 60 g / 2 Sim cards / USB / Dictophone',
        '/media/70686f6e65.jpg', 2630.00, 4, 22)
     , (278576, 'Prestigio JM777211',
        'Monitor diagonal 2.0" / Camera: 2.6Mp / RAM 64 Mb / 1700 mA/h / Blue / Weight 120 g / Dictophone / Bluetooth / USB',
        '/media/70686f6e65.jpg', 2470.00, 4, 10)
     , (278577, 'AirBook CAH58636',
        'Monitor diagonal 8" / Matrix type: E lnk Carta / Resolution: 800x600 / Memory 4 GB / Weight 170 g',
        '/media/652d626f6f6b.jpg', 700.00, 1, 20)
     , (278583, 'Asus RCM3577540',
        'Monitor 15" / Intel Core I7 (2.6 GHz) / RAM 6 GB / HDD 400 GB / Weight 4.2 kg / Webcam / LAN / Bluetooth',
        '/media/6e6f7465626f6f6b.jpg', 2210.00, 3, 13)
     , (278591, 'PocketBook BQ0165',
        'Monitor diagonal 11" / Matrix type: E lnk Pearl / Resolution: 800x600 / Memory 8 GB / Weight 170 g',
        '/media/652d626f6f6b.jpg', 2500.00, 1, 17)
     , (278601, 'Apple AI0587127',
        'Monitor 12" / Intel Core I5 (2.2 GHz) / RAM 13 GB / HDD 290 GB / Weight 6.6 kg / Webcam / Bluetooth / LAN / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 580.00, 3, 15)
     , (278611, 'Philips ABC00415628',
        'Monitor diagonal 2.6" / Camera: 1.8Mp / RAM 32 Mb / 1000 mA/h / Silver / Weight 100 g / Bluetooth / SD / Dictophone / 2 Sim cards',
        '/media/70686f6e65.jpg', 830.00, 4, 18)
     , (278612, 'Nokia FBE40156104',
        'Monitor diagonal 4.4" / Camera: 3.2Mp / RAM: 512 Mb / Silver / 1100 mA/h / Weight 480 g / USB / Bluetooth / Dictophone / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 2740.00, 5, 25)
     , (278620, 'Samsung DS20059509',
        'Monitor diagonal 2.2" / Camera: 2.2Mp / RAM 32 Mb / 1900 mA/h / Silver / Weight 380 g / Bluetooth / USB / SD',
        '/media/70686f6e65.jpg', 800.00, 4, 22)
     , (278631, 'Apple LL57105282',
        'Memory 12 Gb / Weight 26 g / Silver / MP3 / WAV / FM receiver / AMV / Dictophone / WMA / OGG / MPEG-4 / AVI / USB / Bluetooth',
        '/media/6d70332d706c61796572.jpg', 300.00, 2, 15)
     , (278638, 'Nokia SFQ3481',
        'Monitor diagonal 3.8" / Camera: 3.0Mp / RAM: 1 Gb / Blue / 1400 mA/h / Weight 480 g / Bluetooth / 3G / USB / GPS / Dictophone',
        '/media/736d61727470686f6e65.jpg', 240.00, 5, 25)
     , (278648, 'Dell FHT181887',
        'Monitor 23" / Intel Core I7 (2.0 GHz) / RAM 11 GB / HDD 460 GB / Weight 2.6 kg / USB / DVD+/-RW / Bluetooth / WiFi / LAN',
        '/media/6e6f7465626f6f6b.jpg', 2520.00, 3, 1)
     , (278650, 'Asus JUL5305',
        'Monitor 11" / Intel Core I5 (2.6 GHz) / RAM 8 GB / HDD 100 GB / Weight 4.6 kg / HDMI / WiFi / Bluetooth / DVD+/-RW / Webcam / USB / LAN',
        '/media/6e6f7465626f6f6b.jpg', 2850.00, 3, 13)
     , (278658, 'Transcend IRU7638',
        'Memory 20 Gb / Weight 29 g / Silver / MP3 / Bluetooth / AMV / SD slot / FM receiver / WMA / MPEG-4',
        '/media/6d70332d706c61796572.jpg', 560.00, 2, 5)
     , (278664, 'FixiTime DV123312',
        'Monitor diagonal 1.6" / RAM: 1 Gb / Silver / 2000 mA/h / Weight 60 g / Dictophone / WiFi / USB / GPS',
        '/media/736d6172747761746368.jpg', 790.00, 6, 16)
     , (278665, 'PocketBook UHK3659964',
        'Monitor diagonal 12" / Matrix type: E lnk Carta / Resolution: 1024x758 / Memory 5 GB / Weight 185 g',
        '/media/652d626f6f6b.jpg', 2870.00, 1, 17)
     , (278672, 'LG CI3197723',
        'Monitor diagonal 5.6" / Camera: 2.2Mp / RAM: 4 Gb / Blue / 1600 mA/h / Weight 640 g / 3G / GPS / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 2630.00, 5, 21)
     , (278674, 'Nokia EJ78886',
        'Monitor diagonal 2.4" / Camera: 1Mp / RAM 16 Mb / 1600 mA/h / Silver / Weight 80 g / USB / Bluetooth / Dictophone',
        '/media/70686f6e65.jpg', 110.00, 4, 25)
     , (278682, 'Apple LF2535',
        'Monitor 20" / Intel Core I5 (2.8 GHz) / RAM 3 GB / HDD 110 GB / Weight 2.8 kg / Bluetooth / HDMI / USB / Intel HD Graphics / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 1410.00, 3, 15)
     , (278686, 'HTC OV311948',
        'Monitor diagonal 3.2" / Camera: 3.2Mp / RAM: 4 Gb / Black / 1000 mA/h / Weight 760 g / 2 Sim cards / Dictophone / WiFi / GPS / Bluetooth / USB',
        '/media/736d61727470686f6e65.jpg', 2370.00, 5, 19)
     , (278688, 'Nokia LOT28017778',
        'Monitor diagonal 5.6" / Camera: 3.2Mp / RAM: 1 Gb / Silver / 1300 mA/h / Weight 320 g / USB / Dictophone / 3G / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 1160.00, 5, 25)
     , (278695, 'Apple IGB051736', 'Memory 12 Gb / Weight 92 g / Blue / MP3 / Dictophone / SD slot / WMA / AMV',
        '/media/6d70332d706c61796572.jpg', 2400.00, 2, 15)
     , (278697, 'Asus NL80558', 'Monitor 10" / RAM 2 GB / HDD 400 GB / Orange / Weight 260 g / Webcam / HDMI / WiFi',
        '/media/7461626c6574.jpg', 2020.00, 7, 13)
     , (278698, 'Gigabyte IN87579',
        'Monitor diagonal 2.4" / Camera: 1Mp / RAM 64 Mb / 2000 mA/h / Silver / Weight 260 g / USB / Bluetooth / SD',
        '/media/70686f6e65.jpg', 240.00, 4, 4)
     , (278700, 'Lenovo FD694365',
        'Monitor diagonal 3.8" / Camera: 2.2Mp / RAM: 4 Gb / White / 1900 mA/h / Weight 800 g / GPS / Dictophone / 2 Sim cards / WiFi / 3G',
        '/media/736d61727470686f6e65.jpg', 1510.00, 5, 9)
     , (278706, 'HTC RF67533310',
        'Monitor diagonal 5.0" / Camera: 2.2Mp / RAM: 2 Gb / Blue / 2000 mA/h / Weight 720 g / 3G / WiFi / Dictophone / USB / GPS / Bluetooth / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 190.00, 5, 19)
     , (278714, 'FiiO UQ5605',
        'Memory 12 Gb / Weight 77 g / Silver / MP3 / USB / WAV / AVI / Dictophone / Bluetooth / FM receiver / MPEG-4',
        '/media/6d70332d706c61796572.jpg', 1030.00, 2, 2)
     , (278721, 'LG OR3926',
        'Monitor diagonal 2.2" / Camera: 1Mp / RAM 32 Mb / 1800 mA/h / Black / Weight 380 g / Bluetooth / 2 Sim cards / Dictophone',
        '/media/70686f6e65.jpg', 1680.00, 4, 21)
     , (278726, 'Nokia FKM5847559',
        'Monitor diagonal 6.0" / Camera: 3.2Mp / RAM: 512 Mb / Black / 2000 mA/h / Weight 760 g / FM receiver / WiFi / Bluetooth / 3G / Dictophone / USB',
        '/media/736d61727470686f6e65.jpg', 1820.00, 5, 25)
     , (278730, 'Samsung KCU51848',
        'Monitor diagonal 3.2" / Camera: 4.0Mp / RAM: 2 Gb / Silver / 1100 mA/h / Weight 440 g / Dictophone / WiFi / FM receiver / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 1690.00, 5, 22)
     , (278731, 'LG IRL1795748',
        'Monitor diagonal 2.4" / Camera: 2.6Mp / RAM 32 Mb / 1400 mA/h / Black / Weight 160 g / Dictophone / 2 Sim cards / SD / USB',
        '/media/70686f6e65.jpg', 2550.00, 4, 21)
     , (278736, 'PocketBook ID113917',
        'Monitor diagonal 10" / Matrix type: E lnk Pearl / Resolution: 1024x758 / Memory 10 GB / Weight 185 g',
        '/media/652d626f6f6b.jpg', 1240.00, 1, 17)
     , (278746, 'Lenovo DM52835395',
        'Monitor diagonal 5.6" / Camera: 4.0Mp / RAM: 2 Gb / Orange / 1100 mA/h / Weight 760 g / GPS / Dictophone / USB',
        '/media/736d61727470686f6e65.jpg', 2250.00, 5, 9)
     , (278750, 'Nokia ND80617713',
        'Monitor diagonal 4.4" / Camera: 2.2Mp / RAM: 4 Gb / Blue / 1200 mA/h / Weight 320 g / Dictophone / 3G / WiFi',
        '/media/736d61727470686f6e65.jpg', 2530.00, 5, 25)
     , (278759, 'Apple NUV88495',
        'Monitor 23" / Intel Core I3 (2.6 GHz) / RAM 15 GB / HDD 200 GB / Weight 5.4 kg / USB / Bluetooth / LAN',
        '/media/6e6f7465626f6f6b.jpg', 2060.00, 3, 15)
     , (278762, 'Philips BQ8425',
        'Monitor diagonal 2.4" / Camera: 2.6Mp / RAM 32 Mb / 1200 mA/h / Black / Weight 360 g / Bluetooth / Dictophone / SD',
        '/media/70686f6e65.jpg', 1980.00, 4, 18)
     , (278765, 'Acer BBB049232',
        'Monitor 19" / Intel Core I3 (1.8 GHz) / RAM 8 GB / HDD 290 GB / Weight 2.6 kg / DVD+/-RW / WiFi / LAN',
        '/media/6e6f7465626f6f6b.jpg', 90.00, 3, 14)
     , (278775, 'EvroMedia VKG5123',
        'Monitor diagonal 8" / Matrix type: E lnk / Resolution: 1600x1200 / Memory 9 GB / Weight 180 g',
        '/media/652d626f6f6b.jpg', 2030.00, 1, 12)
     , (278781, 'Samsung AGN2844',
        'Monitor diagonal 3.0" / Camera: 2.2Mp / RAM 16 Mb / 1200 mA/h / White / Weight 340 g / Bluetooth / 2 Sim cards / Dictophone / USB',
        '/media/70686f6e65.jpg', 1250.00, 4, 22)
     , (278788, 'LG IOP0316611',
        'Monitor diagonal 5.6" / Camera: 3.0Mp / RAM: 512 Mb / White / 1900 mA/h / Weight 320 g / Bluetooth / GPS / WiFi / Dictophone / FM receiver / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 730.00, 5, 21)
     , (278797, 'Lenovo JUI007482',
        'Monitor 20" / Intel Core I7 (2.4 GHz) / RAM 14 GB / HDD 300 GB / Weight 4.4 kg / DVD+/-RW / Bluetooth / HDMI',
        '/media/6e6f7465626f6f6b.jpg', 750.00, 3, 9)
     , (278798, 'Asus SI57435',
        'Monitor 20" / Intel Core I3 (2.6 GHz) / RAM 9 GB / HDD 630 GB / Weight 6.0 kg / Intel HD Graphics / Bluetooth / USB',
        '/media/6e6f7465626f6f6b.jpg', 560.00, 3, 13)
     , (278808, 'Dell VPD9734',
        'Monitor 14" / Intel Core I3 (1.6 GHz) / RAM 1 GB / HDD 570 GB / Weight 4.2 kg / DVD+/-RW / WiFi / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 2280.00, 3, 1)
     , (278811, 'Prestigio GPJ67303157',
        'Monitor diagonal 5.6" / Camera: 3.0Mp / RAM: 4 Gb / Silver / 1200 mA/h / Weight 480 g / 3G / WiFi / FM receiver / 2 Sim cards / GPS',
        '/media/736d61727470686f6e65.jpg', 2270.00, 5, 10)
     , (278812, 'PocketBook UJ18543736',
        'Monitor diagonal 11" / Matrix type: E lnk / Resolution: 1024x758 / Memory 11 GB / Weight 165 g',
        '/media/652d626f6f6b.jpg', 2190.00, 1, 17)
     , (278813, 'Prestigio OTU324521',
        'Monitor diagonal 3.0" / Camera: 2.6Mp / RAM 32 Mb / 1400 mA/h / Blue / Weight 240 g / USB / Dictophone / 2 Sim cards / Bluetooth',
        '/media/70686f6e65.jpg', 2000.00, 4, 10)
     , (278820, 'HP BNS0492398',
        'Monitor 23" / Intel Core I7 (2.8 GHz) / RAM 5 GB / HDD 460 GB / Weight 5.0 kg / LAN / DVD+/-RW / WiFi',
        '/media/6e6f7465626f6f6b.jpg', 1970.00, 3, 3)
     , (280127, 'Sony DMS3088459', 'Monitor 9" / RAM 4 GB / HDD 600 GB / White / Weight 220 g / Webcam / 3G / GPS',
        '/media/7461626c6574.jpg', 920.00, 7, 8)
     , (278825, 'Samsung LI1504315',
        'Monitor diagonal 1.6" / RAM: 512 Mb / White / 1300 mA/h / Weight 300 g / Bluetooth / USB / GPS',
        '/media/736d6172747761746368.jpg', 1180.00, 6, 22)
     , (278828, 'Lenovo BB68492080',
        'Monitor diagonal 6.0" / Camera: 3.2Mp / RAM: 4 Gb / Orange / 1300 mA/h / Weight 720 g / GPS / WiFi / Dictophone / Bluetooth / USB / 3G / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 2250.00, 5, 9)
     , (278838, 'Sony FST39890',
        'Memory 16 Gb / Weight 38 g / White / MP3 / SD slot / MPEG-4 / WMA / Bluetooth / AMV / AVI / Dictophone / USB / WAV',
        '/media/6d70332d706c61796572.jpg', 1710.00, 2, 8)
     , (278843, 'Samsung RH5820',
        'Monitor diagonal 2.0" / Camera: 1Mp / RAM 16 Mb / 1500 mA/h / White / Weight 120 g / Dictophone / SD / 2 Sim cards / Bluetooth',
        '/media/70686f6e65.jpg', 1540.00, 4, 22)
     , (278847, 'Nokia MC4558',
        'Monitor diagonal 5.0" / Camera: 4.0Mp / RAM: 1 Gb / Silver / 1900 mA/h / Weight 800 g / USB / FM receiver / WiFi',
        '/media/736d61727470686f6e65.jpg', 530.00, 5, 25)
     , (278856, 'Gigabyte RF67822173',
        'Monitor diagonal 3.0" / Camera: 2.2Mp / RAM 48 Mb / 1600 mA/h / Blue / Weight 360 g / USB / Dictophone / Bluetooth / SD',
        '/media/70686f6e65.jpg', 730.00, 4, 4)
     , (278857, 'Lenovo SL718675',
        'Monitor 15" / Intel Core I5 (2.2 GHz) / RAM 4 GB / HDD 640 GB / Weight 4.8 kg / DVD+/-RW / Bluetooth / HDMI / WiFi / Webcam / LAN / Intel HD Graphics',
        '/media/6e6f7465626f6f6b.jpg', 2820.00, 3, 9)
     , (278865, 'Nokia GMS5051875',
        'Monitor diagonal 3.0" / Camera: 2.2Mp / RAM 48 Mb / 1600 mA/h / Black / Weight 60 g / USB / Bluetooth / 2 Sim cards',
        '/media/70686f6e65.jpg', 2640.00, 4, 25)
     , (278867, 'PocketBook MVC32694',
        'Monitor diagonal 6" / Matrix type: E lnk / Resolution: 800x600 / Memory 4 GB / Weight 170 g',
        '/media/652d626f6f6b.jpg', 1590.00, 1, 17)
     , (278873, 'PocketBook HT3980',
        'Monitor 7" / RAM 4 GB / HDD 520 GB / Silver / Weight 60 g / Bluetooth / HDMI / Webcam',
        '/media/7461626c6574.jpg', 2980.00, 7, 17)
     , (278880, 'Jeka PI3160',
        'Memory 4 Gb / Weight 41 g / White / MP3 / USB / AVI / Bluetooth / OGG / WMA / FM receiver',
        '/media/6d70332d706c61796572.jpg', 680.00, 2, 6)
     , (278888, 'Sony EQI462134', 'Memory 16 Gb / Weight 68 g / Silver / MP3 / WAV / MPEG-4 / SD slot / USB / AMV',
        '/media/6d70332d706c61796572.jpg', 2940.00, 2, 8)
     , (278893, 'Lenovo JD4137',
        'Monitor diagonal 3.2" / Camera: 2.2Mp / RAM: 1 Gb / White / 1500 mA/h / Weight 800 g / 2 Sim cards / WiFi / Dictophone',
        '/media/736d61727470686f6e65.jpg', 1040.00, 5, 9)
     , (278898, 'EvroMedia BHT287248',
        'Monitor diagonal 9" / Matrix type: E lnk Carta / Resolution: 1024x758 / Memory 10 GB / Weight 175 g',
        '/media/652d626f6f6b.jpg', 2060.00, 1, 12)
     , (278900, 'HP GP8452386',
        'Monitor 12" / Intel Core I5 (2.4 GHz) / RAM 16 GB / HDD 790 GB / Weight 6.0 kg / Intel HD Graphics / HDMI / WiFi',
        '/media/6e6f7465626f6f6b.jpg', 190.00, 3, 3)
     , (278901, 'Amazon VRB0939516',
        'Monitor diagonal 6" / Matrix type: E lnk / Resolution: 800x600 / Memory 4 GB / Weight 185 g',
        '/media/652d626f6f6b.jpg', 80.00, 1, 23)
     , (278903, 'Lenovo MP87387',
        'Monitor 20" / Intel Core I5 (2.2 GHz) / RAM 15 GB / HDD 120 GB / Weight 3.4 kg / Intel HD Graphics / WiFi / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 300.00, 3, 9)
     , (278904, 'Lenovo UM2290010',
        'Monitor 16" / Intel Core I7 (2.2 GHz) / RAM 16 GB / HDD 360 GB / Weight 5.4 kg / WiFi / LAN / Intel HD Graphics / HDMI',
        '/media/6e6f7465626f6f6b.jpg', 620.00, 3, 9)
     , (278911, 'Nokia ND98899',
        'Monitor diagonal 2.0" / Camera: 1.8Mp / RAM 16 Mb / 1800 mA/h / Black / Weight 400 g / Dictophone / Bluetooth / 2 Sim cards',
        '/media/70686f6e65.jpg', 240.00, 4, 25)
     , (278916, 'AirOn FI9064446',
        'Monitor diagonal 1.4" / RAM: 1 Gb / Silver / 1500 mA/h / Weight 100 g / GPS / Bluetooth / Dictophone',
        '/media/736d6172747761746368.jpg', 1130.00, 6, 11)
     , (278923, 'Apple NJ16749796',
        'Memory 8 Gb / Weight 56 g / White / MP3 / WAV / MPEG-4 / FM receiver / AVI / OGG / Dictophone / SD slot / USB / Bluetooth',
        '/media/6d70332d706c61796572.jpg', 950.00, 2, 15)
     , (278932, 'Philips AQ450828',
        'Monitor diagonal 2.2" / Camera: 2.6Mp / RAM 32 Mb / 1700 mA/h / Black / Weight 280 g / 2 Sim cards / Dictophone / Bluetooth',
        '/media/70686f6e65.jpg', 2500.00, 4, 18)
     , (278940, 'Lenovo JI96701',
        'Monitor 17" / Intel Core I7 (3.0 GHz) / RAM 8 GB / HDD 690 GB / Weight 4.4 kg / LAN / Bluetooth / USB / Intel HD Graphics / HDMI',
        '/media/6e6f7465626f6f6b.jpg', 1630.00, 3, 9)
     , (278944, 'Dell GH16786110', 'Monitor 7" / RAM 3 GB / HDD 530 GB / Blue / Weight 220 g / USB / GPS / 3G',
        '/media/7461626c6574.jpg', 2420.00, 7, 1)
     , (278948, 'HP CJR105628',
        'Monitor 23" / Intel Core I3 (2.6 GHz) / RAM 11 GB / HDD 290 GB / Weight 5.0 kg / Bluetooth / LAN / WiFi',
        '/media/6e6f7465626f6f6b.jpg', 760.00, 3, 3)
     , (278949, 'HP RMI36174792',
        'Monitor 14" / Intel Core I3 (1.8 GHz) / RAM 10 GB / HDD 670 GB / Weight 4.0 kg / Webcam / Bluetooth / USB',
        '/media/6e6f7465626f6f6b.jpg', 2630.00, 3, 3)
     , (278951, 'LG NHF985622',
        'Monitor diagonal 3.8" / Camera: 3.2Mp / RAM: 1 Gb / White / 1600 mA/h / Weight 680 g / Bluetooth / USB / FM receiver',
        '/media/736d61727470686f6e65.jpg', 550.00, 5, 21)
     , (278959, 'Dell UAJ69807',
        'Monitor 23" / Intel Core I5 (2.2 GHz) / RAM 2 GB / HDD 200 GB / Weight 6.6 kg / USB / Intel HD Graphics / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 2060.00, 3, 1)
     , (278967, 'Samsung VUT291257',
        'Monitor diagonal 2.4" / Camera: 1Mp / RAM 48 Mb / 1300 mA/h / Silver / Weight 100 g / Dictophone / USB / Bluetooth',
        '/media/70686f6e65.jpg', 860.00, 4, 22)
     , (278971, 'Apple KUU54695145', 'Memory 20 Gb / Weight 86 g / Silver / MP3 / Bluetooth / USB / AVI',
        '/media/6d70332d706c61796572.jpg', 890.00, 2, 15)
     , (278980, 'Huawei FRG623811',
        'Monitor diagonal 5.6" / Camera: 4.0Mp / RAM: 2 Gb / Black / 1800 mA/h / Weight 720 g / FM receiver / Dictophone / USB / 2 Sim cards / GPS / 3G',
        '/media/736d61727470686f6e65.jpg', 2760.00, 5, 24)
     , (278986, 'HP MRU1015542',
        'Monitor 20" / Intel Core I5 (2.6 GHz) / RAM 7 GB / HDD 160 GB / Weight 6.2 kg / USB / Intel HD Graphics / Bluetooth / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 1630.00, 3, 3)
     , (278987, 'Prestigio BG1413',
        'Monitor diagonal 3.8" / Camera: 2.2Mp / RAM: 2 Gb / Black / 1200 mA/h / Weight 720 g / WiFi / FM receiver / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 2020.00, 5, 10)
     , (278997, 'Gigabyte JRA56495',
        'Monitor diagonal 2.8" / Camera: 2.6Mp / RAM 32 Mb / 1100 mA/h / Blue / Weight 60 g / SD / Bluetooth / USB',
        '/media/70686f6e65.jpg', 500.00, 4, 4)
     , (279000, 'Huawei HOE7522',
        'Monitor diagonal 6.0" / Camera: 3.2Mp / RAM: 2 Gb / Orange / 1800 mA/h / Weight 520 g / USB / Bluetooth / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 1320.00, 5, 24)
     , (279010, 'Prestigio TGQ0476360',
        'Monitor diagonal 3.8" / Camera: 3.2Mp / RAM: 4 Gb / Blue / 1900 mA/h / Weight 520 g / WiFi / GPS / Bluetooth / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 2290.00, 5, 10)
     , (279018, 'LG AID53787312',
        'Monitor diagonal 2.0" / Camera: 1Mp / RAM 16 Mb / 1300 mA/h / Orange / Weight 260 g / 2 Sim cards / USB / SD',
        '/media/70686f6e65.jpg', 2770.00, 4, 21)
     , (279020, 'HTC UCJ873167',
        'Monitor diagonal 3.2" / Camera: 2.2Mp / RAM: 4 Gb / Orange / 1100 mA/h / Weight 320 g / 2 Sim cards / GPS / WiFi',
        '/media/736d61727470686f6e65.jpg', 2990.00, 5, 19)
     , (279025, 'LG QO96947',
        'Monitor diagonal 5.6" / Camera: 3.0Mp / RAM: 1 Gb / Black / 1400 mA/h / Weight 400 g / Bluetooth / WiFi / USB / Dictophone / 3G / GPS / FM receiver',
        '/media/736d61727470686f6e65.jpg', 2010.00, 5, 21)
     , (279032, 'HTC FI74198',
        'Monitor diagonal 5.0" / Camera: 4.0Mp / RAM: 512 Mb / Black / 1200 mA/h / Weight 720 g / WiFi / USB / FM receiver / GPS / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 1680.00, 5, 19)
     , (279042, 'AirBook UV6767',
        'Monitor diagonal 12" / Matrix type: E lnk Pearl / Resolution: 1200x800 / Memory 8 GB / Weight 175 g',
        '/media/652d626f6f6b.jpg', 1400.00, 1, 20)
     , (279045, 'Prestigio HM09962096',
        'Monitor 8" / RAM 3 GB / HDD 790 GB / White / Weight 220 g / Bluetooth / WiFi / 3G / HDMI / USB / GPS',
        '/media/7461626c6574.jpg', 1570.00, 7, 10)
     , (279047, 'Apple RQU003576', 'Memory 20 Gb / Weight 56 g / Orange / MP3 / AMV / AVI / OGG',
        '/media/6d70332d706c61796572.jpg', 600.00, 2, 15)
     , (279057, 'Philips DLE410994',
        'Monitor diagonal 2.4" / Camera: 1.8Mp / RAM 32 Mb / 1700 mA/h / Orange / Weight 300 g / Bluetooth / SD / 2 Sim cards',
        '/media/70686f6e65.jpg', 940.00, 4, 18)
     , (279065, 'Dell JQ6219765',
        'Monitor 8" / RAM 1 GB / HDD 740 GB / White / Weight 140 g / Bluetooth / 3G / Webcam / GPS / USB',
        '/media/7461626c6574.jpg', 590.00, 7, 1)
     , (279067, 'Sony AN80622', 'Memory 20 Gb / Weight 20 g / Orange / MP3 / AMV / FM receiver / WAV / USB / SD slot',
        '/media/6d70332d706c61796572.jpg', 50.00, 2, 8)
     , (279068, 'Samsung FP57728010',
        'Monitor diagonal 1.6" / RAM: 1 Gb / Black / 1100 mA/h / Weight 180 g / GPS / Bluetooth / WiFi',
        '/media/736d6172747761746368.jpg', 710.00, 6, 22)
     , (279074, 'AirOn IS9059',
        'Monitor diagonal 1.3" / RAM: 256 Mb / Orange / 2000 mA/h / Weight 140 g / WiFi / USB / Dictophone',
        '/media/736d6172747761746368.jpg', 1500.00, 6, 11)
     , (279077, 'PocketBook HH9415',
        'Monitor diagonal 6" / Matrix type: E lnk Carta / Resolution: 1024x758 / Memory 4 GB / Weight 180 g',
        '/media/652d626f6f6b.jpg', 1560.00, 1, 17)
     , (279078, 'Samsung EPV7989',
        'Monitor diagonal 2.2" / Camera: 2.6Mp / RAM 64 Mb / 1700 mA/h / Orange / Weight 260 g / Dictophone / USB / SD',
        '/media/70686f6e65.jpg', 1860.00, 4, 22)
     , (279085, 'Samsung BU5263674',
        'Monitor diagonal 1.8" / RAM: 256 Mb / Blue / 1400 mA/h / Weight 260 g / Bluetooth / WiFi / GPS',
        '/media/736d6172747761746368.jpg', 980.00, 6, 22)
     , (279090, 'Fly DP54250108',
        'Monitor diagonal 5.6" / Camera: 4.0Mp / RAM: 1 Gb / Silver / 1600 mA/h / Weight 360 g / 2 Sim cards / USB / WiFi',
        '/media/736d61727470686f6e65.jpg', 2330.00, 5, 7)
     , (279093, 'Nokia UAV8289667',
        'Monitor diagonal 5.0" / Camera: 2.2Mp / RAM: 512 Mb / Silver / 1400 mA/h / Weight 640 g / Bluetooth / GPS / 2 Sim cards / FM receiver / USB / 3G / WiFi',
        '/media/736d61727470686f6e65.jpg', 2250.00, 5, 25)
     , (279101, 'PocketBook GT3457163',
        'Monitor diagonal 9" / Matrix type: E lnk Carta / Resolution: 800x600 / Memory 8 GB / Weight 160 g',
        '/media/652d626f6f6b.jpg', 290.00, 1, 17)
     , (279102, 'LG FD3852052',
        'Monitor diagonal 1.8" / Camera: 1Mp / RAM 48 Mb / 1700 mA/h / White / Weight 140 g / Bluetooth / Dictophone / 2 Sim cards',
        '/media/70686f6e65.jpg', 2000.00, 4, 21)
     , (279112, 'Asus UMK07882946', 'Monitor 9" / RAM 1 GB / HDD 380 GB / White / Weight 260 g / USB / 3G / Bluetooth',
        '/media/7461626c6574.jpg', 1170.00, 7, 13)
     , (279121, 'Lenovo SB839392',
        'Monitor diagonal 3.8" / Camera: 2.2Mp / RAM: 512 Mb / White / 1900 mA/h / Weight 480 g / 3G / USB / FM receiver / WiFi / GPS / Bluetooth / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 360.00, 5, 9)
     , (279130, 'Gigabyte BDH4546',
        'Monitor diagonal 2.4" / Camera: 2.2Mp / RAM 48 Mb / 1900 mA/h / Silver / Weight 100 g / SD / Dictophone / USB',
        '/media/70686f6e65.jpg', 1030.00, 4, 4)
     , (279139, 'HP FR67891',
        'Monitor 11" / Intel Core I3 (2.6 GHz) / RAM 1 GB / HDD 470 GB / Weight 6.2 kg / Bluetooth / Intel HD Graphics / Webcam / HDMI / WiFi / USB',
        '/media/6e6f7465626f6f6b.jpg', 2770.00, 3, 3)
     , (279143, 'Dell OJ286177',
        'Monitor 23" / Intel Core I3 (2.6 GHz) / RAM 9 GB / HDD 420 GB / Weight 5.6 kg / Intel HD Graphics / DVD+/-RW / LAN / WiFi / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 2030.00, 3, 1)
     , (279148, 'Dell EHD276104',
        'Monitor 11" / Intel Core I3 (2.0 GHz) / RAM 6 GB / HDD 770 GB / Weight 5.4 kg / DVD+/-RW / LAN / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 1330.00, 3, 1)
     , (279150, 'AirOn BL897396',
        'Monitor diagonal 1.4" / RAM: 512 Mb / Silver / 1200 mA/h / Weight 260 g / USB / Dictophone / WiFi / GPS',
        '/media/736d6172747761746368.jpg', 1080.00, 6, 11)
     , (279160, 'Sony MQ91841371',
        'Memory 8 Gb / Weight 62 g / Orange / MP3 / USB / FM receiver / Bluetooth / AMV / AVI / Dictophone / MPEG-4',
        '/media/6d70332d706c61796572.jpg', 2360.00, 2, 8)
     , (279162, 'Acer AJM00938',
        'Monitor 7" / RAM 2 GB / HDD 780 GB / White / Weight 180 g / Bluetooth / HDMI / WiFi / Webcam / USB / 3G',
        '/media/7461626c6574.jpg', 2750.00, 7, 14)
     , (279172, 'EvroMedia KJJ62800912',
        'Monitor diagonal 8" / Matrix type: E lnk / Resolution: 1200x800 / Memory 5 GB / Weight 200 g',
        '/media/652d626f6f6b.jpg', 1730.00, 1, 12)
     , (279176, 'AirOn TQB40435',
        'Monitor diagonal 1.6" / RAM: 512 Mb / Silver / 1300 mA/h / Weight 300 g / WiFi / USB / Dictophone',
        '/media/736d6172747761746368.jpg', 2870.00, 6, 11)
     , (279182, 'LG TH6748331',
        'Monitor diagonal 2.2" / Camera: 1.8Mp / RAM 16 Mb / 1300 mA/h / Black / Weight 340 g / Dictophone / USB / SD',
        '/media/70686f6e65.jpg', 660.00, 4, 21)
     , (279189, 'Amazon VVT5827879',
        'Monitor diagonal 10" / Matrix type: E lnk / Resolution: 1024x758 / Memory 10 GB / Weight 155 g',
        '/media/652d626f6f6b.jpg', 1520.00, 1, 23)
     , (279197, 'Dell UPD25038', 'Monitor 9" / RAM 4 GB / HDD 470 GB / White / Weight 140 g / Webcam / 3G / USB / WiFi',
        '/media/7461626c6574.jpg', 2770.00, 7, 1)
     , (279203, 'Asus BTT61346065',
        'Monitor 9" / RAM 4 GB / HDD 680 GB / Orange / Weight 180 g / WiFi / GPS / USB / Webcam / 3G',
        '/media/7461626c6574.jpg', 340.00, 7, 13)
     , (279204, 'Nokia BRH98046970',
        'Monitor diagonal 3.8" / Camera: 4.0Mp / RAM: 2 Gb / White / 1000 mA/h / Weight 360 g / Bluetooth / 2 Sim cards / WiFi / FM receiver',
        '/media/736d61727470686f6e65.jpg', 300.00, 5, 25)
     , (279205, 'LG NTV1934',
        'Monitor diagonal 1.8" / Camera: 1.8Mp / RAM 32 Mb / 1600 mA/h / Black / Weight 380 g / Bluetooth / SD / USB',
        '/media/70686f6e65.jpg', 1100.00, 4, 21)
     , (279214, 'AirOn PP12096',
        'Monitor diagonal 1.2" / RAM: 512 Mb / Blue / 1900 mA/h / Weight 300 g / GPS / WiFi / USB',
        '/media/736d6172747761746368.jpg', 1500.00, 6, 11)
     , (279222, 'Samsung LLJ76964452',
        'Monitor diagonal 5.0" / Camera: 2.2Mp / RAM: 512 Mb / Black / 2000 mA/h / Weight 400 g / 2 Sim cards / 3G / USB / GPS / Bluetooth / Dictophone',
        '/media/736d61727470686f6e65.jpg', 2400.00, 5, 22)
     , (279229, 'Nokia FLT260897',
        'Monitor diagonal 3.2" / Camera: 3.2Mp / RAM: 2 Gb / Blue / 1000 mA/h / Weight 720 g / Bluetooth / GPS / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 1560.00, 5, 25)
     , (279231, 'Lenovo GFA78184',
        'Monitor 7" / RAM 4 GB / HDD 290 GB / Blue / Weight 260 g / Webcam / Bluetooth / 3G / WiFi',
        '/media/7461626c6574.jpg', 2050.00, 7, 9)
     , (279236, 'Samsung NU1015',
        'Monitor diagonal 2.0" / Camera: 2.2Mp / RAM 16 Mb / 1200 mA/h / Black / Weight 260 g / 2 Sim cards / USB / Bluetooth',
        '/media/70686f6e65.jpg', 750.00, 4, 22)
     , (279241, 'Sony DV6891',
        'Monitor diagonal 5.0" / Camera: 2.2Mp / RAM: 1 Gb / Silver / 1000 mA/h / Weight 440 g / WiFi / Bluetooth / USB',
        '/media/736d61727470686f6e65.jpg', 2510.00, 5, 8)
     , (279242, 'Nokia FQ1431',
        'Monitor diagonal 2.4" / Camera: 1Mp / RAM 32 Mb / 1800 mA/h / Blue / Weight 260 g / USB / 2 Sim cards / Dictophone',
        '/media/70686f6e65.jpg', 2430.00, 4, 25)
     , (279244, 'LG BGR015262',
        'Monitor diagonal 3.8" / Camera: 4.0Mp / RAM: 1 Gb / Black / 1400 mA/h / Weight 720 g / Bluetooth / GPS / WiFi',
        '/media/736d61727470686f6e65.jpg', 2070.00, 5, 21)
     , (279252, 'Prestigio SRK16186',
        'Monitor 9" / RAM 3 GB / HDD 150 GB / White / Weight 180 g / Webcam / WiFi / Bluetooth / 3G / GPS',
        '/media/7461626c6574.jpg', 1750.00, 7, 10)
     , (279257, 'Apple EM05082758',
        'Monitor 21" / Intel Core I5 (2.8 GHz) / RAM 8 GB / HDD 640 GB / Weight 3.0 kg / Intel HD Graphics / DVD+/-RW / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 330.00, 3, 15)
     , (279259, 'HTC FJN999242',
        'Monitor diagonal 4.4" / Camera: 2.2Mp / RAM: 512 Mb / Orange / 1600 mA/h / Weight 800 g / USB / Dictophone / WiFi',
        '/media/736d61727470686f6e65.jpg', 2390.00, 5, 19)
     , (279260, 'Apple VN77642298', 'Memory 20 Gb / Weight 71 g / Silver / MP3 / AVI / USB / WMA',
        '/media/6d70332d706c61796572.jpg', 400.00, 2, 15)
     , (279264, 'Samsung SU70521770',
        'Monitor diagonal 4.4" / Camera: 3.0Mp / RAM: 1 Gb / Silver / 1100 mA/h / Weight 760 g / FM receiver / WiFi / 2 Sim cards / Bluetooth / GPS / Dictophone',
        '/media/736d61727470686f6e65.jpg', 10.00, 5, 22)
     , (279269, 'Samsung GP358940',
        'Monitor diagonal 3.0" / Camera: 2.2Mp / RAM 32 Mb / 1400 mA/h / Silver / Weight 160 g / USB / Dictophone / 2 Sim cards',
        '/media/70686f6e65.jpg', 2860.00, 4, 22)
     , (279278, 'Dell MO965658',
        'Monitor 11" / Intel Core I3 (2.2 GHz) / RAM 14 GB / HDD 200 GB / Weight 4.2 kg / HDMI / Intel HD Graphics / WiFi / Bluetooth',
        '/media/6e6f7465626f6f6b.jpg', 2250.00, 3, 1)
     , (279284, 'Lenovo EHT3129',
        'Monitor 14" / Intel Core I7 (3.0 GHz) / RAM 15 GB / HDD 790 GB / Weight 3.2 kg / WiFi / Intel HD Graphics / USB / Bluetooth / Webcam / LAN / HDMI',
        '/media/6e6f7465626f6f6b.jpg', 2620.00, 3, 9)
     , (279293, 'Lenovo DUK5412',
        'Monitor 7" / RAM 2 GB / HDD 750 GB / Silver / Weight 300 g / 3G / WiFi / GPS / Webcam',
        '/media/7461626c6574.jpg', 890.00, 7, 9)
     , (279303, 'Apple NSI8160811',
        'Monitor diagonal 1.1" / RAM: 1 Gb / Orange / 1400 mA/h / Weight 100 g / GPS / Bluetooth / WiFi',
        '/media/736d6172747761746368.jpg', 580.00, 6, 15)
     , (279304, 'HTC RM7582',
        'Monitor diagonal 6.0" / Camera: 3.2Mp / RAM: 4 Gb / Orange / 1700 mA/h / Weight 600 g / 2 Sim cards / USB / 3G',
        '/media/736d61727470686f6e65.jpg', 1340.00, 5, 19)
     , (279305, 'Acer KC12472986',
        'Monitor 17" / Intel Core I5 (2.8 GHz) / RAM 4 GB / HDD 400 GB / Weight 4.4 kg / WiFi / Intel HD Graphics / DVD+/-RW / LAN / HDMI / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 2550.00, 3, 14)
     , (279315, 'Samsung SEI091257',
        'Monitor diagonal 5.0" / Camera: 2.2Mp / RAM: 2 Gb / White / 1600 mA/h / Weight 640 g / Bluetooth / USB / GPS',
        '/media/736d61727470686f6e65.jpg', 2440.00, 5, 22)
     , (279325, 'EvroMedia FO0274203',
        'Monitor diagonal 7" / Matrix type: E lnk Carta / Resolution: 800x600 / Memory 9 GB / Weight 160 g',
        '/media/652d626f6f6b.jpg', 2850.00, 1, 12)
     , (279331, 'Prestigio TGA3972',
        'Monitor 8" / RAM 2 GB / HDD 710 GB / Orange / Weight 140 g / GPS / WiFi / 3G / HDMI',
        '/media/7461626c6574.jpg', 100.00, 7, 10)
     , (279341, 'Dell MQF218961',
        'Monitor 7" / RAM 1 GB / HDD 190 GB / Blue / Weight 260 g / HDMI / Bluetooth / WiFi / GPS',
        '/media/7461626c6574.jpg', 100.00, 7, 1)
     , (279350, 'Apple UEQ439105',
        'Monitor 21" / Intel Core I7 (3.2 GHz) / RAM 5 GB / HDD 220 GB / Weight 5.2 kg / Intel HD Graphics / USB / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 1390.00, 3, 15)
     , (279357, 'EvroMedia PHG06601',
        'Monitor diagonal 8" / Matrix type: E lnk Carta / Resolution: 1024x758 / Memory 5 GB / Weight 165 g',
        '/media/652d626f6f6b.jpg', 580.00, 1, 12)
     , (279358, 'Dell GC67939181', 'Monitor 8" / RAM 2 GB / HDD 130 GB / Silver / Weight 180 g / Webcam / HDMI / GPS',
        '/media/7461626c6574.jpg', 940.00, 7, 1)
     , (279359, 'Samsung RM51354564',
        'Monitor diagonal 6.0" / Camera: 4.0Mp / RAM: 2 Gb / Orange / 1700 mA/h / Weight 400 g / FM receiver / WiFi / GPS',
        '/media/736d61727470686f6e65.jpg', 700.00, 5, 22)
     , (279365, 'Dell OCB02465531',
        'Monitor 7" / RAM 3 GB / HDD 760 GB / Black / Weight 260 g / USB / Bluetooth / WiFi', '/media/7461626c6574.jpg',
        750.00, 7, 1)
     , (279366, 'Asus UFI99956669', 'Monitor 7" / RAM 2 GB / HDD 550 GB / Blue / Weight 180 g / Bluetooth / HDMI / USB',
        '/media/7461626c6574.jpg', 1200.00, 7, 13)
     , (279376, 'Samsung IJ502217', 'Monitor 7" / RAM 3 GB / HDD 310 GB / Blue / Weight 60 g / 3G / Bluetooth / HDMI',
        '/media/7461626c6574.jpg', 630.00, 7, 22)
     , (279379, 'HP SN73700',
        'Monitor 20" / Intel Core I3 (2.4 GHz) / RAM 4 GB / HDD 550 GB / Weight 2.8 kg / DVD+/-RW / Webcam / HDMI',
        '/media/6e6f7465626f6f6b.jpg', 320.00, 3, 3)
     , (279380, 'Lenovo GDS39892821',
        'Monitor 20" / Intel Core I7 (2.0 GHz) / RAM 5 GB / HDD 290 GB / Weight 6.6 kg / Intel HD Graphics / DVD+/-RW / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 530.00, 3, 9)
     , (279388, 'Gigabyte OPN68821',
        'Monitor diagonal 2.2" / Camera: 2.2Mp / RAM 48 Mb / 1000 mA/h / Orange / Weight 320 g / USB / Bluetooth / Dictophone / 2 Sim cards',
        '/media/70686f6e65.jpg', 2810.00, 4, 4)
     , (279395, 'Dell UIL0640',
        'Monitor 18" / Intel Core I3 (2.0 GHz) / RAM 11 GB / HDD 570 GB / Weight 3.8 kg / Bluetooth / USB / WiFi',
        '/media/6e6f7465626f6f6b.jpg', 2050.00, 3, 1)
     , (279405, 'Samsung CF4585262',
        'Monitor diagonal 1.8" / RAM: 512 Mb / Black / 1900 mA/h / Weight 60 g / Dictophone / USB / WiFi',
        '/media/736d6172747761746368.jpg', 2680.00, 6, 22)
     , (279407, 'PocketBook IV4413',
        'Monitor diagonal 10" / Matrix type: E lnk Pearl / Resolution: 1200x800 / Memory 10 GB / Weight 200 g',
        '/media/652d626f6f6b.jpg', 440.00, 1, 17)
     , (279410, 'EvroMedia BR9020015',
        'Monitor diagonal 11" / Matrix type: E lnk Pearl / Resolution: 800x600 / Memory 11 GB / Weight 180 g',
        '/media/652d626f6f6b.jpg', 1860.00, 1, 12)
     , (279414, 'AirBook MOO310916',
        'Monitor diagonal 11" / Matrix type: E lnk Pearl / Resolution: 1024x758 / Memory 10 GB / Weight 185 g',
        '/media/652d626f6f6b.jpg', 100.00, 1, 20)
     , (279419, 'PocketBook PC6093023',
        'Monitor diagonal 11" / Matrix type: E lnk Carta / Resolution: 1200x800 / Memory 12 GB / Weight 180 g',
        '/media/652d626f6f6b.jpg', 290.00, 1, 17)
     , (279423, 'Asus QV00648279',
        'Monitor 14" / Intel Core I3 (2.2 GHz) / RAM 9 GB / HDD 200 GB / Weight 4.6 kg / Webcam / LAN / WiFi',
        '/media/6e6f7465626f6f6b.jpg', 2940.00, 3, 13)
     , (279426, 'Asus NV41508',
        'Monitor 7" / RAM 4 GB / HDD 290 GB / Blue / Weight 60 g / GPS / HDMI / Bluetooth / Webcam',
        '/media/7461626c6574.jpg', 1410.00, 7, 13)
     , (279428, 'Nokia NGO914019',
        'Monitor diagonal 5.0" / Camera: 2.2Mp / RAM: 512 Mb / Blue / 1000 mA/h / Weight 440 g / 3G / GPS / Bluetooth / 2 Sim cards / FM receiver',
        '/media/736d61727470686f6e65.jpg', 1670.00, 5, 25)
     , (279429, 'Nokia MEA088240',
        'Monitor diagonal 3.2" / Camera: 3.2Mp / RAM: 1 Gb / Blue / 1800 mA/h / Weight 640 g / Dictophone / GPS / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 1670.00, 5, 25)
     , (279431, 'FixiTime IA03818',
        'Monitor diagonal 1.7" / RAM: 512 Mb / Orange / 1600 mA/h / Weight 180 g / WiFi / Dictophone / USB / Bluetooth',
        '/media/736d6172747761746368.jpg', 2280.00, 6, 16)
     , (279432, 'Asus HGC626631',
        'Monitor 8" / RAM 4 GB / HDD 170 GB / Black / Weight 60 g / Webcam / HDMI / WiFi / GPS / 3G',
        '/media/7461626c6574.jpg', 1590.00, 7, 13)
     , (279439, 'Fly QN413182',
        'Monitor diagonal 3.8" / Camera: 4.0Mp / RAM: 4 Gb / Black / 1300 mA/h / Weight 440 g / Dictophone / 3G / FM receiver / USB / WiFi / 2 Sim cards / GPS',
        '/media/736d61727470686f6e65.jpg', 2150.00, 5, 7)
     , (279443, 'Samsung GO06292243',
        'Monitor diagonal 2.6" / Camera: 2.6Mp / RAM 64 Mb / 1400 mA/h / Orange / Weight 220 g / 2 Sim cards / USB / SD',
        '/media/70686f6e65.jpg', 2280.00, 4, 22)
     , (279450, 'HTC OJR502975',
        'Monitor diagonal 4.4" / Camera: 3.0Mp / RAM: 4 Gb / White / 1200 mA/h / Weight 360 g / GPS / USB / 3G / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 40.00, 5, 19)
     , (279452, 'Acer ML4177',
        'Monitor 17" / Intel Core I3 (2.6 GHz) / RAM 10 GB / HDD 110 GB / Weight 5.6 kg / Bluetooth / LAN / USB',
        '/media/6e6f7465626f6f6b.jpg', 1630.00, 3, 14)
     , (279458, 'Nokia CK55373',
        'Monitor diagonal 3.2" / Camera: 3.0Mp / RAM: 1 Gb / Black / 1100 mA/h / Weight 520 g / Dictophone / GPS / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 590.00, 5, 25)
     , (279466, 'LG RAB1296',
        'Monitor diagonal 2.0" / Camera: 1Mp / RAM 32 Mb / 1500 mA/h / White / Weight 60 g / USB / SD / 2 Sim cards / Bluetooth',
        '/media/70686f6e65.jpg', 2160.00, 4, 21)
     , (279475, 'AirOn BC8776',
        'Monitor diagonal 1.4" / RAM: 512 Mb / Black / 1300 mA/h / Weight 60 g / USB / Dictophone / WiFi',
        '/media/736d6172747761746368.jpg', 680.00, 6, 11)
     , (279485, 'FixiTime LUB46203840',
        'Monitor diagonal 1.3" / RAM: 512 Mb / Black / 1100 mA/h / Weight 300 g / Dictophone / GPS / WiFi / Bluetooth',
        '/media/736d6172747761746368.jpg', 350.00, 6, 16)
     , (279492, 'AirOn DE2782529',
        'Monitor diagonal 1.7" / RAM: 512 Mb / Blue / 1200 mA/h / Weight 220 g / GPS / WiFi / Dictophone',
        '/media/736d6172747761746368.jpg', 2230.00, 6, 11)
     , (279502, 'AirOn TV5586630',
        'Monitor diagonal 1.7" / RAM: 512 Mb / Orange / 1300 mA/h / Weight 60 g / WiFi / GPS / Dictophone / Bluetooth',
        '/media/736d6172747761746368.jpg', 1540.00, 6, 11)
     , (279503, 'Nokia GJ38397',
        'Monitor diagonal 5.6" / Camera: 3.0Mp / RAM: 1 Gb / Orange / 2000 mA/h / Weight 560 g / FM receiver / 3G / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 770.00, 5, 25)
     , (279504, 'Philips HD38703',
        'Monitor diagonal 3.0" / Camera: 1.8Mp / RAM 16 Mb / 1200 mA/h / Blue / Weight 260 g / Bluetooth / Dictophone / SD',
        '/media/70686f6e65.jpg', 2850.00, 4, 18)
     , (279513, 'Apple RCB537476', 'Memory 12 Gb / Weight 68 g / Blue / MP3 / MPEG-4 / OGG / Dictophone',
        '/media/6d70332d706c61796572.jpg', 980.00, 2, 15)
     , (279517, 'Gigabyte MM7660705',
        'Monitor diagonal 2.6" / Camera: 2.2Mp / RAM 32 Mb / 1100 mA/h / Black / Weight 60 g / USB / 2 Sim cards / Dictophone',
        '/media/70686f6e65.jpg', 570.00, 4, 4)
     , (279526, 'Lenovo MN3005529',
        'Monitor diagonal 3.2" / Camera: 3.0Mp / RAM: 1 Gb / Black / 1800 mA/h / Weight 680 g / Dictophone / Bluetooth / USB / WiFi / GPS',
        '/media/736d61727470686f6e65.jpg', 1970.00, 5, 9)
     , (279531, 'Lenovo DU90650',
        'Monitor diagonal 4.4" / Camera: 2.2Mp / RAM: 1 Gb / White / 1300 mA/h / Weight 520 g / USB / FM receiver / WiFi',
        '/media/736d61727470686f6e65.jpg', 330.00, 5, 9)
     , (279539, 'EvroMedia PB9120',
        'Monitor diagonal 6" / Matrix type: E lnk Pearl / Resolution: 1600x1200 / Memory 6 GB / Weight 200 g',
        '/media/652d626f6f6b.jpg', 1550.00, 1, 12)
     , (279541, 'Dell FJ957234',
        'Monitor 20" / Intel Core I7 (2.8 GHz) / RAM 14 GB / HDD 750 GB / Weight 6.2 kg / USB / Webcam / WiFi / Bluetooth',
        '/media/6e6f7465626f6f6b.jpg', 680.00, 3, 1)
     , (279550, 'Dell HG719529',
        'Monitor 11" / Intel Core I5 (2.2 GHz) / RAM 1 GB / HDD 470 GB / Weight 4.0 kg / WiFi / Intel HD Graphics / HDMI / Webcam / LAN / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 2670.00, 3, 1)
     , (279559, 'Apple HDF6985',
        'Monitor diagonal 5.0" / Camera: 4.0Mp / RAM: 2 Gb / Orange / 1300 mA/h / Weight 560 g / 3G / FM receiver / USB',
        '/media/736d61727470686f6e65.jpg', 2270.00, 5, 15)
     , (279566, 'Dell HMS18475',
        'Monitor 11" / Intel Core I5 (2.6 GHz) / RAM 11 GB / HDD 750 GB / Weight 3.2 kg / WiFi / LAN / DVD+/-RW / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 2960.00, 3, 1)
     , (279572, 'Acer QSL6227', 'Monitor 8" / RAM 2 GB / HDD 800 GB / Silver / Weight 220 g / 3G / Bluetooth / GPS',
        '/media/7461626c6574.jpg', 990.00, 7, 14)
     , (279579, 'LG GG0028717',
        'Monitor diagonal 3.2" / Camera: 3.0Mp / RAM: 4 Gb / Blue / 1400 mA/h / Weight 520 g / WiFi / 3G / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 1150.00, 5, 21)
     , (279585, 'Nokia VG2525928',
        'Monitor diagonal 3.8" / Camera: 2.2Mp / RAM: 512 Mb / White / 1900 mA/h / Weight 640 g / FM receiver / GPS / Dictophone',
        '/media/736d61727470686f6e65.jpg', 1770.00, 5, 25)
     , (279595, 'Prestigio IAE51364',
        'Monitor diagonal 2.4" / Camera: 2.2Mp / RAM 48 Mb / 1100 mA/h / Black / Weight 80 g / Bluetooth / Dictophone / SD',
        '/media/70686f6e65.jpg', 2480.00, 4, 10)
     , (279597, 'Samsung ML34343064',
        'Monitor diagonal 2.0" / Camera: 2.2Mp / RAM 16 Mb / 1400 mA/h / Blue / Weight 360 g / Bluetooth / USB / SD',
        '/media/70686f6e65.jpg', 1510.00, 4, 22)
     , (279603, 'AirOn TRJ43593',
        'Monitor diagonal 1.4" / RAM: 1 Gb / Black / 1500 mA/h / Weight 180 g / GPS / WiFi / USB',
        '/media/736d6172747761746368.jpg', 750.00, 6, 11)
     , (279606, 'Samsung UH399204', 'Monitor 7" / RAM 2 GB / HDD 790 GB / Blue / Weight 60 g / Bluetooth / 3G / GPS',
        '/media/7461626c6574.jpg', 230.00, 7, 22)
     , (279610, 'Amazon TM47360',
        'Monitor diagonal 9" / Matrix type: E lnk / Resolution: 1200x800 / Memory 11 GB / Weight 185 g',
        '/media/652d626f6f6b.jpg', 560.00, 1, 23)
     , (279615, 'AirOn JM265970',
        'Monitor diagonal 1.8" / RAM: 1 Gb / Black / 1600 mA/h / Weight 140 g / Dictophone / GPS / Bluetooth',
        '/media/736d6172747761746368.jpg', 1080.00, 6, 11)
     , (279622, 'Apple ODF33952892',
        'Memory 16 Gb / Weight 100 g / White / MP3 / AVI / WAV / Dictophone / Bluetooth / MPEG-4',
        '/media/6d70332d706c61796572.jpg', 2730.00, 2, 15)
     , (279629, 'Prestigio EGV46406',
        'Monitor 7" / RAM 4 GB / HDD 120 GB / Blue / Weight 100 g / Bluetooth / USB / Webcam / 3G / GPS',
        '/media/7461626c6574.jpg', 2930.00, 7, 10)
     , (279638, 'Asus BPN890134', 'Monitor 8" / RAM 1 GB / HDD 90 GB / Orange / Weight 260 g / GPS / HDMI / USB',
        '/media/7461626c6574.jpg', 550.00, 7, 13)
     , (279647, 'LG LLI633980',
        'Monitor diagonal 6.0" / Camera: 3.0Mp / RAM: 2 Gb / Black / 1700 mA/h / Weight 440 g / 3G / WiFi / Dictophone / 2 Sim cards / USB / FM receiver',
        '/media/736d61727470686f6e65.jpg', 2250.00, 5, 21)
     , (279652, 'LG KG8431641',
        'Monitor diagonal 5.0" / Camera: 3.2Mp / RAM: 2 Gb / Orange / 1600 mA/h / Weight 800 g / WiFi / GPS / FM receiver',
        '/media/736d61727470686f6e65.jpg', 510.00, 5, 21)
     , (279658, 'AirOn TV87445196',
        'Monitor diagonal 1.8" / RAM: 256 Mb / Blue / 1800 mA/h / Weight 260 g / GPS / Dictophone / USB',
        '/media/736d6172747761746368.jpg', 1800.00, 6, 11)
     , (279661, 'PocketBook RK4516',
        'Monitor diagonal 8" / Matrix type: E lnk / Resolution: 1600x1200 / Memory 12 GB / Weight 190 g',
        '/media/652d626f6f6b.jpg', 2500.00, 1, 17)
     , (279662, 'Dell PE21389',
        'Monitor 18" / Intel Core I3 (1.8 GHz) / RAM 11 GB / HDD 270 GB / Weight 3.4 kg / Intel HD Graphics / Webcam / HDMI / LAN / DVD+/-RW / WiFi / Bluetooth',
        '/media/6e6f7465626f6f6b.jpg', 1280.00, 3, 1)
     , (279666, 'Transcend FE2279', 'Memory 8 Gb / Weight 77 g / Silver / MP3 / WAV / Bluetooth / AMV',
        '/media/6d70332d706c61796572.jpg', 1630.00, 2, 5)
     , (279670, 'Amazon NFS87497',
        'Monitor diagonal 10" / Matrix type: E lnk Pearl / Resolution: 800x600 / Memory 6 GB / Weight 170 g',
        '/media/652d626f6f6b.jpg', 560.00, 1, 23)
     , (279671, 'Transcend LE7626351',
        'Memory 12 Gb / Weight 59 g / White / MP3 / Bluetooth / MPEG-4 / AMV / SD slot / FM receiver / Dictophone / AVI / WMA / WAV',
        '/media/6d70332d706c61796572.jpg', 620.00, 2, 5)
     , (279676, 'Dell UE19951', 'Monitor 9" / RAM 4 GB / HDD 80 GB / Blue / Weight 100 g / HDMI / 3G / GPS / USB',
        '/media/7461626c6574.jpg', 1670.00, 7, 1)
     , (279677, 'HP QR0612',
        'Monitor 21" / Intel Core I7 (2.2 GHz) / RAM 9 GB / HDD 800 GB / Weight 6.0 kg / DVD+/-RW / USB / HDMI / LAN / Bluetooth',
        '/media/6e6f7465626f6f6b.jpg', 1790.00, 3, 3)
     , (279684, 'Amazon HAU6383097',
        'Monitor diagonal 6" / Matrix type: E lnk / Resolution: 1600x1200 / Memory 10 GB / Weight 170 g',
        '/media/652d626f6f6b.jpg', 2620.00, 1, 23)
     , (279688, 'FiiO JTE4624715',
        'Memory 20 Gb / Weight 59 g / White / MP3 / WAV / WMA / USB / AMV / Bluetooth / FM receiver',
        '/media/6d70332d706c61796572.jpg', 1500.00, 2, 2)
     , (279695, 'Prestigio KP01253',
        'Monitor 8" / RAM 2 GB / HDD 530 GB / White / Weight 180 g / Bluetooth / WiFi / Webcam',
        '/media/7461626c6574.jpg', 130.00, 7, 10)
     , (279696, 'Prestigio IBM4526313',
        'Monitor diagonal 2.8" / Camera: 2.6Mp / RAM 64 Mb / 1500 mA/h / Orange / Weight 380 g / Dictophone / SD / USB / 2 Sim cards',
        '/media/70686f6e65.jpg', 2120.00, 4, 10)
     , (279704, 'LG HFQ261605',
        'Monitor diagonal 3.2" / Camera: 2.2Mp / RAM: 512 Mb / White / 1800 mA/h / Weight 320 g / 2 Sim cards / WiFi / Dictophone',
        '/media/736d61727470686f6e65.jpg', 1690.00, 5, 21)
     , (279713, 'LG LM84648547',
        'Monitor diagonal 3.2" / Camera: 2.2Mp / RAM: 4 Gb / Black / 1900 mA/h / Weight 400 g / FM receiver / Bluetooth / WiFi',
        '/media/736d61727470686f6e65.jpg', 700.00, 5, 21)
     , (279718, 'EvroMedia GJK86313370',
        'Monitor diagonal 9" / Matrix type: E lnk / Resolution: 800x600 / Memory 8 GB / Weight 170 g',
        '/media/652d626f6f6b.jpg', 180.00, 1, 12)
     , (279720, 'Transcend CHQ9462882', 'Memory 4 Gb / Weight 100 g / Blue / MP3 / MPEG-4 / OGG / SD slot',
        '/media/6d70332d706c61796572.jpg', 1890.00, 2, 5)
     , (279730, 'EvroMedia LL02656508',
        'Monitor diagonal 9" / Matrix type: E lnk Carta / Resolution: 1024x758 / Memory 6 GB / Weight 195 g',
        '/media/652d626f6f6b.jpg', 1570.00, 1, 12)
     , (279733, 'Samsung QN818861',
        'Monitor diagonal 1.6" / RAM: 256 Mb / White / 1300 mA/h / Weight 60 g / Bluetooth / WiFi / Dictophone',
        '/media/736d6172747761746368.jpg', 2720.00, 6, 22)
     , (279735, 'Prestigio UK59171',
        'Monitor 7" / RAM 2 GB / HDD 590 GB / Black / Weight 100 g / USB / Bluetooth / WiFi', '/media/7461626c6574.jpg',
        530.00, 7, 10)
     , (279739, 'Lenovo UGS004040', 'Monitor 8" / RAM 3 GB / HDD 550 GB / Orange / Weight 260 g / HDMI / 3G / Webcam',
        '/media/7461626c6574.jpg', 220.00, 7, 9)
     , (279745, 'Prestigio MF7396',
        'Monitor 9" / RAM 4 GB / HDD 380 GB / Silver / Weight 180 g / Bluetooth / GPS / Webcam',
        '/media/7461626c6574.jpg', 1750.00, 7, 10)
     , (279752, 'LG HR944204',
        'Monitor diagonal 1.8" / Camera: 2.6Mp / RAM 16 Mb / 1500 mA/h / White / Weight 160 g / USB / 2 Sim cards / Bluetooth',
        '/media/70686f6e65.jpg', 130.00, 4, 21)
     , (279754, 'HTC AG4121879',
        'Monitor diagonal 5.0" / Camera: 3.0Mp / RAM: 512 Mb / Orange / 1600 mA/h / Weight 440 g / 3G / 2 Sim cards / WiFi',
        '/media/736d61727470686f6e65.jpg', 740.00, 5, 19)
     , (279760, 'Dell RFT85879', 'Monitor 9" / RAM 3 GB / HDD 440 GB / Black / Weight 260 g / USB / WiFi / Webcam',
        '/media/7461626c6574.jpg', 2440.00, 7, 1)
     , (279767, 'Apple GQE09184',
        'Memory 4 Gb / Weight 56 g / White / MP3 / AVI / WAV / WMA / USB / AMV / FM receiver / MPEG-4 / OGG',
        '/media/6d70332d706c61796572.jpg', 2730.00, 2, 15)
     , (279774, 'LG MMF367185',
        'Monitor diagonal 5.6" / Camera: 3.2Mp / RAM: 4 Gb / Blue / 1600 mA/h / Weight 440 g / Dictophone / WiFi / USB',
        '/media/736d61727470686f6e65.jpg', 1010.00, 5, 21)
     , (279778, 'Jeka UBG83020', 'Memory 20 Gb / Weight 80 g / Blue / MP3 / USB / OGG / AMV',
        '/media/6d70332d706c61796572.jpg', 30.00, 2, 6)
     , (279784, 'Samsung LRP25349238',
        'Monitor diagonal 1.5" / RAM: 512 Mb / Silver / 1400 mA/h / Weight 220 g / Dictophone / Bluetooth / WiFi',
        '/media/736d6172747761746368.jpg', 630.00, 6, 22)
     , (279794, 'HTC AA44675303',
        'Monitor diagonal 5.0" / Camera: 2.2Mp / RAM: 4 Gb / Orange / 1500 mA/h / Weight 720 g / Bluetooth / FM receiver / USB',
        '/media/736d61727470686f6e65.jpg', 1150.00, 5, 19)
     , (279799, 'Nokia FL8022',
        'Monitor diagonal 2.4" / Camera: 2.2Mp / RAM 48 Mb / 1400 mA/h / Silver / Weight 260 g / 2 Sim cards / USB / Dictophone',
        '/media/70686f6e65.jpg', 1560.00, 4, 25)
     , (279800, 'Apple BUM416112',
        'Monitor 8" / RAM 4 GB / HDD 650 GB / Black / Weight 140 g / HDMI / GPS / USB / Webcam / Bluetooth / 3G',
        '/media/7461626c6574.jpg', 960.00, 7, 15)
     , (279801, 'Samsung QO0708',
        'Monitor diagonal 2.6" / Camera: 1.8Mp / RAM 48 Mb / 1100 mA/h / Blue / Weight 60 g / 2 Sim cards / USB / Dictophone / SD',
        '/media/70686f6e65.jpg', 840.00, 4, 22)
     , (279805, 'Lenovo UFR34839192',
        'Monitor 13" / Intel Core I5 (2.2 GHz) / RAM 11 GB / HDD 470 GB / Weight 2.4 kg / WiFi / USB / LAN / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 1710.00, 3, 9)
     , (279811, 'Prestigio OIL07662085',
        'Monitor diagonal 3.8" / Camera: 3.2Mp / RAM: 2 Gb / Orange / 1100 mA/h / Weight 800 g / USB / Bluetooth / 3G',
        '/media/736d61727470686f6e65.jpg', 990.00, 5, 10)
     , (279820, 'Philips VB14920645',
        'Monitor diagonal 2.8" / Camera: 2.2Mp / RAM 32 Mb / 1600 mA/h / Orange / Weight 340 g / SD / Dictophone / USB',
        '/media/70686f6e65.jpg', 580.00, 4, 18)
     , (279825, 'Jeka SNV291219',
        'Memory 4 Gb / Weight 26 g / Black / MP3 / OGG / AVI / SD slot / Bluetooth / USB / FM receiver',
        '/media/6d70332d706c61796572.jpg', 2280.00, 2, 6)
     , (279830, 'Dell ML157042',
        'Monitor 20" / Intel Core I7 (3.0 GHz) / RAM 10 GB / HDD 800 GB / Weight 6.0 kg / HDMI / Webcam / Bluetooth / LAN',
        '/media/6e6f7465626f6f6b.jpg', 1620.00, 3, 1)
     , (279837, 'Apple HIV6713',
        'Monitor 19" / Intel Core I3 (2.0 GHz) / RAM 7 GB / HDD 320 GB / Weight 6.0 kg / HDMI / USB / Bluetooth',
        '/media/6e6f7465626f6f6b.jpg', 1480.00, 3, 15)
     , (279847, 'Amazon RJ6595815',
        'Monitor diagonal 10" / Matrix type: E lnk Pearl / Resolution: 800x600 / Memory 12 GB / Weight 195 g',
        '/media/652d626f6f6b.jpg', 2690.00, 1, 23)
     , (279851, 'Apple POR67923', 'Monitor 7" / RAM 3 GB / HDD 520 GB / Black / Weight 100 g / Webcam / 3G / USB',
        '/media/7461626c6574.jpg', 130.00, 7, 15)
     , (279860, 'AirOn ILU98595',
        'Monitor diagonal 1.7" / RAM: 512 Mb / White / 1000 mA/h / Weight 220 g / WiFi / USB / GPS',
        '/media/736d6172747761746368.jpg', 1150.00, 6, 11)
     , (279861, 'Lenovo QLA7916166', 'Monitor 7" / RAM 3 GB / HDD 620 GB / Black / Weight 140 g / 3G / GPS / USB',
        '/media/7461626c6574.jpg', 2300.00, 7, 9)
     , (279865, 'Prestigio LEV3282964', 'Monitor 9" / RAM 2 GB / HDD 70 GB / White / Weight 300 g / HDMI / 3G / Webcam',
        '/media/7461626c6574.jpg', 1270.00, 7, 10)
     , (279868, 'Dell KMI64732',
        'Monitor 13" / Intel Core I7 (3.0 GHz) / RAM 1 GB / HDD 450 GB / Weight 5.0 kg / Bluetooth / USB / Intel HD Graphics / HDMI / Webcam / WiFi / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 880.00, 3, 1)
     , (279878, 'AirOn DRE58489685',
        'Monitor diagonal 1.6" / RAM: 1 Gb / White / 1000 mA/h / Weight 140 g / Bluetooth / Dictophone / USB',
        '/media/736d6172747761746368.jpg', 300.00, 6, 11)
     , (279882, 'Apple JN451403',
        'Monitor diagonal 3.2" / Camera: 4.0Mp / RAM: 2 Gb / Blue / 1100 mA/h / Weight 560 g / WiFi / FM receiver / Dictophone / USB / GPS / 3G / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 1260.00, 5, 15)
     , (279889, 'Sony OQV2064',
        'Monitor diagonal 4.4" / Camera: 4.0Mp / RAM: 1 Gb / Silver / 1600 mA/h / Weight 320 g / Bluetooth / 2 Sim cards / WiFi',
        '/media/736d61727470686f6e65.jpg', 1020.00, 5, 8)
     , (279896, 'Lenovo UCA0238', 'Monitor 9" / RAM 2 GB / HDD 140 GB / White / Weight 140 g / WiFi / USB / HDMI',
        '/media/7461626c6574.jpg', 1430.00, 7, 9)
     , (279901, 'Nokia MGB0184265',
        'Monitor diagonal 5.6" / Camera: 2.2Mp / RAM: 512 Mb / Silver / 1800 mA/h / Weight 480 g / 2 Sim cards / GPS / 3G',
        '/media/736d61727470686f6e65.jpg', 700.00, 5, 25)
     , (279905, 'LG SO9296656',
        'Monitor diagonal 4.4" / Camera: 2.2Mp / RAM: 2 Gb / Black / 1300 mA/h / Weight 400 g / 3G / Dictophone / USB / GPS',
        '/media/736d61727470686f6e65.jpg', 2640.00, 5, 21)
     , (279906, 'Lenovo JJO33352',
        'Monitor 16" / Intel Core I5 (2.4 GHz) / RAM 7 GB / HDD 180 GB / Weight 4.6 kg / USB / LAN / HDMI / WiFi / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 2250.00, 3, 9)
     , (279910, 'Nokia SQT04944021',
        'Monitor diagonal 4.4" / Camera: 4.0Mp / RAM: 512 Mb / Blue / 1100 mA/h / Weight 600 g / 2 Sim cards / FM receiver / 3G / WiFi / Dictophone / Bluetooth / USB',
        '/media/736d61727470686f6e65.jpg', 2520.00, 5, 25)
     , (279912, 'LG NVD11123',
        'Monitor diagonal 3.2" / Camera: 2.2Mp / RAM: 512 Mb / Orange / 1300 mA/h / Weight 440 g / FM receiver / USB / GPS',
        '/media/736d61727470686f6e65.jpg', 250.00, 5, 21)
     , (279921, 'HTC PU33697',
        'Monitor diagonal 3.2" / Camera: 4.0Mp / RAM: 1 Gb / Silver / 1400 mA/h / Weight 400 g / Bluetooth / WiFi / Dictophone / GPS / FM receiver',
        '/media/736d61727470686f6e65.jpg', 1600.00, 5, 19)
     , (279925, 'Gigabyte MDU8648',
        'Monitor diagonal 2.2" / Camera: 1Mp / RAM 64 Mb / 1300 mA/h / White / Weight 260 g / 2 Sim cards / Dictophone / Bluetooth',
        '/media/70686f6e65.jpg', 1190.00, 4, 4)
     , (279927, 'Gigabyte HJ42481016',
        'Monitor diagonal 2.8" / Camera: 2.6Mp / RAM 32 Mb / 1800 mA/h / White / Weight 280 g / Bluetooth / 2 Sim cards / Dictophone / SD',
        '/media/70686f6e65.jpg', 1110.00, 4, 4)
     , (279937, 'Philips KK7675',
        'Monitor diagonal 2.6" / Camera: 2.6Mp / RAM 16 Mb / 1200 mA/h / White / Weight 340 g / USB / Bluetooth / Dictophone',
        '/media/70686f6e65.jpg', 1490.00, 4, 18)
     , (279944, 'LG CF3239',
        'Monitor diagonal 2.8" / Camera: 2.6Mp / RAM 32 Mb / 2000 mA/h / Orange / Weight 240 g / SD / Bluetooth / USB',
        '/media/70686f6e65.jpg', 2930.00, 4, 21)
     , (279953, 'Jeka NVJ2497229',
        'Memory 8 Gb / Weight 32 g / Black / MP3 / AMV / WAV / AVI / MPEG-4 / USB / FM receiver',
        '/media/6d70332d706c61796572.jpg', 2110.00, 2, 6)
     , (279954, 'Samsung LDK54509868',
        'Monitor diagonal 6.0" / Camera: 3.0Mp / RAM: 1 Gb / Orange / 2000 mA/h / Weight 560 g / WiFi / FM receiver / GPS',
        '/media/736d61727470686f6e65.jpg', 2960.00, 5, 22)
     , (279957, 'Apple JKM79969160', 'Memory 8 Gb / Weight 56 g / Orange / MP3 / AVI / WAV / USB',
        '/media/6d70332d706c61796572.jpg', 2690.00, 2, 15)
     , (279967, 'Samsung NP69651637',
        'Monitor 8" / RAM 3 GB / HDD 730 GB / Black / Weight 180 g / USB / HDMI / 3G / GPS', '/media/7461626c6574.jpg',
        280.00, 7, 22)
     , (279973, 'Lenovo IB9524933',
        'Monitor 16" / Intel Core I3 (2.0 GHz) / RAM 4 GB / HDD 760 GB / Weight 5.8 kg / WiFi / USB / HDMI / DVD+/-RW / Intel HD Graphics / LAN',
        '/media/6e6f7465626f6f6b.jpg', 2780.00, 3, 9)
     , (279982, 'EvroMedia OIJ75385376',
        'Monitor diagonal 6" / Matrix type: E lnk Carta / Resolution: 1024x758 / Memory 6 GB / Weight 175 g',
        '/media/652d626f6f6b.jpg', 2950.00, 1, 12)
     , (279991, 'HP PID929839',
        'Monitor 23" / Intel Core I7 (3.2 GHz) / RAM 2 GB / HDD 240 GB / Weight 5.0 kg / LAN / Bluetooth / USB / WiFi / DVD+/-RW / HDMI',
        '/media/6e6f7465626f6f6b.jpg', 200.00, 3, 3)
     , (279992, 'Samsung JBH01985',
        'Monitor diagonal 2.0" / Camera: 2.2Mp / RAM 32 Mb / 1100 mA/h / Silver / Weight 180 g / 2 Sim cards / SD / USB',
        '/media/70686f6e65.jpg', 1500.00, 4, 22)
     , (280000, 'Prestigio QHT5646',
        'Monitor diagonal 1.8" / Camera: 2.2Mp / RAM 64 Mb / 1400 mA/h / White / Weight 160 g / USB / 2 Sim cards / Bluetooth',
        '/media/70686f6e65.jpg', 1970.00, 4, 10)
     , (280002, 'FiiO UT5340', 'Memory 8 Gb / Weight 77 g / White / MP3 / AMV / MPEG-4 / OGG',
        '/media/6d70332d706c61796572.jpg', 0.00, 2, 2)
     , (280004, 'Samsung TCI8484',
        'Monitor diagonal 2.0" / Camera: 2.6Mp / RAM 64 Mb / 1900 mA/h / Orange / Weight 340 g / 2 Sim cards / Bluetooth / SD',
        '/media/70686f6e65.jpg', 2920.00, 4, 22)
     , (280007, 'Amazon OBJ88041280',
        'Monitor diagonal 11" / Matrix type: E lnk Carta / Resolution: 1024x758 / Memory 6 GB / Weight 155 g',
        '/media/652d626f6f6b.jpg', 2700.00, 1, 23)
     , (280015, 'LG HO4993',
        'Monitor diagonal 3.8" / Camera: 3.0Mp / RAM: 2 Gb / White / 1800 mA/h / Weight 520 g / WiFi / FM receiver / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 150.00, 5, 21)
     , (280025, 'Philips IG54025',
        'Monitor diagonal 2.8" / Camera: 2.2Mp / RAM 32 Mb / 1800 mA/h / Silver / Weight 180 g / USB / SD / 2 Sim cards',
        '/media/70686f6e65.jpg', 150.00, 4, 18)
     , (280029, 'AirOn CH79260356',
        'Monitor diagonal 1.8" / RAM: 512 Mb / Orange / 2000 mA/h / Weight 60 g / WiFi / Dictophone / Bluetooth',
        '/media/736d6172747761746368.jpg', 490.00, 6, 11)
     , (280035, 'Prestigio PO07959265',
        'Monitor 10" / RAM 3 GB / HDD 230 GB / Black / Weight 180 g / Bluetooth / WiFi / GPS',
        '/media/7461626c6574.jpg', 2870.00, 7, 10)
     , (280043, 'Samsung CTQ429333',
        'Monitor diagonal 2.0" / Camera: 1Mp / RAM 48 Mb / 2000 mA/h / White / Weight 240 g / SD / Bluetooth / Dictophone',
        '/media/70686f6e65.jpg', 1430.00, 4, 22)
     , (280050, 'Dell JN7942271', 'Monitor 10" / RAM 2 GB / HDD 760 GB / Blue / Weight 220 g / 3G / GPS / HDMI',
        '/media/7461626c6574.jpg', 1080.00, 7, 1)
     , (280054, 'Nokia LUF12364660',
        'Monitor diagonal 4.4" / Camera: 4.0Mp / RAM: 2 Gb / White / 1600 mA/h / Weight 400 g / Bluetooth / FM receiver / 3G',
        '/media/736d61727470686f6e65.jpg', 2000.00, 5, 25)
     , (280059, 'LG KJ39157',
        'Monitor diagonal 4.4" / Camera: 2.2Mp / RAM: 512 Mb / Silver / 1300 mA/h / Weight 560 g / 2 Sim cards / Dictophone / 3G / FM receiver / USB / WiFi',
        '/media/736d61727470686f6e65.jpg', 380.00, 5, 21)
     , (280063, 'LG VNQ12479',
        'Monitor diagonal 3.0" / Camera: 1Mp / RAM 48 Mb / 2000 mA/h / White / Weight 120 g / USB / Dictophone / Bluetooth',
        '/media/70686f6e65.jpg', 1950.00, 4, 21)
     , (280066, 'Dell FP492939', 'Monitor 9" / RAM 1 GB / HDD 150 GB / Silver / Weight 180 g / USB / WiFi / 3G',
        '/media/7461626c6574.jpg', 2880.00, 7, 1)
     , (280074, 'Lenovo QTK5155',
        'Monitor diagonal 5.6" / Camera: 3.0Mp / RAM: 1 Gb / Orange / 1600 mA/h / Weight 440 g / FM receiver / Dictophone / 2 Sim cards / WiFi / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 1260.00, 5, 9)
     , (280083, 'LG NI84691470',
        'Monitor diagonal 4.4" / Camera: 4.0Mp / RAM: 512 Mb / White / 1800 mA/h / Weight 800 g / Bluetooth / WiFi / 3G / Dictophone / FM receiver / USB',
        '/media/736d61727470686f6e65.jpg', 1100.00, 5, 21)
     , (280084, 'Apple LEK30171021',
        'Monitor 18" / Intel Core I3 (2.0 GHz) / RAM 14 GB / HDD 620 GB / Weight 5.8 kg / Webcam / Bluetooth / WiFi / USB / LAN / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 2340.00, 3, 15)
     , (280088, 'Lenovo ES81748414',
        'Monitor 7" / RAM 1 GB / HDD 400 GB / Black / Weight 100 g / GPS / Bluetooth / USB', '/media/7461626c6574.jpg',
        1840.00, 7, 9)
     , (280095, 'Jeka BR5896572',
        'Memory 8 Gb / Weight 50 g / Blue / MP3 / SD slot / USB / MPEG-4 / AVI / OGG / AMV / FM receiver / WAV / Bluetooth',
        '/media/6d70332d706c61796572.jpg', 1840.00, 2, 6)
     , (280099, 'Asus NE8310', 'Monitor 10" / RAM 2 GB / HDD 800 GB / Black / Weight 60 g / WiFi / 3G / USB',
        '/media/7461626c6574.jpg', 470.00, 7, 13)
     , (280102, 'Apple QG94817',
        'Memory 8 Gb / Weight 41 g / White / MP3 / FM receiver / USB / OGG / Bluetooth / Dictophone / SD slot / AVI / MPEG-4 / WAV',
        '/media/6d70332d706c61796572.jpg', 2840.00, 2, 15)
     , (280111, 'Prestigio MFM56644967',
        'Monitor 7" / RAM 3 GB / HDD 380 GB / Orange / Weight 180 g / USB / WiFi / HDMI / Webcam',
        '/media/7461626c6574.jpg', 1380.00, 7, 10)
     , (280120, 'Gigabyte VVE772897',
        'Monitor diagonal 2.4" / Camera: 1Mp / RAM 32 Mb / 1200 mA/h / Silver / Weight 260 g / Bluetooth / USB / 2 Sim cards',
        '/media/70686f6e65.jpg', 2900.00, 4, 4)
     , (280130, 'Apple SA1684975',
        'Monitor 9" / RAM 1 GB / HDD 250 GB / Silver / Weight 260 g / WiFi / Webcam / GPS / USB',
        '/media/7461626c6574.jpg', 2500.00, 7, 15)
     , (280138, 'Jeka JSD01027098',
        'Memory 20 Gb / Weight 44 g / Silver / MP3 / Dictophone / WAV / SD slot / USB / MPEG-4 / OGG / Bluetooth',
        '/media/6d70332d706c61796572.jpg', 1310.00, 2, 6)
     , (280139, 'Nokia VN88491',
        'Monitor diagonal 3.2" / Camera: 4.0Mp / RAM: 4 Gb / Silver / 1700 mA/h / Weight 760 g / WiFi / 3G / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 2970.00, 5, 25)
     , (280146, 'Philips MDE849967',
        'Monitor diagonal 1.8" / Camera: 2.6Mp / RAM 64 Mb / 1000 mA/h / Silver / Weight 160 g / Dictophone / SD / 2 Sim cards',
        '/media/70686f6e65.jpg', 2080.00, 4, 18)
     , (280152, 'Gigabyte NH04843251',
        'Monitor diagonal 3.0" / Camera: 1.8Mp / RAM 64 Mb / 1600 mA/h / Blue / Weight 100 g / Bluetooth / 2 Sim cards / USB',
        '/media/70686f6e65.jpg', 1800.00, 4, 4)
     , (280155, 'Lenovo TG938383',
        'Monitor 9" / RAM 1 GB / HDD 450 GB / Blue / Weight 260 g / 3G / USB / HDMI / Bluetooth',
        '/media/7461626c6574.jpg', 700.00, 7, 9)
     , (280158, 'Amazon QE11232',
        'Monitor diagonal 10" / Matrix type: E lnk Pearl / Resolution: 800x600 / Memory 9 GB / Weight 195 g',
        '/media/652d626f6f6b.jpg', 1060.00, 1, 23)
     , (280160, 'Sony IIN68694438',
        'Monitor diagonal 5.0" / Camera: 3.2Mp / RAM: 2 Gb / Black / 1500 mA/h / Weight 600 g / FM receiver / GPS / 3G / Dictophone / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 220.00, 5, 8)
     , (280166, 'Asus CAF32961',
        'Monitor 13" / Intel Core I7 (2.6 GHz) / RAM 12 GB / HDD 790 GB / Weight 3.0 kg / Webcam / LAN / HDMI / USB / WiFi',
        '/media/6e6f7465626f6f6b.jpg', 1510.00, 3, 13)
     , (280174, 'Philips GS2164908',
        'Monitor diagonal 2.4" / Camera: 2.6Mp / RAM 16 Mb / 1800 mA/h / Blue / Weight 400 g / Dictophone / USB / 2 Sim cards',
        '/media/70686f6e65.jpg', 2670.00, 4, 18)
     , (280179, 'Amazon LF55027',
        'Monitor diagonal 12" / Matrix type: E lnk Carta / Resolution: 800x600 / Memory 4 GB / Weight 170 g',
        '/media/652d626f6f6b.jpg', 2890.00, 1, 23)
     , (280182, 'Apple PF8267',
        'Monitor 8" / RAM 1 GB / HDD 540 GB / Orange / Weight 100 g / WiFi / HDMI / Bluetooth / Webcam / GPS',
        '/media/7461626c6574.jpg', 2800.00, 7, 15)
     , (280189, 'Prestigio AFM5135050',
        'Monitor 8" / RAM 4 GB / HDD 360 GB / Orange / Weight 180 g / HDMI / GPS / Bluetooth / Webcam / 3G',
        '/media/7461626c6574.jpg', 2790.00, 7, 10)
     , (280199, 'Nokia AFN469239',
        'Monitor diagonal 5.6" / Camera: 3.0Mp / RAM: 512 Mb / Silver / 1500 mA/h / Weight 560 g / USB / Bluetooth / 2 Sim cards / GPS / WiFi',
        '/media/736d61727470686f6e65.jpg', 110.00, 5, 25)
     , (280200, 'Lenovo QM7728880',
        'Monitor 17" / Intel Core I7 (2.6 GHz) / RAM 14 GB / HDD 510 GB / Weight 2.8 kg / WiFi / Bluetooth / Webcam / Intel HD Graphics / DVD+/-RW / LAN / HDMI',
        '/media/6e6f7465626f6f6b.jpg', 270.00, 3, 9)
     , (280210, 'Samsung NBL1401564',
        'Monitor 9" / RAM 2 GB / HDD 690 GB / White / Weight 300 g / 3G / Bluetooth / WiFi', '/media/7461626c6574.jpg',
        160.00, 7, 22)
     , (280216, 'EvroMedia JU74729',
        'Monitor diagonal 9" / Matrix type: E lnk Pearl / Resolution: 1200x800 / Memory 7 GB / Weight 175 g',
        '/media/652d626f6f6b.jpg', 950.00, 1, 12)
     , (280219, 'Dell IO1119', 'Monitor 8" / RAM 3 GB / HDD 770 GB / Black / Weight 260 g / GPS / 3G / USB / WiFi',
        '/media/7461626c6574.jpg', 1530.00, 7, 1)
     , (280221, 'Apple ML2132',
        'Monitor 15" / Intel Core I3 (2.4 GHz) / RAM 15 GB / HDD 350 GB / Weight 3.8 kg / Bluetooth / LAN / WiFi',
        '/media/6e6f7465626f6f6b.jpg', 2830.00, 3, 15)
     , (280224, 'Sony EVC642437',
        'Monitor diagonal 3.8" / Camera: 3.0Mp / RAM: 4 Gb / Orange / 1500 mA/h / Weight 760 g / Dictophone / WiFi / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 170.00, 5, 8)
     , (280228, 'Samsung GOM42387', 'Monitor 7" / RAM 1 GB / HDD 690 GB / White / Weight 140 g / WiFi / HDMI / GPS',
        '/media/7461626c6574.jpg', 880.00, 7, 22)
     , (280235, 'Gigabyte LSB601965',
        'Monitor diagonal 1.8" / Camera: 2.6Mp / RAM 48 Mb / 1700 mA/h / Orange / Weight 200 g / Bluetooth / 2 Sim cards / USB',
        '/media/70686f6e65.jpg', 2230.00, 4, 4)
     , (280244, 'Dell NP3596',
        'Monitor 11" / Intel Core I3 (1.6 GHz) / RAM 12 GB / HDD 680 GB / Weight 3.0 kg / Bluetooth / USB / WiFi / LAN / HDMI / Intel HD Graphics / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 2090.00, 3, 1)
     , (280245, 'AirOn UUR642277',
        'Monitor diagonal 1.7" / RAM: 256 Mb / Blue / 1200 mA/h / Weight 140 g / Bluetooth / GPS / Dictophone / WiFi',
        '/media/736d6172747761746368.jpg', 2470.00, 6, 11)
     , (280249, 'Dell UK231019',
        'Monitor 10" / RAM 3 GB / HDD 370 GB / Blue / Weight 300 g / GPS / Webcam / USB / Bluetooth / 3G / WiFi',
        '/media/7461626c6574.jpg', 330.00, 7, 1)
     , (280250, 'Samsung KT78991', 'Monitor 9" / RAM 4 GB / HDD 140 GB / Black / Weight 60 g / Bluetooth / GPS / HDMI',
        '/media/7461626c6574.jpg', 1180.00, 7, 22)
     , (280255, 'Prestigio UKC8381084',
        'Monitor diagonal 2.0" / Camera: 2.6Mp / RAM 48 Mb / 1700 mA/h / Black / Weight 120 g / USB / SD / Bluetooth',
        '/media/70686f6e65.jpg', 1110.00, 4, 10)
     , (280257, 'Amazon GQ8384',
        'Monitor diagonal 10" / Matrix type: E lnk / Resolution: 800x600 / Memory 6 GB / Weight 170 g',
        '/media/652d626f6f6b.jpg', 950.00, 1, 23)
     , (280267, 'AirOn JVE299287',
        'Monitor diagonal 1.4" / RAM: 256 Mb / White / 1800 mA/h / Weight 220 g / USB / Dictophone / WiFi',
        '/media/736d6172747761746368.jpg', 1920.00, 6, 11)
     , (280274, 'Samsung PT191283',
        'Monitor 7" / RAM 2 GB / HDD 160 GB / Blue / Weight 140 g / 3G / WiFi / Webcam / GPS / USB',
        '/media/7461626c6574.jpg', 2020.00, 7, 22)
     , (280281, 'Lenovo OU9471164',
        'Monitor diagonal 5.0" / Camera: 2.2Mp / RAM: 1 Gb / White / 1300 mA/h / Weight 600 g / WiFi / GPS / USB',
        '/media/736d61727470686f6e65.jpg', 2850.00, 5, 9)
     , (280291, 'Apple TD69802919',
        'Monitor 22" / Intel Core I7 (2.2 GHz) / RAM 16 GB / HDD 260 GB / Weight 3.6 kg / DVD+/-RW / HDMI / USB',
        '/media/6e6f7465626f6f6b.jpg', 1920.00, 3, 15)
     , (280298, 'HTC OMB55110550',
        'Monitor diagonal 3.2" / Camera: 3.2Mp / RAM: 1 Gb / White / 1400 mA/h / Weight 600 g / Dictophone / WiFi / 3G / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 1620.00, 5, 19)
     , (280304, 'HTC NT29099',
        'Monitor diagonal 4.4" / Camera: 4.0Mp / RAM: 4 Gb / White / 1000 mA/h / Weight 360 g / Bluetooth / FM receiver / WiFi',
        '/media/736d61727470686f6e65.jpg', 420.00, 5, 19)
     , (280306, 'Lenovo QQJ98367035',
        'Monitor diagonal 5.6" / Camera: 3.0Mp / RAM: 4 Gb / Blue / 1500 mA/h / Weight 520 g / 3G / Dictophone / FM receiver / 2 Sim cards / USB',
        '/media/736d61727470686f6e65.jpg', 1770.00, 5, 9)
     , (280311, 'Lenovo LKB905086',
        'Monitor diagonal 3.8" / Camera: 3.2Mp / RAM: 512 Mb / Orange / 1300 mA/h / Weight 720 g / GPS / FM receiver / 2 Sim cards / 3G / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 90.00, 5, 9)
     , (280318, 'Asus CI4698',
        'Monitor 19" / Intel Core I7 (2.0 GHz) / RAM 12 GB / HDD 560 GB / Weight 6.2 kg / Bluetooth / WiFi / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 1290.00, 3, 13)
     , (280323, 'Lenovo FL0895584',
        'Monitor 9" / RAM 4 GB / HDD 470 GB / Black / Weight 140 g / GPS / Webcam / Bluetooth',
        '/media/7461626c6574.jpg', 1070.00, 7, 9)
     , (280327, 'Apple HF38915359',
        'Monitor 8" / RAM 3 GB / HDD 330 GB / Orange / Weight 300 g / Webcam / 3G / HDMI / GPS',
        '/media/7461626c6574.jpg', 2450.00, 7, 15)
     , (280337, 'Huawei JI52761',
        'Monitor diagonal 5.6" / Camera: 2.2Mp / RAM: 2 Gb / Black / 1300 mA/h / Weight 760 g / FM receiver / Dictophone / Bluetooth / 3G / 2 Sim cards / USB / WiFi',
        '/media/736d61727470686f6e65.jpg', 620.00, 5, 24)
     , (280340, 'Dell NUV04046', 'Monitor 9" / RAM 4 GB / HDD 800 GB / Black / Weight 100 g / HDMI / Bluetooth / WiFi',
        '/media/7461626c6574.jpg', 2610.00, 7, 1)
     , (280348, 'Apple AB1377374',
        'Memory 8 Gb / Weight 98 g / Black / MP3 / AVI / FM receiver / OGG / SD slot / AMV / USB / WMA / WAV / Bluetooth',
        '/media/6d70332d706c61796572.jpg', 1990.00, 2, 15)
     , (280354, 'Jeka JQT82413', 'Memory 16 Gb / Weight 41 g / Orange / MP3 / SD slot / MPEG-4 / AMV',
        '/media/6d70332d706c61796572.jpg', 780.00, 2, 6)
     , (280357, 'Asus TIE053115', 'Monitor 7" / RAM 4 GB / HDD 740 GB / Silver / Weight 220 g / WiFi / GPS / USB',
        '/media/7461626c6574.jpg', 2460.00, 7, 13)
     , (280360, 'Asus HDJ597483',
        'Monitor 15" / Intel Core I7 (2.2 GHz) / RAM 14 GB / HDD 290 GB / Weight 6.4 kg / Webcam / LAN / HDMI / USB / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 490.00, 3, 13)
     , (280361, 'Prestigio UUV52071029',
        'Monitor 10" / RAM 1 GB / HDD 750 GB / Silver / Weight 220 g / HDMI / USB / 3G / GPS',
        '/media/7461626c6574.jpg', 820.00, 7, 10)
     , (280362, 'Dell PBC50277488',
        'Monitor 9" / RAM 3 GB / HDD 170 GB / Orange / Weight 300 g / GPS / HDMI / WiFi / Webcam',
        '/media/7461626c6574.jpg', 2470.00, 7, 1)
     , (280372, 'Asus OPF01743707',
        'Monitor 19" / Intel Core I7 (2.8 GHz) / RAM 3 GB / HDD 540 GB / Weight 4.8 kg / LAN / HDMI / Intel HD Graphics / WiFi',
        '/media/6e6f7465626f6f6b.jpg', 2420.00, 3, 13)
     , (280376, 'Philips CU6713949',
        'Monitor diagonal 1.8" / Camera: 1.8Mp / RAM 64 Mb / 2000 mA/h / White / Weight 100 g / 2 Sim cards / USB / SD',
        '/media/70686f6e65.jpg', 220.00, 4, 18)
     , (280383, 'Sony MO48397504',
        'Monitor 7" / RAM 1 GB / HDD 460 GB / Blue / Weight 140 g / Webcam / Bluetooth / WiFi / GPS / HDMI / USB',
        '/media/7461626c6574.jpg', 1580.00, 7, 8)
     , (280389, 'Sony BMS2443427',
        'Monitor diagonal 5.6" / Camera: 3.0Mp / RAM: 512 Mb / Blue / 2000 mA/h / Weight 360 g / USB / 3G / WiFi / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 2300.00, 5, 8)
     , (280396, 'Samsung ES396326', 'Monitor 9" / RAM 3 GB / HDD 170 GB / Blue / Weight 100 g / HDMI / 3G / USB',
        '/media/7461626c6574.jpg', 390.00, 7, 22)
     , (280404, 'Sony EMQ26269347', 'Monitor 8" / RAM 4 GB / HDD 130 GB / Orange / Weight 180 g / USB / GPS / WiFi',
        '/media/7461626c6574.jpg', 2960.00, 7, 8)
     , (280406, 'Dell GSR91390',
        'Monitor 16" / Intel Core I7 (3.2 GHz) / RAM 10 GB / HDD 220 GB / Weight 4.8 kg / Intel HD Graphics / WiFi / LAN / Webcam / USB',
        '/media/6e6f7465626f6f6b.jpg', 1470.00, 3, 1)
     , (280414, 'Prestigio SRV09104',
        'Monitor diagonal 3.0" / Camera: 1Mp / RAM 16 Mb / 1400 mA/h / Black / Weight 380 g / Dictophone / USB / 2 Sim cards',
        '/media/70686f6e65.jpg', 1780.00, 4, 10)
     , (280418, 'Apple IT347753',
        'Monitor diagonal 5.0" / Camera: 2.2Mp / RAM: 1 Gb / Blue / 1100 mA/h / Weight 760 g / WiFi / FM receiver / 2 Sim cards / Dictophone / USB',
        '/media/736d61727470686f6e65.jpg', 1900.00, 5, 15)
     , (280423, 'Prestigio JSH50346',
        'Monitor diagonal 3.2" / Camera: 3.0Mp / RAM: 1 Gb / Orange / 1200 mA/h / Weight 800 g / USB / GPS / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 1310.00, 5, 10)
     , (280428, 'Apple DUA12277',
        'Monitor diagonal 5.6" / Camera: 2.2Mp / RAM: 1 Gb / Blue / 1400 mA/h / Weight 520 g / 3G / WiFi / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 630.00, 5, 15)
     , (280438, 'HTC DFL95755',
        'Monitor diagonal 6.0" / Camera: 3.0Mp / RAM: 1 Gb / Orange / 1200 mA/h / Weight 440 g / 2 Sim cards / 3G / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 1130.00, 5, 19)
     , (280444, 'HP LE5132',
        'Monitor 20" / Intel Core I5 (2.8 GHz) / RAM 16 GB / HDD 510 GB / Weight 4.2 kg / WiFi / Webcam / LAN',
        '/media/6e6f7465626f6f6b.jpg', 900.00, 3, 3)
     , (280446, 'Apple GM5850',
        'Monitor 7" / RAM 2 GB / HDD 140 GB / Blue / Weight 180 g / GPS / HDMI / WiFi / USB / 3G',
        '/media/7461626c6574.jpg', 1740.00, 7, 15)
     , (280450, 'Jeka EJK294073',
        'Memory 12 Gb / Weight 23 g / Black / MP3 / MPEG-4 / Bluetooth / SD slot / FM receiver / Dictophone / AVI / WAV / USB / WMA',
        '/media/6d70332d706c61796572.jpg', 2780.00, 2, 6)
     , (280454, 'Samsung SJ7203',
        'Monitor diagonal 5.6" / Camera: 2.2Mp / RAM: 1 Gb / White / 1000 mA/h / Weight 560 g / WiFi / 2 Sim cards / Dictophone / GPS / Bluetooth / USB',
        '/media/736d61727470686f6e65.jpg', 610.00, 5, 22)
     , (280464, 'Samsung OL862093',
        'Monitor diagonal 1.3" / RAM: 512 Mb / Black / 1800 mA/h / Weight 180 g / USB / Dictophone / WiFi',
        '/media/736d6172747761746368.jpg', 830.00, 6, 22)
     , (280467, 'Sony CIA548933', 'Monitor 7" / RAM 1 GB / HDD 270 GB / Orange / Weight 140 g / 3G / USB / WiFi',
        '/media/7461626c6574.jpg', 2120.00, 7, 8)
     , (280471, 'Samsung HEL4122',
        'Monitor diagonal 2.2" / Camera: 2.6Mp / RAM 16 Mb / 1400 mA/h / Blue / Weight 220 g / USB / SD / Dictophone',
        '/media/70686f6e65.jpg', 510.00, 4, 22)
     , (280477, 'Asus BN08534',
        'Monitor 9" / RAM 4 GB / HDD 610 GB / White / Weight 300 g / Bluetooth / HDMI / GPS / 3G / USB / Webcam',
        '/media/7461626c6574.jpg', 2440.00, 7, 13)
     , (280486, 'AirBook AJ47474184',
        'Monitor diagonal 9" / Matrix type: E lnk Carta / Resolution: 1024x758 / Memory 6 GB / Weight 175 g',
        '/media/652d626f6f6b.jpg', 1460.00, 1, 20)
     , (280489, 'HP BCD1364187',
        'Monitor 11" / Intel Core I5 (2.8 GHz) / RAM 14 GB / HDD 770 GB / Weight 2.6 kg / Webcam / HDMI / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 1690.00, 3, 3)
     , (280493, 'Apple KK6879', 'Memory 8 Gb / Weight 92 g / Blue / MP3 / AVI / Bluetooth / SD slot / WMA / OGG / AMV',
        '/media/6d70332d706c61796572.jpg', 100.00, 2, 15)
     , (280499, 'PocketBook RFI1841148',
        'Monitor 9" / RAM 1 GB / HDD 170 GB / Orange / Weight 260 g / GPS / 3G / Bluetooth', '/media/7461626c6574.jpg',
        600.00, 7, 17)
     , (280501, 'Sony JB67934619', 'Memory 16 Gb / Weight 20 g / White / MP3 / WAV / OGG / USB',
        '/media/6d70332d706c61796572.jpg', 290.00, 2, 8)
     , (280509, 'Samsung QSA2738',
        'Monitor diagonal 1.2" / RAM: 512 Mb / Silver / 1700 mA/h / Weight 140 g / Dictophone / GPS / USB',
        '/media/736d6172747761746368.jpg', 140.00, 6, 22)
     , (280512, 'Dell VMI6814446',
        'Monitor 7" / RAM 3 GB / HDD 310 GB / White / Weight 100 g / USB / GPS / Webcam / Bluetooth / 3G / WiFi',
        '/media/7461626c6574.jpg', 2830.00, 7, 1)
     , (280516, 'Nokia LLA7862',
        'Monitor diagonal 2.6" / Camera: 1.8Mp / RAM 16 Mb / 1100 mA/h / Blue / Weight 220 g / SD / Dictophone / USB / 2 Sim cards',
        '/media/70686f6e65.jpg', 240.00, 4, 25)
     , (280524, 'LG DFT7551',
        'Monitor diagonal 1.8" / Camera: 1.8Mp / RAM 64 Mb / 1100 mA/h / Black / Weight 120 g / Bluetooth / 2 Sim cards / Dictophone',
        '/media/70686f6e65.jpg', 1080.00, 4, 21)
     , (280532, 'Asus QA4578', 'Monitor 9" / RAM 2 GB / HDD 600 GB / Blue / Weight 100 g / Webcam / GPS / Bluetooth',
        '/media/7461626c6574.jpg', 500.00, 7, 13)
     , (280533, 'Gigabyte DS50388',
        'Monitor diagonal 1.8" / Camera: 1Mp / RAM 48 Mb / 2000 mA/h / Black / Weight 280 g / Dictophone / 2 Sim cards / Bluetooth',
        '/media/70686f6e65.jpg', 1550.00, 4, 4)
     , (280540, 'Samsung SIV01248',
        'Monitor diagonal 1.3" / RAM: 512 Mb / Black / 1200 mA/h / Weight 260 g / USB / Dictophone / WiFi',
        '/media/736d6172747761746368.jpg', 550.00, 6, 22)
     , (280546, 'EvroMedia IR48454',
        'Monitor diagonal 12" / Matrix type: E lnk Pearl / Resolution: 1600x1200 / Memory 12 GB / Weight 165 g',
        '/media/652d626f6f6b.jpg', 360.00, 1, 12)
     , (280555, 'Dell UM2704277',
        'Monitor 14" / Intel Core I3 (1.6 GHz) / RAM 2 GB / HDD 410 GB / Weight 4.2 kg / Webcam / HDMI / Intel HD Graphics',
        '/media/6e6f7465626f6f6b.jpg', 1740.00, 3, 1)
     , (280558, 'HP CGD61260307',
        'Monitor 22" / Intel Core I5 (2.6 GHz) / RAM 8 GB / HDD 170 GB / Weight 3.2 kg / Webcam / HDMI / WiFi / LAN / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 580.00, 3, 3)
     , (280562, 'LG HDR0935',
        'Monitor diagonal 3.0" / Camera: 2.6Mp / RAM 32 Mb / 1400 mA/h / White / Weight 200 g / USB / Dictophone / Bluetooth',
        '/media/70686f6e65.jpg', 30.00, 4, 21)
     , (280563, 'Nokia IQB6377',
        'Monitor diagonal 5.0" / Camera: 3.0Mp / RAM: 1 Gb / Silver / 1600 mA/h / Weight 360 g / 2 Sim cards / WiFi / FM receiver',
        '/media/736d61727470686f6e65.jpg', 1170.00, 5, 25)
     , (280567, 'Sony FR1413',
        'Monitor diagonal 3.8" / Camera: 4.0Mp / RAM: 2 Gb / Orange / 1600 mA/h / Weight 320 g / 3G / WiFi / FM receiver / GPS',
        '/media/736d61727470686f6e65.jpg', 1160.00, 5, 8)
     , (280571, 'Fly DIC83070198',
        'Monitor diagonal 6.0" / Camera: 3.0Mp / RAM: 2 Gb / Black / 1600 mA/h / Weight 680 g / USB / Bluetooth / GPS',
        '/media/736d61727470686f6e65.jpg', 1950.00, 5, 7)
     , (280577, 'Jeka TTC7398', 'Memory 16 Gb / Weight 65 g / White / MP3 / MPEG-4 / WMA / AMV',
        '/media/6d70332d706c61796572.jpg', 830.00, 2, 6)
     , (280586, 'PocketBook CL7516',
        'Monitor diagonal 11" / Matrix type: E lnk Pearl / Resolution: 1200x800 / Memory 4 GB / Weight 160 g',
        '/media/652d626f6f6b.jpg', 2270.00, 1, 17)
     , (280595, 'Sony EG25357',
        'Monitor diagonal 4.4" / Camera: 2.2Mp / RAM: 2 Gb / Silver / 1700 mA/h / Weight 640 g / 2 Sim cards / WiFi / FM receiver / Dictophone / GPS',
        '/media/736d61727470686f6e65.jpg', 2100.00, 5, 8)
     , (280604, 'Prestigio LN3000',
        'Monitor diagonal 5.0" / Camera: 3.2Mp / RAM: 512 Mb / Blue / 1800 mA/h / Weight 440 g / Bluetooth / 3G / GPS / USB',
        '/media/736d61727470686f6e65.jpg', 1700.00, 5, 10)
     , (280605, 'Asus HLQ98942', 'Monitor 8" / RAM 1 GB / HDD 670 GB / Orange / Weight 260 g / Bluetooth / USB / GPS',
        '/media/7461626c6574.jpg', 660.00, 7, 13)
     , (280614, 'LG AON6222001',
        'Monitor diagonal 3.8" / Camera: 2.2Mp / RAM: 512 Mb / Blue / 1000 mA/h / Weight 640 g / GPS / 3G / FM receiver / USB / Dictophone',
        '/media/736d61727470686f6e65.jpg', 740.00, 5, 21)
     , (280616, 'Apple PMO657886', 'Memory 8 Gb / Weight 53 g / White / MP3 / Dictophone / WAV / AVI',
        '/media/6d70332d706c61796572.jpg', 1170.00, 2, 15)
     , (280619, 'Jeka BSV31700',
        'Memory 16 Gb / Weight 92 g / Silver / MP3 / USB / SD slot / Bluetooth / WMA / OGG / AMV / FM receiver',
        '/media/6d70332d706c61796572.jpg', 2800.00, 2, 6)
     , (280625, 'Prestigio AC6022', 'Monitor 10" / RAM 2 GB / HDD 190 GB / Blue / Weight 260 g / GPS / WiFi / USB',
        '/media/7461626c6574.jpg', 1120.00, 7, 10)
     , (280629, 'Acer GFT19850', 'Monitor 9" / RAM 4 GB / HDD 530 GB / Silver / Weight 60 g / GPS / HDMI / USB',
        '/media/7461626c6574.jpg', 1050.00, 7, 14)
     , (280632, 'HTC KBK9346',
        'Monitor diagonal 5.6" / Camera: 2.2Mp / RAM: 4 Gb / Silver / 1000 mA/h / Weight 760 g / WiFi / 3G / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 1180.00, 5, 19)
     , (280633, 'Apple CAP86311',
        'Memory 12 Gb / Weight 59 g / Black / MP3 / Bluetooth / FM receiver / USB / MPEG-4 / WMA / SD slot / Dictophone / AMV / AVI / OGG',
        '/media/6d70332d706c61796572.jpg', 2870.00, 2, 15)
     , (280642, 'PocketBook GF665461',
        'Monitor diagonal 8" / Matrix type: E lnk / Resolution: 800x600 / Memory 8 GB / Weight 165 g',
        '/media/652d626f6f6b.jpg', 2350.00, 1, 17)
     , (280647, 'HTC HJ88585',
        'Monitor diagonal 6.0" / Camera: 2.2Mp / RAM: 1 Gb / White / 1100 mA/h / Weight 760 g / Bluetooth / USB / GPS / 3G',
        '/media/736d61727470686f6e65.jpg', 1920.00, 5, 19)
     , (280650, 'Nokia ASK27054409',
        'Monitor diagonal 3.0" / Camera: 2.2Mp / RAM 32 Mb / 1900 mA/h / Orange / Weight 320 g / Bluetooth / Dictophone / 2 Sim cards',
        '/media/70686f6e65.jpg', 1000.00, 4, 25)
     , (280651, 'Sony LIQ6049688',
        'Memory 12 Gb / Weight 62 g / Orange / MP3 / SD slot / OGG / USB / WMA / AMV / FM receiver / Dictophone / Bluetooth / MPEG-4',
        '/media/6d70332d706c61796572.jpg', 1350.00, 2, 8)
     , (280655, 'Dell DMU07094',
        'Monitor 7" / RAM 2 GB / HDD 250 GB / White / Weight 300 g / 3G / GPS / USB / Webcam / HDMI / Bluetooth',
        '/media/7461626c6574.jpg', 230.00, 7, 1)
     , (280665, 'Amazon DQP5301',
        'Monitor diagonal 12" / Matrix type: E lnk Carta / Resolution: 800x600 / Memory 5 GB / Weight 200 g',
        '/media/652d626f6f6b.jpg', 640.00, 1, 23)
     , (280670, 'HTC TRB16006469',
        'Monitor diagonal 3.2" / Camera: 3.2Mp / RAM: 512 Mb / Orange / 1900 mA/h / Weight 760 g / Dictophone / GPS / 3G / WiFi',
        '/media/736d61727470686f6e65.jpg', 1130.00, 5, 19)
     , (280673, 'Dell QGE43016874',
        'Monitor 9" / RAM 1 GB / HDD 670 GB / White / Weight 260 g / WiFi / HDMI / Bluetooth / GPS / USB / Webcam',
        '/media/7461626c6574.jpg', 1140.00, 7, 1)
     , (280682, 'HTC HFA34046',
        'Monitor diagonal 4.4" / Camera: 3.0Mp / RAM: 512 Mb / Silver / 2000 mA/h / Weight 680 g / GPS / USB / WiFi',
        '/media/736d61727470686f6e65.jpg', 1370.00, 5, 19)
     , (280691, 'AirOn UFL65606731',
        'Monitor diagonal 1.1" / RAM: 1 Gb / White / 1600 mA/h / Weight 60 g / Bluetooth / Dictophone / GPS / WiFi',
        '/media/736d6172747761746368.jpg', 750.00, 6, 11)
     , (280701, 'Huawei ODE31119806',
        'Monitor diagonal 6.0" / Camera: 3.0Mp / RAM: 4 Gb / Blue / 1700 mA/h / Weight 360 g / 2 Sim cards / GPS / USB / WiFi',
        '/media/736d61727470686f6e65.jpg', 330.00, 5, 24)
     , (280702, 'HTC GSP94941895',
        'Monitor diagonal 5.0" / Camera: 2.2Mp / RAM: 2 Gb / Orange / 1700 mA/h / Weight 600 g / Dictophone / 3G / FM receiver',
        '/media/736d61727470686f6e65.jpg', 1580.00, 5, 19)
     , (280710, 'HTC IN9689',
        'Monitor diagonal 5.6" / Camera: 2.2Mp / RAM: 1 Gb / Silver / 1400 mA/h / Weight 440 g / 3G / Dictophone / WiFi / FM receiver / USB',
        '/media/736d61727470686f6e65.jpg', 1930.00, 5, 19)
     , (280719, 'FiiO TD79613267', 'Memory 4 Gb / Weight 38 g / Silver / MP3 / WAV / USB / MPEG-4',
        '/media/6d70332d706c61796572.jpg', 2160.00, 2, 2)
     , (280729, 'Asus GRV0423',
        'Monitor 9" / RAM 2 GB / HDD 220 GB / Black / Weight 180 g / HDMI / WiFi / Bluetooth / USB / 3G',
        '/media/7461626c6574.jpg', 1080.00, 7, 13)
     , (280737, 'Huawei NE966268',
        'Monitor diagonal 3.8" / Camera: 3.2Mp / RAM: 1 Gb / Orange / 2000 mA/h / Weight 440 g / Dictophone / WiFi / FM receiver',
        '/media/736d61727470686f6e65.jpg', 130.00, 5, 24)
     , (280742, 'Apple DB49573767',
        'Monitor 11" / Intel Core I7 (2.0 GHz) / RAM 13 GB / HDD 60 GB / Weight 6.2 kg / Bluetooth / USB / DVD+/-RW / Webcam / WiFi / Intel HD Graphics / LAN',
        '/media/6e6f7465626f6f6b.jpg', 1620.00, 3, 15)
     , (280744, 'Nokia FAE7972',
        'Monitor diagonal 4.4" / Camera: 3.2Mp / RAM: 1 Gb / Black / 1700 mA/h / Weight 400 g / WiFi / FM receiver / Dictophone / 3G',
        '/media/736d61727470686f6e65.jpg', 250.00, 5, 25)
     , (280749, 'Apple OF750832',
        'Monitor diagonal 1.8" / RAM: 256 Mb / Orange / 1100 mA/h / Weight 100 g / WiFi / Bluetooth / GPS',
        '/media/736d6172747761746368.jpg', 950.00, 6, 15)
     , (280756, 'Jeka ASP606112',
        'Memory 20 Gb / Weight 65 g / Black / MP3 / MPEG-4 / OGG / AVI / Bluetooth / Dictophone',
        '/media/6d70332d706c61796572.jpg', 520.00, 2, 6)
     , (280763, 'Apple OD9090',
        'Monitor diagonal 5.6" / Camera: 3.2Mp / RAM: 4 Gb / Blue / 1600 mA/h / Weight 360 g / 3G / FM receiver / Dictophone',
        '/media/736d61727470686f6e65.jpg', 1930.00, 5, 15)
     , (280770, 'LG CIP0674',
        'Monitor diagonal 3.0" / Camera: 2.2Mp / RAM 32 Mb / 1200 mA/h / Black / Weight 320 g / Dictophone / USB / 2 Sim cards',
        '/media/70686f6e65.jpg', 2200.00, 4, 21)
     , (280777, 'EvroMedia FND1286535',
        'Monitor diagonal 8" / Matrix type: E lnk Pearl / Resolution: 800x600 / Memory 7 GB / Weight 155 g',
        '/media/652d626f6f6b.jpg', 2990.00, 1, 12)
     , (280786, 'AirBook FRP4348774',
        'Monitor diagonal 7" / Matrix type: E lnk Pearl / Resolution: 1600x1200 / Memory 7 GB / Weight 175 g',
        '/media/652d626f6f6b.jpg', 1850.00, 1, 20)
     , (280796, 'Lenovo LF14971',
        'Monitor diagonal 4.4" / Camera: 3.0Mp / RAM: 512 Mb / Orange / 1700 mA/h / Weight 360 g / 3G / FM receiver / GPS',
        '/media/736d61727470686f6e65.jpg', 2130.00, 5, 9)
     , (280800, 'Dell RU4771958',
        'Monitor 9" / RAM 1 GB / HDD 710 GB / Blue / Weight 100 g / 3G / Bluetooth / Webcam / HDMI / GPS / USB',
        '/media/7461626c6574.jpg', 1710.00, 7, 1)
     , (280804, 'Samsung MF94069976',
        'Monitor diagonal 1.2" / RAM: 512 Mb / Black / 1000 mA/h / Weight 220 g / WiFi / GPS / USB / Dictophone',
        '/media/736d6172747761746368.jpg', 1400.00, 6, 22)
     , (280811, 'Apple FC8805542',
        'Monitor 8" / RAM 2 GB / HDD 690 GB / Black / Weight 260 g / Bluetooth / Webcam / WiFi / HDMI',
        '/media/7461626c6574.jpg', 290.00, 7, 15)
     , (280817, 'Samsung SF7097318',
        'Monitor diagonal 5.0" / Camera: 3.0Mp / RAM: 1 Gb / Silver / 1500 mA/h / Weight 480 g / FM receiver / Bluetooth / 3G',
        '/media/736d61727470686f6e65.jpg', 400.00, 5, 22)
     , (280819, 'Apple QIE324977',
        'Memory 8 Gb / Weight 65 g / Black / MP3 / SD slot / Dictophone / USB / OGG / FM receiver / AVI / MPEG-4 / Bluetooth / WAV',
        '/media/6d70332d706c61796572.jpg', 1340.00, 2, 15)
     , (280829, 'HP FPC3480338',
        'Monitor 19" / Intel Core I5 (2.0 GHz) / RAM 16 GB / HDD 570 GB / Weight 6.4 kg / DVD+/-RW / Webcam / Bluetooth / HDMI',
        '/media/6e6f7465626f6f6b.jpg', 1930.00, 3, 3)
     , (280832, 'LG MR03692798',
        'Monitor diagonal 2.2" / Camera: 1.8Mp / RAM 48 Mb / 1900 mA/h / Blue / Weight 320 g / 2 Sim cards / Bluetooth / USB',
        '/media/70686f6e65.jpg', 160.00, 4, 21)
     , (280839, 'Transcend NOO8344',
        'Memory 12 Gb / Weight 74 g / Blue / MP3 / AVI / USB / FM receiver / Bluetooth / OGG / WMA / SD slot / MPEG-4 / WAV',
        '/media/6d70332d706c61796572.jpg', 2170.00, 2, 5)
     , (280844, 'Lenovo GK53416',
        'Monitor diagonal 5.0" / Camera: 3.0Mp / RAM: 2 Gb / White / 1300 mA/h / Weight 720 g / WiFi / USB / Bluetooth / 3G',
        '/media/736d61727470686f6e65.jpg', 1490.00, 5, 9)
     , (280849, 'Dell PJ3044',
        'Monitor 23" / Intel Core I5 (2.0 GHz) / RAM 11 GB / HDD 640 GB / Weight 3.0 kg / Intel HD Graphics / HDMI / LAN',
        '/media/6e6f7465626f6f6b.jpg', 2180.00, 3, 1)
     , (280855, 'Dell TB1626',
        'Monitor 13" / Intel Core I7 (2.2 GHz) / RAM 11 GB / HDD 310 GB / Weight 4.0 kg / HDMI / Webcam / Bluetooth',
        '/media/6e6f7465626f6f6b.jpg', 2910.00, 3, 1)
     , (280862, 'Prestigio MIG2546', 'Monitor 9" / RAM 4 GB / HDD 560 GB / Black / Weight 140 g / HDMI / Webcam / 3G',
        '/media/7461626c6574.jpg', 1870.00, 7, 10)
     , (280870, 'Jeka TG75893138',
        'Memory 4 Gb / Weight 41 g / Black / MP3 / WAV / AMV / MPEG-4 / FM receiver / SD slot / AVI / Bluetooth',
        '/media/6d70332d706c61796572.jpg', 350.00, 2, 6)
     , (280876, 'FixiTime CFN503445',
        'Monitor diagonal 1.2" / RAM: 256 Mb / White / 1800 mA/h / Weight 180 g / USB / WiFi / GPS',
        '/media/736d6172747761746368.jpg', 940.00, 6, 16)
     , (280879, 'LG RCE6546620',
        'Monitor diagonal 4.4" / Camera: 4.0Mp / RAM: 2 Gb / Silver / 1400 mA/h / Weight 360 g / Dictophone / USB / FM receiver',
        '/media/736d61727470686f6e65.jpg', 2420.00, 5, 21)
     , (280887, 'AirBook VD619827',
        'Monitor diagonal 9" / Matrix type: E lnk Carta / Resolution: 800x600 / Memory 9 GB / Weight 160 g',
        '/media/652d626f6f6b.jpg', 540.00, 1, 20)
     , (280897, 'Asus UO665476', 'Monitor 8" / RAM 4 GB / HDD 220 GB / Blue / Weight 260 g / GPS / WiFi / HDMI',
        '/media/7461626c6574.jpg', 2580.00, 7, 13)
     , (280900, 'Apple OQ752673',
        'Monitor diagonal 1.8" / RAM: 512 Mb / White / 1300 mA/h / Weight 300 g / Bluetooth / Dictophone / GPS',
        '/media/736d6172747761746368.jpg', 300.00, 6, 15)
     , (280910, 'Dell IKA450072',
        'Monitor 19" / Intel Core I3 (2.4 GHz) / RAM 5 GB / HDD 240 GB / Weight 5.0 kg / LAN / WiFi / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 140.00, 3, 1)
     , (280911, 'Jeka MCV46141809',
        'Memory 12 Gb / Weight 68 g / White / MP3 / Bluetooth / USB / OGG / AVI / FM receiver / WAV / AMV / Dictophone / MPEG-4',
        '/media/6d70332d706c61796572.jpg', 2000.00, 2, 6)
     , (280916, 'AirBook QJ378592',
        'Monitor diagonal 12" / Matrix type: E lnk Pearl / Resolution: 800x600 / Memory 10 GB / Weight 155 g',
        '/media/652d626f6f6b.jpg', 2690.00, 1, 20)
     , (280919, 'Prestigio GKP09960',
        'Monitor diagonal 3.2" / Camera: 3.0Mp / RAM: 512 Mb / Orange / 1100 mA/h / Weight 440 g / GPS / USB / Dictophone',
        '/media/736d61727470686f6e65.jpg', 1550.00, 5, 10)
     , (280923, 'Apple ULI845207',
        'Monitor 19" / Intel Core I3 (2.0 GHz) / RAM 8 GB / HDD 400 GB / Weight 4.0 kg / USB / Intel HD Graphics / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 2410.00, 3, 15)
     , (280926, 'HTC EJI60035',
        'Monitor diagonal 3.8" / Camera: 3.2Mp / RAM: 512 Mb / Silver / 1100 mA/h / Weight 360 g / Bluetooth / 2 Sim cards / GPS',
        '/media/736d61727470686f6e65.jpg', 1630.00, 5, 19)
     , (280933, 'Nokia FRL2094',
        'Monitor diagonal 3.2" / Camera: 4.0Mp / RAM: 512 Mb / Black / 1900 mA/h / Weight 760 g / WiFi / FM receiver / 3G',
        '/media/736d61727470686f6e65.jpg', 1200.00, 5, 25)
     , (280935, 'Lenovo EI8169077',
        'Monitor diagonal 5.6" / Camera: 3.2Mp / RAM: 1 Gb / White / 1500 mA/h / Weight 680 g / 2 Sim cards / Bluetooth / Dictophone / USB / FM receiver / WiFi',
        '/media/736d61727470686f6e65.jpg', 860.00, 5, 9)
     , (280942, 'Gigabyte NVQ6135',
        'Monitor diagonal 2.2" / Camera: 2.6Mp / RAM 48 Mb / 1500 mA/h / Orange / Weight 200 g / USB / 2 Sim cards / SD',
        '/media/70686f6e65.jpg', 260.00, 4, 4)
     , (280952, 'Lenovo DTJ5976',
        'Monitor 19" / Intel Core I3 (1.6 GHz) / RAM 15 GB / HDD 610 GB / Weight 3.8 kg / Webcam / Intel HD Graphics / DVD+/-RW / LAN',
        '/media/6e6f7465626f6f6b.jpg', 2460.00, 3, 9)
     , (280955, 'Acer ND76757336',
        'Monitor 10" / RAM 4 GB / HDD 580 GB / Silver / Weight 220 g / HDMI / Bluetooth / WiFi',
        '/media/7461626c6574.jpg', 80.00, 7, 14)
     , (280957, 'Apple CNB27077577',
        'Monitor diagonal 4.4" / Camera: 2.2Mp / RAM: 4 Gb / Silver / 1200 mA/h / Weight 760 g / GPS / 3G / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 250.00, 5, 15)
     , (280963, 'Lenovo IU79168',
        'Monitor 9" / RAM 3 GB / HDD 100 GB / White / Weight 60 g / 3G / WiFi / HDMI / Bluetooth / Webcam / USB',
        '/media/7461626c6574.jpg', 520.00, 7, 9)
     , (280965, 'Samsung VBT4722687',
        'Monitor diagonal 2.0" / Camera: 1.8Mp / RAM 64 Mb / 2000 mA/h / Silver / Weight 220 g / USB / SD / 2 Sim cards',
        '/media/70686f6e65.jpg', 580.00, 4, 22)
     , (280974, 'Philips FFG610244',
        'Monitor diagonal 1.8" / Camera: 1.8Mp / RAM 48 Mb / 1200 mA/h / Silver / Weight 220 g / USB / Dictophone / SD',
        '/media/70686f6e65.jpg', 1810.00, 4, 18)
     , (280983, 'Dell IM49686784',
        'Monitor 7" / RAM 1 GB / HDD 410 GB / Black / Weight 100 g / 3G / Bluetooth / Webcam',
        '/media/7461626c6574.jpg', 1300.00, 7, 1)
     , (280990, 'Dell QMI61263', 'Monitor 9" / RAM 1 GB / HDD 800 GB / Blue / Weight 60 g / GPS / Webcam / Bluetooth',
        '/media/7461626c6574.jpg', 1160.00, 7, 1)
     , (280992, 'Samsung LM79564', 'Monitor 8" / RAM 4 GB / HDD 530 GB / White / Weight 260 g / USB / WiFi / HDMI',
        '/media/7461626c6574.jpg', 960.00, 7, 22)
     , (281000, 'Asus HS0592736', 'Monitor 9" / RAM 1 GB / HDD 60 GB / Blue / Weight 300 g / Webcam / GPS / Bluetooth',
        '/media/7461626c6574.jpg', 2800.00, 7, 13)
     , (281008, 'FiiO SS0931', 'Memory 20 Gb / Weight 35 g / Orange / MP3 / AVI / MPEG-4 / FM receiver',
        '/media/6d70332d706c61796572.jpg', 1560.00, 2, 2)
     , (281018, 'Samsung BEM9587',
        'Monitor diagonal 1.1" / RAM: 256 Mb / Blue / 2000 mA/h / Weight 180 g / Dictophone / WiFi / GPS',
        '/media/736d6172747761746368.jpg', 1050.00, 6, 22)
     , (281023, 'PocketBook JUM1926',
        'Monitor diagonal 8" / Matrix type: E lnk Pearl / Resolution: 800x600 / Memory 11 GB / Weight 170 g',
        '/media/652d626f6f6b.jpg', 1760.00, 1, 17)
     , (281030, 'Prestigio DU72303',
        'Monitor diagonal 3.8" / Camera: 4.0Mp / RAM: 2 Gb / Black / 1900 mA/h / Weight 360 g / WiFi / Bluetooth / Dictophone',
        '/media/736d61727470686f6e65.jpg', 1720.00, 5, 10)
     , (281033, 'Samsung PPU954783',
        'Monitor 7" / RAM 4 GB / HDD 400 GB / Orange / Weight 100 g / Bluetooth / USB / Webcam',
        '/media/7461626c6574.jpg', 660.00, 7, 22)
     , (281040, 'Prestigio FK85927997',
        'Monitor 7" / RAM 2 GB / HDD 460 GB / Silver / Weight 300 g / HDMI / 3G / Bluetooth', '/media/7461626c6574.jpg',
        1930.00, 7, 10)
     , (281041, 'HTC DHP404540',
        'Monitor diagonal 6.0" / Camera: 4.0Mp / RAM: 1 Gb / Black / 1300 mA/h / Weight 680 g / USB / Bluetooth / 3G',
        '/media/736d61727470686f6e65.jpg', 2400.00, 5, 19)
     , (281048, 'Samsung OR986279',
        'Monitor diagonal 1.7" / RAM: 256 Mb / Black / 1600 mA/h / Weight 60 g / Bluetooth / WiFi / GPS',
        '/media/736d6172747761746368.jpg', 1120.00, 6, 22)
     , (281057, 'Dell QPK14976', 'Monitor 8" / RAM 3 GB / HDD 550 GB / Blue / Weight 140 g / WiFi / GPS / Webcam',
        '/media/7461626c6574.jpg', 480.00, 7, 1)
     , (281067, 'Dell BVH47855',
        'Monitor 10" / RAM 2 GB / HDD 460 GB / Silver / Weight 220 g / Bluetooth / Webcam / HDMI',
        '/media/7461626c6574.jpg', 2260.00, 7, 1)
     , (281069, 'EvroMedia ECE1147826',
        'Monitor diagonal 11" / Matrix type: E lnk / Resolution: 1024x758 / Memory 12 GB / Weight 175 g',
        '/media/652d626f6f6b.jpg', 1780.00, 1, 12)
     , (281076, 'LG PO95605',
        'Monitor diagonal 2.4" / Camera: 1.8Mp / RAM 48 Mb / 1800 mA/h / Silver / Weight 200 g / Bluetooth / USB / 2 Sim cards',
        '/media/70686f6e65.jpg', 1510.00, 4, 21)
     , (281080, 'Prestigio TI9566459',
        'Monitor 10" / RAM 4 GB / HDD 680 GB / Silver / Weight 260 g / 3G / GPS / Webcam / HDMI / USB / Bluetooth',
        '/media/7461626c6574.jpg', 510.00, 7, 10)
     , (281083, 'HTC VCI7384357',
        'Monitor diagonal 5.6" / Camera: 2.2Mp / RAM: 512 Mb / Black / 2000 mA/h / Weight 640 g / Bluetooth / 3G / USB',
        '/media/736d61727470686f6e65.jpg', 2370.00, 5, 19)
     , (281090, 'EvroMedia FT56641',
        'Monitor diagonal 11" / Matrix type: E lnk Carta / Resolution: 800x600 / Memory 7 GB / Weight 160 g',
        '/media/652d626f6f6b.jpg', 680.00, 1, 12)
     , (281096, 'LG ANR0649',
        'Monitor diagonal 2.4" / Camera: 2.6Mp / RAM 64 Mb / 2000 mA/h / White / Weight 180 g / Bluetooth / SD / Dictophone',
        '/media/70686f6e65.jpg', 670.00, 4, 21)
     , (281100, 'Sony QO762015',
        'Memory 4 Gb / Weight 29 g / Silver / MP3 / Bluetooth / Dictophone / FM receiver / AVI / OGG / WAV / WMA / MPEG-4 / SD slot',
        '/media/6d70332d706c61796572.jpg', 780.00, 2, 8)
     , (281106, 'Dell QP51063775',
        'Monitor 11" / Intel Core I3 (2.6 GHz) / RAM 11 GB / HDD 800 GB / Weight 3.6 kg / USB / Bluetooth / DVD+/-RW / WiFi / HDMI / LAN',
        '/media/6e6f7465626f6f6b.jpg', 1540.00, 3, 1)
     , (281110, 'Lenovo VBF32233957',
        'Monitor diagonal 5.0" / Camera: 2.2Mp / RAM: 2 Gb / White / 1500 mA/h / Weight 480 g / GPS / Dictophone / USB / Bluetooth / 3G / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 990.00, 5, 9)
     , (281119, 'HP LC6621959',
        'Monitor 22" / Intel Core I3 (2.2 GHz) / RAM 8 GB / HDD 610 GB / Weight 3.0 kg / WiFi / HDMI / Intel HD Graphics / DVD+/-RW / Bluetooth',
        '/media/6e6f7465626f6f6b.jpg', 1510.00, 3, 3)
     , (281122, 'EvroMedia ACN22969',
        'Monitor diagonal 7" / Matrix type: E lnk / Resolution: 800x600 / Memory 10 GB / Weight 185 g',
        '/media/652d626f6f6b.jpg', 1740.00, 1, 12)
     , (281132, 'PocketBook UQJ16738',
        'Monitor diagonal 11" / Matrix type: E lnk Carta / Resolution: 1600x1200 / Memory 7 GB / Weight 195 g',
        '/media/652d626f6f6b.jpg', 2220.00, 1, 17)
     , (281137, 'Jeka CV8094',
        'Memory 8 Gb / Weight 29 g / Blue / MP3 / FM receiver / OGG / AVI / USB / MPEG-4 / SD slot / WMA / AMV',
        '/media/6d70332d706c61796572.jpg', 2070.00, 2, 6)
     , (281141, 'Nokia ID5569506',
        'Monitor diagonal 1.8" / Camera: 1Mp / RAM 64 Mb / 1600 mA/h / Silver / Weight 100 g / Dictophone / 2 Sim cards / Bluetooth',
        '/media/70686f6e65.jpg', 1710.00, 4, 25)
     , (281144, 'AirOn OFJ5589',
        'Monitor diagonal 1.3" / RAM: 512 Mb / Blue / 1200 mA/h / Weight 180 g / Bluetooth / USB / GPS',
        '/media/736d6172747761746368.jpg', 1150.00, 6, 11)
     , (281145, 'Apple BB1293837',
        'Memory 4 Gb / Weight 71 g / Black / MP3 / Dictophone / USB / MPEG-4 / WAV / WMA / OGG / AVI / FM receiver / AMV',
        '/media/6d70332d706c61796572.jpg', 610.00, 2, 15)
     , (281153, 'Prestigio ICL0412215',
        'Monitor diagonal 6.0" / Camera: 2.2Mp / RAM: 512 Mb / Blue / 2000 mA/h / Weight 720 g / Dictophone / 2 Sim cards / GPS / USB / Bluetooth / FM receiver / 3G',
        '/media/736d61727470686f6e65.jpg', 2700.00, 5, 10)
     , (281157, 'LG GC5031',
        'Monitor diagonal 2.0" / Camera: 1Mp / RAM 32 Mb / 1100 mA/h / Black / Weight 280 g / 2 Sim cards / Bluetooth / SD',
        '/media/70686f6e65.jpg', 2450.00, 4, 21)
     , (281165, 'Dell LCR5325042',
        'Monitor 7" / RAM 1 GB / HDD 350 GB / Silver / Weight 100 g / WiFi / Webcam / Bluetooth',
        '/media/7461626c6574.jpg', 1070.00, 7, 1)
     , (281169, 'LG HFU81266',
        'Monitor diagonal 3.8" / Camera: 4.0Mp / RAM: 512 Mb / Blue / 1400 mA/h / Weight 480 g / USB / 2 Sim cards / Dictophone / WiFi',
        '/media/736d61727470686f6e65.jpg', 2850.00, 5, 21)
     , (281170, 'Sony UE40965975',
        'Monitor 8" / RAM 3 GB / HDD 400 GB / Black / Weight 180 g / GPS / Webcam / WiFi / 3G / HDMI',
        '/media/7461626c6574.jpg', 2090.00, 7, 8)
     , (281174, 'Dell CP8761423',
        'Monitor 18" / Intel Core I3 (1.6 GHz) / RAM 1 GB / HDD 560 GB / Weight 2.4 kg / USB / LAN / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 1660.00, 3, 1)
     , (281177, 'Lenovo DMR301691',
        'Monitor diagonal 3.8" / Camera: 3.2Mp / RAM: 2 Gb / Blue / 2000 mA/h / Weight 640 g / USB / FM receiver / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 2150.00, 5, 9)
     , (281185, 'PocketBook OR501555',
        'Monitor diagonal 10" / Matrix type: E lnk Carta / Resolution: 800x600 / Memory 4 GB / Weight 160 g',
        '/media/652d626f6f6b.jpg', 1470.00, 1, 17)
     , (281191, 'Dell DHK957295',
        'Monitor 7" / RAM 3 GB / HDD 680 GB / Blue / Weight 220 g / GPS / USB / HDMI / Bluetooth',
        '/media/7461626c6574.jpg', 90.00, 7, 1)
     , (281196, 'Samsung BVK04851',
        'Monitor 8" / RAM 4 GB / HDD 660 GB / Blue / Weight 180 g / USB / GPS / WiFi / Webcam / HDMI',
        '/media/7461626c6574.jpg', 2390.00, 7, 22)
     , (281203, 'Jeka QKK827433', 'Memory 16 Gb / Weight 23 g / Silver / MP3 / Dictophone / MPEG-4 / USB / WMA',
        '/media/6d70332d706c61796572.jpg', 1940.00, 2, 6)
     , (281209, 'Jeka MD36388', 'Memory 16 Gb / Weight 89 g / Black / MP3 / Bluetooth / OGG / SD slot / WMA / WAV',
        '/media/6d70332d706c61796572.jpg', 450.00, 2, 6)
     , (281210, 'Samsung TP6216',
        'Monitor diagonal 2.6" / Camera: 1Mp / RAM 16 Mb / 1600 mA/h / Black / Weight 180 g / USB / 2 Sim cards / Bluetooth',
        '/media/70686f6e65.jpg', 420.00, 4, 22)
     , (281219, 'Philips MTE29346793',
        'Monitor diagonal 2.8" / Camera: 2.2Mp / RAM 16 Mb / 1400 mA/h / Blue / Weight 380 g / Dictophone / Bluetooth / SD',
        '/media/70686f6e65.jpg', 2680.00, 4, 18)
     , (281224, 'Apple UE109484',
        'Monitor 19" / Intel Core I5 (2.8 GHz) / RAM 15 GB / HDD 720 GB / Weight 6.6 kg / DVD+/-RW / HDMI / Bluetooth',
        '/media/6e6f7465626f6f6b.jpg', 1670.00, 3, 15)
     , (281226, 'Huawei FHC95412',
        'Monitor diagonal 3.2" / Camera: 4.0Mp / RAM: 512 Mb / White / 1200 mA/h / Weight 800 g / FM receiver / Dictophone / USB / Bluetooth / 3G / WiFi / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 380.00, 5, 24)
     , (281232, 'Dell PJD1906',
        'Monitor 18" / Intel Core I5 (2.0 GHz) / RAM 13 GB / HDD 760 GB / Weight 4.4 kg / LAN / Intel HD Graphics / WiFi / HDMI / Webcam / DVD+/-RW / USB',
        '/media/6e6f7465626f6f6b.jpg', 2990.00, 3, 1)
     , (281234, 'Prestigio JDV71107904',
        'Monitor 9" / RAM 1 GB / HDD 440 GB / Orange / Weight 300 g / 3G / Webcam / WiFi / Bluetooth',
        '/media/7461626c6574.jpg', 2620.00, 7, 10)
     , (281239, 'LG LSL4326',
        'Monitor diagonal 5.0" / Camera: 2.2Mp / RAM: 2 Gb / Orange / 1300 mA/h / Weight 400 g / Bluetooth / FM receiver / 2 Sim cards / WiFi / USB / 3G',
        '/media/736d61727470686f6e65.jpg', 1650.00, 5, 21)
     , (281246, 'Samsung LR86814',
        'Monitor diagonal 1.4" / RAM: 256 Mb / Silver / 1700 mA/h / Weight 140 g / Bluetooth / WiFi / GPS',
        '/media/736d6172747761746368.jpg', 1110.00, 6, 22)
     , (281250, 'Nokia SCJ6031065',
        'Monitor diagonal 5.6" / Camera: 2.2Mp / RAM: 1 Gb / Orange / 2000 mA/h / Weight 520 g / Dictophone / WiFi / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 990.00, 5, 25)
     , (281256, 'Lenovo ED9819',
        'Monitor 22" / Intel Core I7 (2.8 GHz) / RAM 7 GB / HDD 670 GB / Weight 5.6 kg / Intel HD Graphics / Bluetooth / LAN / HDMI',
        '/media/6e6f7465626f6f6b.jpg', 250.00, 3, 9)
     , (281260, 'LG KLS616240',
        'Monitor diagonal 2.0" / Camera: 1Mp / RAM 64 Mb / 1000 mA/h / Silver / Weight 80 g / Dictophone / 2 Sim cards / USB',
        '/media/70686f6e65.jpg', 520.00, 4, 21)
     , (281267, 'LG RH8090',
        'Monitor diagonal 5.0" / Camera: 3.2Mp / RAM: 4 Gb / Silver / 1700 mA/h / Weight 760 g / Bluetooth / 2 Sim cards / Dictophone',
        '/media/736d61727470686f6e65.jpg', 1540.00, 5, 21)
     , (281273, 'FiiO SNG13025554', 'Memory 16 Gb / Weight 80 g / Silver / MP3 / MPEG-4 / Dictophone / AVI',
        '/media/6d70332d706c61796572.jpg', 2020.00, 2, 2)
     , (281275, 'LG VG401125',
        'Monitor diagonal 2.6" / Camera: 2.6Mp / RAM 32 Mb / 1400 mA/h / Silver / Weight 300 g / SD / USB / Dictophone',
        '/media/70686f6e65.jpg', 1050.00, 4, 21)
     , (281278, 'Lenovo JMI47300440',
        'Monitor 11" / Intel Core I5 (2.0 GHz) / RAM 9 GB / HDD 360 GB / Weight 3.0 kg / Webcam / WiFi / Intel HD Graphics',
        '/media/6e6f7465626f6f6b.jpg', 830.00, 3, 9)
     , (281280, 'Apple GN7836470',
        'Monitor 15" / Intel Core I5 (2.6 GHz) / RAM 9 GB / HDD 60 GB / Weight 6.0 kg / Webcam / HDMI / Intel HD Graphics',
        '/media/6e6f7465626f6f6b.jpg', 1860.00, 3, 15)
     , (281290, 'Huawei TN62091738',
        'Monitor diagonal 3.8" / Camera: 2.2Mp / RAM: 4 Gb / White / 1400 mA/h / Weight 440 g / Dictophone / USB / WiFi',
        '/media/736d61727470686f6e65.jpg', 250.00, 5, 24)
     , (281296, 'Sony KIK96720245',
        'Monitor 9" / RAM 1 GB / HDD 150 GB / Silver / Weight 140 g / 3G / GPS / Webcam / USB / WiFi / Bluetooth',
        '/media/7461626c6574.jpg', 1870.00, 7, 8)
     , (281301, 'Apple VAM9781083',
        'Monitor 16" / Intel Core I3 (2.4 GHz) / RAM 5 GB / HDD 200 GB / Weight 4.0 kg / Webcam / LAN / Bluetooth / USB / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 460.00, 3, 15)
     , (281303, 'HTC GFH77880',
        'Monitor diagonal 5.0" / Camera: 2.2Mp / RAM: 1 Gb / Black / 1700 mA/h / Weight 600 g / Bluetooth / 3G / USB',
        '/media/736d61727470686f6e65.jpg', 150.00, 5, 19)
     , (281312, 'LG DAV97332184',
        'Monitor diagonal 4.4" / Camera: 2.2Mp / RAM: 512 Mb / White / 1100 mA/h / Weight 760 g / 2 Sim cards / FM receiver / Dictophone',
        '/media/736d61727470686f6e65.jpg', 2440.00, 5, 21)
     , (281321, 'EvroMedia CRD15761092',
        'Monitor diagonal 10" / Matrix type: E lnk / Resolution: 1024x758 / Memory 7 GB / Weight 175 g',
        '/media/652d626f6f6b.jpg', 1740.00, 1, 12)
     , (281326, 'EvroMedia VS833332',
        'Monitor diagonal 10" / Matrix type: E lnk Pearl / Resolution: 1024x758 / Memory 4 GB / Weight 195 g',
        '/media/652d626f6f6b.jpg', 1070.00, 1, 12)
     , (281331, 'FixiTime NVA65289077',
        'Monitor diagonal 1.5" / RAM: 1 Gb / White / 1000 mA/h / Weight 140 g / Dictophone / GPS / USB',
        '/media/736d6172747761746368.jpg', 640.00, 6, 16)
     , (281340, 'HTC DVB387427',
        'Monitor diagonal 4.4" / Camera: 3.0Mp / RAM: 2 Gb / Black / 1900 mA/h / Weight 480 g / FM receiver / 3G / WiFi / USB / Dictophone / GPS',
        '/media/736d61727470686f6e65.jpg', 2640.00, 5, 19)
     , (281349, 'Lenovo EN682202',
        'Monitor diagonal 6.0" / Camera: 3.0Mp / RAM: 1 Gb / Black / 1400 mA/h / Weight 320 g / WiFi / Dictophone / USB / 3G / GPS / 2 Sim cards / FM receiver',
        '/media/736d61727470686f6e65.jpg', 380.00, 5, 9)
     , (281357, 'LG MTA0691',
        'Monitor diagonal 5.0" / Camera: 3.2Mp / RAM: 512 Mb / Orange / 1800 mA/h / Weight 520 g / FM receiver / WiFi / USB',
        '/media/736d61727470686f6e65.jpg', 280.00, 5, 21)
     , (281362, 'Apple EMD67933', 'Monitor 7" / RAM 2 GB / HDD 80 GB / White / Weight 300 g / WiFi / Webcam / HDMI',
        '/media/7461626c6574.jpg', 2570.00, 7, 15)
     , (281366, 'Samsung AFP095395',
        'Monitor diagonal 1.8" / Camera: 2.2Mp / RAM 48 Mb / 1000 mA/h / Blue / Weight 80 g / Bluetooth / USB / SD',
        '/media/70686f6e65.jpg', 2090.00, 4, 22)
     , (281376, 'Gigabyte SCB52651139',
        'Monitor diagonal 2.4" / Camera: 1.8Mp / RAM 48 Mb / 1000 mA/h / Black / Weight 280 g / USB / Bluetooth / 2 Sim cards',
        '/media/70686f6e65.jpg', 1410.00, 4, 4)
     , (281383, 'Prestigio MRJ3647', 'Monitor 8" / RAM 1 GB / HDD 580 GB / Silver / Weight 220 g / Webcam / HDMI / GPS',
        '/media/7461626c6574.jpg', 1150.00, 7, 10)
     , (281390, 'Philips JS5521',
        'Monitor diagonal 2.0" / Camera: 1.8Mp / RAM 64 Mb / 2000 mA/h / Blue / Weight 180 g / Bluetooth / USB / SD',
        '/media/70686f6e65.jpg', 850.00, 4, 18)
     , (281395, 'Sony LA9323', 'Monitor 8" / RAM 2 GB / HDD 110 GB / Blue / Weight 60 g / WiFi / HDMI / 3G',
        '/media/7461626c6574.jpg', 550.00, 7, 8)
     , (281403, 'AirOn TSK0201256',
        'Monitor diagonal 1.2" / RAM: 512 Mb / Black / 1300 mA/h / Weight 60 g / Bluetooth / USB / Dictophone',
        '/media/736d6172747761746368.jpg', 2830.00, 6, 11)
     , (281407, 'Dell ETB4036', 'Monitor 8" / RAM 4 GB / HDD 260 GB / White / Weight 180 g / 3G / WiFi / USB / GPS',
        '/media/7461626c6574.jpg', 2160.00, 7, 1)
     , (281415, 'HTC LO85236110',
        'Monitor diagonal 3.8" / Camera: 3.2Mp / RAM: 512 Mb / Blue / 1600 mA/h / Weight 680 g / Bluetooth / WiFi / FM receiver',
        '/media/736d61727470686f6e65.jpg', 2390.00, 5, 19)
     , (281421, 'PocketBook DL049715', 'Monitor 7" / RAM 4 GB / HDD 680 GB / Orange / Weight 260 g / Webcam / GPS / 3G',
        '/media/7461626c6574.jpg', 2050.00, 7, 17)
     , (281422, 'EvroMedia ARJ5054',
        'Monitor diagonal 9" / Matrix type: E lnk Carta / Resolution: 1200x800 / Memory 8 GB / Weight 155 g',
        '/media/652d626f6f6b.jpg', 2850.00, 1, 12)
     , (281424, 'FiiO HLG470908',
        'Memory 4 Gb / Weight 71 g / White / MP3 / MPEG-4 / Dictophone / USB / WAV / AVI / OGG / FM receiver / AMV / WMA / Bluetooth',
        '/media/6d70332d706c61796572.jpg', 2710.00, 2, 2)
     , (281430, 'Sony QKU26229', 'Memory 4 Gb / Weight 56 g / White / MP3 / SD slot / OGG / Bluetooth',
        '/media/6d70332d706c61796572.jpg', 450.00, 2, 8)
     , (281433, 'Acer NR5217688',
        'Monitor 11" / Intel Core I3 (2.2 GHz) / RAM 10 GB / HDD 220 GB / Weight 6.6 kg / LAN / Bluetooth / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 2570.00, 3, 14)
     , (281436, 'Samsung AMQ077528',
        'Monitor diagonal 5.0" / Camera: 3.0Mp / RAM: 2 Gb / Orange / 1300 mA/h / Weight 800 g / USB / GPS / FM receiver',
        '/media/736d61727470686f6e65.jpg', 1110.00, 5, 22)
     , (281443, 'Jeka TET70148292', 'Memory 8 Gb / Weight 53 g / White / MP3 / FM receiver / USB / Bluetooth',
        '/media/6d70332d706c61796572.jpg', 1870.00, 2, 6)
     , (281445, 'PocketBook FN9256120',
        'Monitor 7" / RAM 3 GB / HDD 280 GB / White / Weight 260 g / WiFi / 3G / USB / Bluetooth / Webcam / HDMI',
        '/media/7461626c6574.jpg', 2190.00, 7, 17)
     , (281453, 'Apple SQT1263222',
        'Monitor diagonal 1.6" / RAM: 512 Mb / Blue / 1600 mA/h / Weight 60 g / Bluetooth / WiFi / GPS',
        '/media/736d6172747761746368.jpg', 1060.00, 6, 15)
     , (281700, 'Amazon FDV0440440',
        'Monitor diagonal 6" / Matrix type: E lnk / Resolution: 800x600 / Memory 11 GB / Weight 185 g',
        '/media/652d626f6f6b.jpg', 140.00, 1, 23)
     , (281463, 'Samsung SOK9369',
        'Monitor diagonal 5.6" / Camera: 2.2Mp / RAM: 512 Mb / Black / 1500 mA/h / Weight 360 g / 3G / 2 Sim cards / WiFi / GPS / Bluetooth / FM receiver',
        '/media/736d61727470686f6e65.jpg', 2840.00, 5, 22)
     , (281472, 'Samsung BJP252997',
        'Monitor diagonal 2.6" / Camera: 1Mp / RAM 16 Mb / 1200 mA/h / Black / Weight 320 g / Bluetooth / SD / 2 Sim cards',
        '/media/70686f6e65.jpg', 1800.00, 4, 22)
     , (281480, 'Apple KUQ3009', 'Monitor 9" / RAM 3 GB / HDD 740 GB / White / Weight 100 g / 3G / Webcam / HDMI / USB',
        '/media/7461626c6574.jpg', 1730.00, 7, 15)
     , (281481, 'Samsung JNK3553190',
        'Monitor diagonal 3.2" / Camera: 3.0Mp / RAM: 2 Gb / White / 2000 mA/h / Weight 480 g / USB / 2 Sim cards / 3G / FM receiver / Dictophone',
        '/media/736d61727470686f6e65.jpg', 60.00, 5, 22)
     , (281491, 'Samsung VR08796760',
        'Monitor diagonal 2.4" / Camera: 1.8Mp / RAM 48 Mb / 1800 mA/h / Blue / Weight 400 g / USB / SD / Bluetooth / 2 Sim cards',
        '/media/70686f6e65.jpg', 160.00, 4, 22)
     , (281495, 'Apple UBG13058543',
        'Memory 12 Gb / Weight 41 g / Black / MP3 / MPEG-4 / OGG / AVI / Dictophone / AMV / WAV',
        '/media/6d70332d706c61796572.jpg', 2490.00, 2, 15)
     , (281500, 'Huawei CG00163740',
        'Monitor diagonal 3.2" / Camera: 2.2Mp / RAM: 2 Gb / White / 1300 mA/h / Weight 480 g / WiFi / USB / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 2440.00, 5, 24)
     , (281507, 'Lenovo BI7662',
        'Monitor 20" / Intel Core I7 (2.8 GHz) / RAM 9 GB / HDD 370 GB / Weight 4.6 kg / Intel HD Graphics / DVD+/-RW / Bluetooth / LAN / HDMI / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 80.00, 3, 9)
     , (281515, 'Apple IM4483894',
        'Monitor 14" / Intel Core I7 (2.4 GHz) / RAM 9 GB / HDD 70 GB / Weight 6.2 kg / USB / Intel HD Graphics / Webcam / Bluetooth',
        '/media/6e6f7465626f6f6b.jpg', 1290.00, 3, 15)
     , (281521, 'PocketBook CFO6512',
        'Monitor diagonal 9" / Matrix type: E lnk / Resolution: 800x600 / Memory 5 GB / Weight 175 g',
        '/media/652d626f6f6b.jpg', 1080.00, 1, 17)
     , (281530, 'Apple BVK77410',
        'Memory 8 Gb / Weight 95 g / Black / MP3 / AMV / Bluetooth / AVI / OGG / Dictophone / WMA',
        '/media/6d70332d706c61796572.jpg', 1890.00, 2, 15)
     , (281540, 'Nokia RAO47914224',
        'Monitor diagonal 3.8" / Camera: 4.0Mp / RAM: 4 Gb / Orange / 1000 mA/h / Weight 720 g / 3G / USB / GPS',
        '/media/736d61727470686f6e65.jpg', 1910.00, 5, 25)
     , (281549, 'Prestigio VI15964045',
        'Monitor 8" / RAM 4 GB / HDD 760 GB / Silver / Weight 220 g / Webcam / HDMI / GPS / Bluetooth / USB / WiFi',
        '/media/7461626c6574.jpg', 1040.00, 7, 10)
     , (281552, 'Samsung TIK58452',
        'Monitor diagonal 1.6" / RAM: 512 Mb / Orange / 1500 mA/h / Weight 180 g / WiFi / Dictophone / GPS',
        '/media/736d6172747761746368.jpg', 70.00, 6, 22)
     , (281556, 'HTC SGN098090',
        'Monitor diagonal 4.4" / Camera: 3.2Mp / RAM: 1 Gb / Orange / 1900 mA/h / Weight 400 g / 2 Sim cards / Bluetooth / WiFi / 3G',
        '/media/736d61727470686f6e65.jpg', 2590.00, 5, 19)
     , (281563, 'Sony RTC36770063',
        'Monitor 8" / RAM 2 GB / HDD 290 GB / Blue / Weight 140 g / GPS / Webcam / Bluetooth / WiFi / 3G',
        '/media/7461626c6574.jpg', 2950.00, 7, 8)
     , (281565, 'Samsung GG99526',
        'Monitor diagonal 5.0" / Camera: 4.0Mp / RAM: 2 Gb / Silver / 1500 mA/h / Weight 480 g / USB / GPS / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 690.00, 5, 22)
     , (281574, 'Lenovo GGU578044',
        'Monitor diagonal 6.0" / Camera: 2.2Mp / RAM: 1 Gb / White / 1700 mA/h / Weight 560 g / Dictophone / Bluetooth / WiFi / USB / FM receiver / GPS / 3G',
        '/media/736d61727470686f6e65.jpg', 1750.00, 5, 9)
     , (281578, 'Dell KCJ8416', 'Monitor 10" / RAM 3 GB / HDD 120 GB / White / Weight 300 g / WiFi / 3G / Bluetooth',
        '/media/7461626c6574.jpg', 700.00, 7, 1)
     , (281579, 'Lenovo LB22565985',
        'Monitor 7" / RAM 4 GB / HDD 650 GB / Black / Weight 140 g / GPS / Bluetooth / Webcam',
        '/media/7461626c6574.jpg', 2690.00, 7, 9)
     , (281584, 'Dell PLM35598',
        'Monitor 20" / Intel Core I3 (1.6 GHz) / RAM 14 GB / HDD 270 GB / Weight 4.8 kg / HDMI / LAN / Bluetooth / Intel HD Graphics / USB / WiFi / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 1310.00, 3, 1)
     , (281591, 'PocketBook CI005629',
        'Monitor diagonal 9" / Matrix type: E lnk Carta / Resolution: 800x600 / Memory 12 GB / Weight 155 g',
        '/media/652d626f6f6b.jpg', 1910.00, 1, 17)
     , (281598, 'Transcend VVO7856075',
        'Memory 4 Gb / Weight 29 g / Orange / MP3 / Dictophone / AMV / SD slot / Bluetooth',
        '/media/6d70332d706c61796572.jpg', 680.00, 2, 5)
     , (281604, 'PocketBook UID37933410',
        'Monitor 7" / RAM 1 GB / HDD 480 GB / Orange / Weight 140 g / WiFi / HDMI / Bluetooth',
        '/media/7461626c6574.jpg', 1820.00, 7, 17)
     , (281611, 'Dell QA5341',
        'Monitor 15" / Intel Core I5 (2.6 GHz) / RAM 15 GB / HDD 570 GB / Weight 3.0 kg / USB / HDMI / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 1800.00, 3, 1)
     , (281616, 'Sony HFO17380', 'Memory 16 Gb / Weight 86 g / Black / MP3 / OGG / USB / WAV',
        '/media/6d70332d706c61796572.jpg', 1010.00, 2, 8)
     , (281623, 'Sony UCT8420',
        'Memory 12 Gb / Weight 89 g / Blue / MP3 / MPEG-4 / WAV / FM receiver / Dictophone / AVI',
        '/media/6d70332d706c61796572.jpg', 1770.00, 2, 8)
     , (281624, 'LG RGV1659043',
        'Monitor diagonal 5.0" / Camera: 3.2Mp / RAM: 512 Mb / White / 1300 mA/h / Weight 480 g / Bluetooth / 3G / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 710.00, 5, 21)
     , (281633, 'Amazon CNP750795',
        'Monitor diagonal 8" / Matrix type: E lnk / Resolution: 800x600 / Memory 7 GB / Weight 175 g',
        '/media/652d626f6f6b.jpg', 380.00, 1, 23)
     , (281639, 'Asus VE073744',
        'Monitor 15" / Intel Core I5 (2.6 GHz) / RAM 10 GB / HDD 580 GB / Weight 6.2 kg / DVD+/-RW / WiFi / LAN / HDMI',
        '/media/6e6f7465626f6f6b.jpg', 810.00, 3, 13)
     , (281645, 'Apple VP9342',
        'Monitor 11" / Intel Core I3 (1.6 GHz) / RAM 12 GB / HDD 160 GB / Weight 3.6 kg / Intel HD Graphics / USB / Bluetooth',
        '/media/6e6f7465626f6f6b.jpg', 2070.00, 3, 15)
     , (281648, 'Asus ROR6404527',
        'Monitor 15" / Intel Core I7 (2.6 GHz) / RAM 16 GB / HDD 620 GB / Weight 4.4 kg / Webcam / LAN / USB / WiFi',
        '/media/6e6f7465626f6f6b.jpg', 770.00, 3, 13)
     , (281651, 'Samsung KMG8246339',
        'Monitor diagonal 6.0" / Camera: 4.0Mp / RAM: 1 Gb / Orange / 2000 mA/h / Weight 600 g / Dictophone / GPS / 3G / USB',
        '/media/736d61727470686f6e65.jpg', 2070.00, 5, 22)
     , (281659, 'Fly IOK080064',
        'Monitor diagonal 5.0" / Camera: 2.2Mp / RAM: 1 Gb / Black / 1400 mA/h / Weight 760 g / USB / Dictophone / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 2760.00, 5, 7)
     , (281661, 'Fly EQ2519878',
        'Monitor diagonal 5.6" / Camera: 3.2Mp / RAM: 4 Gb / Black / 1800 mA/h / Weight 320 g / WiFi / USB / GPS / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 270.00, 5, 7)
     , (281668, 'Dell RAR53809', 'Monitor 7" / RAM 1 GB / HDD 540 GB / Black / Weight 180 g / WiFi / Webcam / HDMI',
        '/media/7461626c6574.jpg', 480.00, 7, 1)
     , (281674, 'Gigabyte BL19572371',
        'Monitor diagonal 1.8" / Camera: 1Mp / RAM 64 Mb / 1500 mA/h / Black / Weight 380 g / 2 Sim cards / Dictophone / SD',
        '/media/70686f6e65.jpg', 2330.00, 4, 4)
     , (281684, 'Samsung BOM6371',
        'Monitor diagonal 2.8" / Camera: 1.8Mp / RAM 16 Mb / 2000 mA/h / Blue / Weight 280 g / SD / Bluetooth / USB',
        '/media/70686f6e65.jpg', 2060.00, 4, 22)
     , (281694, 'HP MO5108',
        'Monitor 17" / Intel Core I3 (2.4 GHz) / RAM 11 GB / HDD 490 GB / Weight 4.4 kg / Webcam / Intel HD Graphics / HDMI / WiFi / Bluetooth / DVD+/-RW / USB',
        '/media/6e6f7465626f6f6b.jpg', 580.00, 3, 3)
     , (281698, 'Samsung HDB74263636', 'Monitor 8" / RAM 1 GB / HDD 600 GB / Blue / Weight 220 g / HDMI / GPS / USB',
        '/media/7461626c6574.jpg', 930.00, 7, 22)
     , (281703, 'LG MJ2625',
        'Monitor diagonal 6.0" / Camera: 3.0Mp / RAM: 4 Gb / White / 1900 mA/h / Weight 400 g / Dictophone / USB / 3G / GPS / FM receiver',
        '/media/736d61727470686f6e65.jpg', 1250.00, 5, 21)
     , (281710, 'Gigabyte IR5203259',
        'Monitor diagonal 2.6" / Camera: 2.6Mp / RAM 32 Mb / 1900 mA/h / White / Weight 120 g / Bluetooth / Dictophone / 2 Sim cards',
        '/media/70686f6e65.jpg', 360.00, 4, 4)
     , (281713, 'Lenovo KJN9344746',
        'Monitor 19" / Intel Core I3 (2.0 GHz) / RAM 7 GB / HDD 580 GB / Weight 5.6 kg / Webcam / Bluetooth / HDMI',
        '/media/6e6f7465626f6f6b.jpg', 2770.00, 3, 9)
     , (281718, 'HP COH43747456',
        'Monitor 23" / Intel Core I3 (2.2 GHz) / RAM 8 GB / HDD 520 GB / Weight 5.0 kg / Webcam / WiFi / HDMI',
        '/media/6e6f7465626f6f6b.jpg', 480.00, 3, 3)
     , (281727, 'Samsung HG33464647',
        'Monitor diagonal 1.8" / Camera: 1.8Mp / RAM 32 Mb / 1000 mA/h / Orange / Weight 240 g / 2 Sim cards / Bluetooth / SD / USB',
        '/media/70686f6e65.jpg', 1890.00, 4, 22)
     , (281730, 'AirBook NK56751',
        'Monitor diagonal 8" / Matrix type: E lnk / Resolution: 1024x758 / Memory 10 GB / Weight 200 g',
        '/media/652d626f6f6b.jpg', 2930.00, 1, 20)
     , (281735, 'Asus MI01830747',
        'Monitor 8" / RAM 2 GB / HDD 510 GB / Black / Weight 260 g / USB / 3G / Bluetooth / Webcam / WiFi',
        '/media/7461626c6574.jpg', 2820.00, 7, 13)
     , (281737, 'Transcend CFN5793', 'Memory 20 Gb / Weight 23 g / White / MP3 / AMV / FM receiver / WAV / WMA',
        '/media/6d70332d706c61796572.jpg', 1800.00, 2, 5)
     , (281746, 'Prestigio SO0933', 'Monitor 10" / RAM 2 GB / HDD 680 GB / Silver / Weight 140 g / USB / 3G / GPS',
        '/media/7461626c6574.jpg', 2130.00, 7, 10)
     , (281753, 'HP EP148779',
        'Monitor 15" / Intel Core I5 (2.8 GHz) / RAM 9 GB / HDD 310 GB / Weight 4.8 kg / HDMI / Intel HD Graphics / LAN / Bluetooth / WiFi / Webcam / USB',
        '/media/6e6f7465626f6f6b.jpg', 2500.00, 3, 3)
     , (281754, 'Dell MSG660274',
        'Monitor 16" / Intel Core I3 (1.6 GHz) / RAM 8 GB / HDD 240 GB / Weight 2.8 kg / LAN / USB / Intel HD Graphics',
        '/media/6e6f7465626f6f6b.jpg', 330.00, 3, 1)
     , (281762, 'HP QEN02524',
        'Monitor 20" / Intel Core I3 (2.0 GHz) / RAM 9 GB / HDD 470 GB / Weight 6.6 kg / Bluetooth / LAN / HDMI / WiFi / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 490.00, 3, 3)
     , (281766, 'Jeka RQ9770959',
        'Memory 8 Gb / Weight 98 g / Blue / MP3 / MPEG-4 / Bluetooth / AVI / USB / Dictophone',
        '/media/6d70332d706c61796572.jpg', 1590.00, 2, 6)
     , (281776, 'Dell JTF6650640',
        'Monitor 15" / Intel Core I7 (2.4 GHz) / RAM 1 GB / HDD 70 GB / Weight 3.0 kg / LAN / Webcam / Bluetooth / HDMI / Intel HD Graphics / USB / WiFi',
        '/media/6e6f7465626f6f6b.jpg', 1360.00, 3, 1)
     , (281783, 'Dell JIB30805',
        'Monitor 17" / Intel Core I3 (2.2 GHz) / RAM 10 GB / HDD 230 GB / Weight 3.6 kg / Intel HD Graphics / Bluetooth / DVD+/-RW / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 530.00, 3, 1)
     , (281784, 'Dell LJK2040203', 'Monitor 10" / RAM 4 GB / HDD 210 GB / Black / Weight 260 g / Bluetooth / 3G / GPS',
        '/media/7461626c6574.jpg', 180.00, 7, 1)
     , (281793, 'Samsung MT6626918',
        'Monitor diagonal 2.6" / Camera: 1Mp / RAM 64 Mb / 1900 mA/h / White / Weight 400 g / 2 Sim cards / SD / Bluetooth',
        '/media/70686f6e65.jpg', 1990.00, 4, 22)
     , (281802, 'Gigabyte HKR46989770',
        'Monitor diagonal 1.8" / Camera: 2.2Mp / RAM 16 Mb / 1600 mA/h / White / Weight 220 g / Bluetooth / 2 Sim cards / SD',
        '/media/70686f6e65.jpg', 2650.00, 4, 4)
     , (281803, 'PocketBook IGN7947672',
        'Monitor diagonal 7" / Matrix type: E lnk Pearl / Resolution: 800x600 / Memory 10 GB / Weight 185 g',
        '/media/652d626f6f6b.jpg', 700.00, 1, 17)
     , (281805, 'LG DU4625',
        'Monitor diagonal 2.2" / Camera: 1Mp / RAM 32 Mb / 1200 mA/h / Orange / Weight 80 g / 2 Sim cards / Dictophone / USB',
        '/media/70686f6e65.jpg', 2100.00, 4, 21)
     , (281807, 'Prestigio EA2553',
        'Monitor 9" / RAM 1 GB / HDD 310 GB / White / Weight 260 g / Bluetooth / GPS / HDMI', '/media/7461626c6574.jpg',
        1250.00, 7, 10)
     , (281814, 'Dell RJ14489678',
        'Monitor 19" / Intel Core I7 (2.6 GHz) / RAM 1 GB / HDD 370 GB / Weight 3.0 kg / LAN / HDMI / DVD+/-RW / WiFi / Intel HD Graphics',
        '/media/6e6f7465626f6f6b.jpg', 2460.00, 3, 1)
     , (281822, 'Dell GB178480',
        'Monitor 13" / Intel Core I7 (2.6 GHz) / RAM 16 GB / HDD 80 GB / Weight 6.4 kg / LAN / USB / WiFi / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 2680.00, 3, 1)
     , (281829, 'HP AL844710',
        'Monitor 13" / Intel Core I7 (2.0 GHz) / RAM 15 GB / HDD 420 GB / Weight 3.0 kg / DVD+/-RW / HDMI / WiFi',
        '/media/6e6f7465626f6f6b.jpg', 1050.00, 3, 3)
     , (281834, 'AirOn RME677881',
        'Monitor diagonal 1.2" / RAM: 512 Mb / Orange / 2000 mA/h / Weight 140 g / WiFi / GPS / Dictophone',
        '/media/736d6172747761746368.jpg', 2130.00, 6, 11)
     , (281839, 'LG CI9664180',
        'Monitor diagonal 6.0" / Camera: 2.2Mp / RAM: 1 Gb / Orange / 1500 mA/h / Weight 680 g / 2 Sim cards / Dictophone / FM receiver / GPS / USB / Bluetooth / 3G',
        '/media/736d61727470686f6e65.jpg', 2550.00, 5, 21)
     , (281845, 'Samsung QD7809', 'Monitor 8" / RAM 1 GB / HDD 640 GB / Silver / Weight 180 g / GPS / Bluetooth / USB',
        '/media/7461626c6574.jpg', 2880.00, 7, 22)
     , (281846, 'LG TE54170',
        'Monitor diagonal 3.2" / Camera: 2.2Mp / RAM: 2 Gb / White / 2000 mA/h / Weight 480 g / 3G / Dictophone / FM receiver',
        '/media/736d61727470686f6e65.jpg', 560.00, 5, 21)
     , (281855, 'Dell UIK108683',
        'Monitor 9" / RAM 1 GB / HDD 180 GB / Blue / Weight 260 g / USB / HDMI / GPS / Bluetooth / WiFi / 3G',
        '/media/7461626c6574.jpg', 1360.00, 7, 1)
     , (281863, 'Lenovo UM6813',
        'Monitor 19" / Intel Core I7 (2.4 GHz) / RAM 15 GB / HDD 370 GB / Weight 5.4 kg / DVD+/-RW / WiFi / HDMI / Webcam / USB / Intel HD Graphics',
        '/media/6e6f7465626f6f6b.jpg', 80.00, 3, 9)
     , (281864, 'Amazon HGM3301',
        'Monitor diagonal 7" / Matrix type: E lnk / Resolution: 800x600 / Memory 11 GB / Weight 195 g',
        '/media/652d626f6f6b.jpg', 410.00, 1, 23)
     , (281874, 'EvroMedia SA3348',
        'Monitor diagonal 11" / Matrix type: E lnk Carta / Resolution: 1200x800 / Memory 11 GB / Weight 200 g',
        '/media/652d626f6f6b.jpg', 1820.00, 1, 12)
     , (281876, 'Acer FIT48680810', 'Monitor 10" / RAM 4 GB / HDD 380 GB / Black / Weight 260 g / HDMI / Webcam / 3G',
        '/media/7461626c6574.jpg', 60.00, 7, 14)
     , (281877, 'Dell RHH34902',
        'Monitor 21" / Intel Core I3 (2.4 GHz) / RAM 3 GB / HDD 260 GB / Weight 4.8 kg / WiFi / HDMI / LAN / Bluetooth',
        '/media/6e6f7465626f6f6b.jpg', 130.00, 3, 1)
     , (281885, 'Prestigio PND4031445',
        'Monitor diagonal 2.0" / Camera: 1Mp / RAM 48 Mb / 1800 mA/h / White / Weight 400 g / SD / Bluetooth / Dictophone / USB',
        '/media/70686f6e65.jpg', 330.00, 4, 10)
     , (281889, 'Samsung NRP85901278',
        'Monitor diagonal 2.4" / Camera: 2.6Mp / RAM 64 Mb / 1600 mA/h / Black / Weight 60 g / Dictophone / 2 Sim cards / SD',
        '/media/70686f6e65.jpg', 2960.00, 4, 22)
     , (281891, 'HTC US199769',
        'Monitor diagonal 5.0" / Camera: 3.0Mp / RAM: 512 Mb / Blue / 1700 mA/h / Weight 640 g / 3G / WiFi / FM receiver / Bluetooth / Dictophone / GPS / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 960.00, 5, 19)
     , (281901, 'Apple HP8805',
        'Memory 4 Gb / Weight 47 g / White / MP3 / FM receiver / OGG / SD slot / WMA / AMV / MPEG-4',
        '/media/6d70332d706c61796572.jpg', 2760.00, 2, 15)
     , (281908, 'HP BSC7043668',
        'Monitor 16" / Intel Core I3 (2.6 GHz) / RAM 2 GB / HDD 520 GB / Weight 3.0 kg / WiFi / Bluetooth / HDMI',
        '/media/6e6f7465626f6f6b.jpg', 1590.00, 3, 3)
     , (281915, 'Prestigio EDM365906',
        'Monitor diagonal 6.0" / Camera: 3.2Mp / RAM: 4 Gb / White / 1900 mA/h / Weight 800 g / Bluetooth / FM receiver / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 2090.00, 5, 10)
     , (281919, 'Lenovo ETI8339',
        'Monitor diagonal 4.4" / Camera: 4.0Mp / RAM: 1 Gb / Silver / 1700 mA/h / Weight 680 g / Dictophone / Bluetooth / WiFi',
        '/media/736d61727470686f6e65.jpg', 1460.00, 5, 9)
     , (281927, 'EvroMedia DRM09691107',
        'Monitor diagonal 8" / Matrix type: E lnk / Resolution: 1200x800 / Memory 4 GB / Weight 155 g',
        '/media/652d626f6f6b.jpg', 1920.00, 1, 12)
     , (281929, 'LG QSO7280',
        'Monitor diagonal 3.0" / Camera: 2.6Mp / RAM 48 Mb / 1900 mA/h / Silver / Weight 240 g / SD / USB / Bluetooth / 2 Sim cards',
        '/media/70686f6e65.jpg', 1740.00, 4, 21)
     , (281938, 'EvroMedia OST167124',
        'Monitor diagonal 6" / Matrix type: E lnk / Resolution: 800x600 / Memory 4 GB / Weight 155 g',
        '/media/652d626f6f6b.jpg', 1480.00, 1, 12)
     , (281948, 'Samsung HJD24168923',
        'Monitor diagonal 1.7" / RAM: 256 Mb / Orange / 1800 mA/h / Weight 260 g / GPS / USB / WiFi',
        '/media/736d6172747761746368.jpg', 1590.00, 6, 22)
     , (281957, 'Apple SOV0834565', 'Monitor 9" / RAM 1 GB / HDD 200 GB / White / Weight 180 g / Webcam / HDMI / 3G',
        '/media/7461626c6574.jpg', 670.00, 7, 15)
     , (281965, 'Lenovo GM5765302',
        'Monitor diagonal 3.2" / Camera: 2.2Mp / RAM: 4 Gb / Silver / 1500 mA/h / Weight 680 g / 2 Sim cards / Bluetooth / USB',
        '/media/736d61727470686f6e65.jpg', 2840.00, 5, 9)
     , (281966, 'HTC UDV486218',
        'Monitor diagonal 5.6" / Camera: 2.2Mp / RAM: 512 Mb / Silver / 1800 mA/h / Weight 440 g / Bluetooth / 3G / GPS / 2 Sim cards / FM receiver / Dictophone',
        '/media/736d61727470686f6e65.jpg', 2160.00, 5, 19)
     , (281967, 'Dell PCU25238', 'Monitor 10" / RAM 1 GB / HDD 180 GB / Blue / Weight 220 g / 3G / GPS / HDMI',
        '/media/7461626c6574.jpg', 740.00, 7, 1)
     , (281976, 'Dell QPJ004883',
        'Monitor 12" / Intel Core I5 (2.6 GHz) / RAM 7 GB / HDD 360 GB / Weight 2.8 kg / WiFi / Bluetooth / HDMI / Webcam / Intel HD Graphics / USB',
        '/media/6e6f7465626f6f6b.jpg', 1990.00, 3, 1)
     , (281980, 'Dell DRJ78096',
        'Monitor 21" / Intel Core I7 (2.6 GHz) / RAM 9 GB / HDD 490 GB / Weight 6.2 kg / WiFi / Webcam / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 850.00, 3, 1)
     , (281981, 'Philips DOQ02899',
        'Monitor diagonal 2.4" / Camera: 2.6Mp / RAM 64 Mb / 1300 mA/h / Blue / Weight 300 g / USB / Bluetooth / 2 Sim cards',
        '/media/70686f6e65.jpg', 2720.00, 4, 18)
     , (281982, 'HTC SHV7724',
        'Monitor diagonal 5.6" / Camera: 3.0Mp / RAM: 2 Gb / Black / 1000 mA/h / Weight 480 g / USB / GPS / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 1300.00, 5, 19)
     , (281989, 'LG BTH5675687',
        'Monitor diagonal 5.0" / Camera: 4.0Mp / RAM: 2 Gb / Silver / 1500 mA/h / Weight 760 g / 2 Sim cards / WiFi / Dictophone',
        '/media/736d61727470686f6e65.jpg', 1730.00, 5, 21)
     , (281994, 'Huawei UEP4746274',
        'Monitor diagonal 6.0" / Camera: 4.0Mp / RAM: 4 Gb / Black / 1600 mA/h / Weight 680 g / WiFi / Dictophone / 2 Sim cards / USB / GPS / Bluetooth / FM receiver',
        '/media/736d61727470686f6e65.jpg', 2710.00, 5, 24)
     , (282001, 'Samsung CGI1537',
        'Monitor diagonal 2.2" / Camera: 2.6Mp / RAM 64 Mb / 1500 mA/h / White / Weight 360 g / Bluetooth / SD / Dictophone',
        '/media/70686f6e65.jpg', 2460.00, 4, 22)
     , (282002, 'Apple RKR0512',
        'Monitor 7" / RAM 3 GB / HDD 380 GB / Blue / Weight 220 g / GPS / 3G / Bluetooth / HDMI / USB',
        '/media/7461626c6574.jpg', 250.00, 7, 15)
     , (282009, 'Dell VS452254',
        'Monitor 17" / Intel Core I3 (2.4 GHz) / RAM 5 GB / HDD 380 GB / Weight 4.6 kg / LAN / USB / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 360.00, 3, 1)
     , (282012, 'AirBook JOL898056',
        'Monitor diagonal 8" / Matrix type: E lnk / Resolution: 1600x1200 / Memory 9 GB / Weight 175 g',
        '/media/652d626f6f6b.jpg', 1960.00, 1, 20)
     , (282021, 'Huawei IFT8685',
        'Monitor diagonal 3.8" / Camera: 3.2Mp / RAM: 1 Gb / Blue / 1800 mA/h / Weight 720 g / Dictophone / 2 Sim cards / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 290.00, 5, 24)
     , (282028, 'Asus PPF66825724',
        'Monitor 22" / Intel Core I5 (2.4 GHz) / RAM 12 GB / HDD 230 GB / Weight 4.6 kg / Bluetooth / DVD+/-RW / USB / HDMI / Webcam / Intel HD Graphics / LAN',
        '/media/6e6f7465626f6f6b.jpg', 2200.00, 3, 13)
     , (282038, 'Lenovo DD712191', 'Monitor 7" / RAM 2 GB / HDD 760 GB / Blue / Weight 180 g / 3G / GPS / WiFi',
        '/media/7461626c6574.jpg', 2380.00, 7, 9)
     , (282040, 'FixiTime EQB0906943',
        'Monitor diagonal 1.5" / RAM: 512 Mb / Blue / 2000 mA/h / Weight 300 g / Bluetooth / USB / Dictophone',
        '/media/736d6172747761746368.jpg', 2240.00, 6, 16)
     , (282043, 'HP MKO382177',
        'Monitor 12" / Intel Core I3 (2.4 GHz) / RAM 3 GB / HDD 380 GB / Weight 5.0 kg / USB / Intel HD Graphics / DVD+/-RW / LAN / Webcam / WiFi',
        '/media/6e6f7465626f6f6b.jpg', 1240.00, 3, 3)
     , (282051, 'Dell KS6032400',
        'Monitor 23" / Intel Core I3 (2.6 GHz) / RAM 15 GB / HDD 370 GB / Weight 2.4 kg / LAN / DVD+/-RW / Intel HD Graphics',
        '/media/6e6f7465626f6f6b.jpg', 1920.00, 3, 1)
     , (282060, 'Prestigio FSI38637596',
        'Monitor diagonal 3.8" / Camera: 3.2Mp / RAM: 512 Mb / Orange / 1900 mA/h / Weight 440 g / Dictophone / Bluetooth / WiFi / 2 Sim cards / 3G / FM receiver',
        '/media/736d61727470686f6e65.jpg', 470.00, 5, 10)
     , (282061, 'HP VAI760997',
        'Monitor 13" / Intel Core I7 (2.0 GHz) / RAM 12 GB / HDD 610 GB / Weight 5.8 kg / HDMI / Bluetooth / DVD+/-RW / Intel HD Graphics',
        '/media/6e6f7465626f6f6b.jpg', 2240.00, 3, 3)
     , (282063, 'Samsung FN8044403', 'Monitor 10" / RAM 3 GB / HDD 490 GB / Blue / Weight 140 g / Webcam / 3G / GPS',
        '/media/7461626c6574.jpg', 1920.00, 7, 22)
     , (282065, 'Apple AB92050550',
        'Monitor 20" / Intel Core I5 (2.6 GHz) / RAM 6 GB / HDD 620 GB / Weight 2.4 kg / Intel HD Graphics / HDMI / USB / LAN / WiFi / Bluetooth / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 1670.00, 3, 15)
     , (282075, 'Dell BL0739',
        'Monitor 20" / Intel Core I7 (2.8 GHz) / RAM 9 GB / HDD 760 GB / Weight 6.4 kg / DVD+/-RW / HDMI / LAN / Webcam / Intel HD Graphics / Bluetooth',
        '/media/6e6f7465626f6f6b.jpg', 1280.00, 3, 1)
     , (282076, 'Philips BO2421',
        'Monitor diagonal 2.4" / Camera: 2.2Mp / RAM 16 Mb / 1700 mA/h / White / Weight 320 g / Bluetooth / Dictophone / SD',
        '/media/70686f6e65.jpg', 1020.00, 4, 18)
     , (282086, 'Lenovo LJ833914',
        'Monitor 7" / RAM 2 GB / HDD 370 GB / Orange / Weight 220 g / Bluetooth / HDMI / WiFi',
        '/media/7461626c6574.jpg', 1580.00, 7, 9)
     , (282095, 'Samsung NVH2066099',
        'Monitor diagonal 3.8" / Camera: 2.2Mp / RAM: 4 Gb / Silver / 1300 mA/h / Weight 360 g / 3G / USB / FM receiver / WiFi / Bluetooth / GPS',
        '/media/736d61727470686f6e65.jpg', 310.00, 5, 22)
     , (282099, 'Sony AV5638164',
        'Monitor diagonal 3.2" / Camera: 4.0Mp / RAM: 4 Gb / Silver / 1200 mA/h / Weight 320 g / 3G / WiFi / Dictophone',
        '/media/736d61727470686f6e65.jpg', 1670.00, 5, 8)
     , (282107, 'FiiO EU698386', 'Memory 4 Gb / Weight 23 g / Blue / MP3 / SD slot / WAV / MPEG-4',
        '/media/6d70332d706c61796572.jpg', 2280.00, 2, 2)
     , (282109, 'Lenovo HHH249944',
        'Monitor diagonal 4.4" / Camera: 3.2Mp / RAM: 4 Gb / Black / 1200 mA/h / Weight 640 g / GPS / Dictophone / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 1430.00, 5, 9)
     , (282119, 'Philips LJ9968',
        'Monitor diagonal 1.8" / Camera: 1.8Mp / RAM 32 Mb / 1300 mA/h / Orange / Weight 260 g / SD / 2 Sim cards / USB',
        '/media/70686f6e65.jpg', 1080.00, 4, 18)
     , (282124, 'Sony FT209366', 'Memory 20 Gb / Weight 29 g / Orange / MP3 / OGG / USB / Dictophone',
        '/media/6d70332d706c61796572.jpg', 210.00, 2, 8)
     , (282129, 'Acer FB151888',
        'Monitor 10" / RAM 3 GB / HDD 550 GB / Orange / Weight 220 g / WiFi / HDMI / USB / Bluetooth / 3G',
        '/media/7461626c6574.jpg', 170.00, 7, 14)
     , (282139, 'Lenovo GG0494',
        'Monitor 23" / Intel Core I3 (1.8 GHz) / RAM 13 GB / HDD 370 GB / Weight 2.6 kg / Bluetooth / DVD+/-RW / WiFi / LAN',
        '/media/6e6f7465626f6f6b.jpg', 1190.00, 3, 9)
     , (282148, 'Samsung PR929855',
        'Monitor diagonal 3.0" / Camera: 2.6Mp / RAM 16 Mb / 1300 mA/h / Silver / Weight 400 g / SD / Bluetooth / 2 Sim cards',
        '/media/70686f6e65.jpg', 1740.00, 4, 22)
     , (282151, 'Prestigio GDU841928',
        'Monitor 8" / RAM 1 GB / HDD 380 GB / Silver / Weight 100 g / USB / HDMI / Webcam', '/media/7461626c6574.jpg',
        1130.00, 7, 10)
     , (282157, 'Sony MU723334',
        'Monitor diagonal 3.8" / Camera: 3.2Mp / RAM: 4 Gb / White / 1100 mA/h / Weight 600 g / USB / GPS / 2 Sim cards / WiFi / 3G / FM receiver / Dictophone',
        '/media/736d61727470686f6e65.jpg', 2860.00, 5, 8)
     , (282160, 'HP UND079303',
        'Monitor 20" / Intel Core I5 (2.2 GHz) / RAM 4 GB / HDD 480 GB / Weight 4.6 kg / WiFi / Webcam / Intel HD Graphics',
        '/media/6e6f7465626f6f6b.jpg', 2610.00, 3, 3)
     , (282166, 'Amazon APF3349682',
        'Monitor diagonal 10" / Matrix type: E lnk Pearl / Resolution: 800x600 / Memory 7 GB / Weight 200 g',
        '/media/652d626f6f6b.jpg', 2570.00, 1, 23)
     , (282176, 'LG ANC1271184',
        'Monitor diagonal 2.0" / Camera: 1Mp / RAM 64 Mb / 1300 mA/h / Orange / Weight 120 g / SD / 2 Sim cards / Bluetooth',
        '/media/70686f6e65.jpg', 1930.00, 4, 21)
     , (282178, 'HP QA8686',
        'Monitor 21" / Intel Core I5 (2.8 GHz) / RAM 8 GB / HDD 710 GB / Weight 3.8 kg / HDMI / WiFi / Intel HD Graphics / DVD+/-RW / USB / Webcam / Bluetooth',
        '/media/6e6f7465626f6f6b.jpg', 280.00, 3, 3)
     , (282184, 'Samsung BV419027',
        'Monitor diagonal 6.0" / Camera: 4.0Mp / RAM: 2 Gb / Black / 1800 mA/h / Weight 640 g / Dictophone / Bluetooth / USB',
        '/media/736d61727470686f6e65.jpg', 1340.00, 5, 22)
     , (282192, 'HP NEE1117752',
        'Monitor 22" / Intel Core I7 (2.8 GHz) / RAM 12 GB / HDD 700 GB / Weight 4.2 kg / DVD+/-RW / Webcam / LAN',
        '/media/6e6f7465626f6f6b.jpg', 2430.00, 3, 3)
     , (282202, 'LG KU47513200',
        'Monitor diagonal 4.4" / Camera: 3.0Mp / RAM: 2 Gb / Black / 1000 mA/h / Weight 520 g / USB / FM receiver / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 2050.00, 5, 21)
     , (282204, 'Samsung MG75474',
        'Monitor diagonal 2.8" / Camera: 2.6Mp / RAM 32 Mb / 1400 mA/h / Silver / Weight 120 g / Bluetooth / Dictophone / USB / 2 Sim cards',
        '/media/70686f6e65.jpg', 1930.00, 4, 22)
     , (282214, 'Samsung OV40272616',
        'Monitor 9" / RAM 4 GB / HDD 330 GB / Blue / Weight 260 g / 3G / Webcam / Bluetooth / WiFi / GPS / HDMI',
        '/media/7461626c6574.jpg', 1230.00, 7, 22)
     , (282223, 'Gigabyte UA5584477',
        'Monitor diagonal 2.6" / Camera: 1.8Mp / RAM 64 Mb / 1800 mA/h / Black / Weight 280 g / 2 Sim cards / Dictophone / Bluetooth',
        '/media/70686f6e65.jpg', 2200.00, 4, 4)
     , (282232, 'Gigabyte NAK96484217',
        'Monitor diagonal 3.0" / Camera: 1.8Mp / RAM 64 Mb / 1500 mA/h / Blue / Weight 180 g / SD / Bluetooth / Dictophone',
        '/media/70686f6e65.jpg', 1670.00, 4, 4)
     , (282237, 'Apple FMR234443',
        'Monitor 20" / Intel Core I5 (2.6 GHz) / RAM 2 GB / HDD 160 GB / Weight 3.8 kg / Bluetooth / DVD+/-RW / USB / Webcam / Intel HD Graphics',
        '/media/6e6f7465626f6f6b.jpg', 2930.00, 3, 15)
     , (282239, 'Lenovo DST27784918',
        'Monitor diagonal 5.0" / Camera: 4.0Mp / RAM: 4 Gb / White / 1600 mA/h / Weight 600 g / 2 Sim cards / GPS / FM receiver',
        '/media/736d61727470686f6e65.jpg', 820.00, 5, 9)
     , (282244, 'Asus FD31666', 'Monitor 9" / RAM 3 GB / HDD 570 GB / White / Weight 100 g / HDMI / Webcam / GPS',
        '/media/7461626c6574.jpg', 110.00, 7, 13)
     , (282252, 'Prestigio ET1344',
        'Monitor diagonal 2.6" / Camera: 2.6Mp / RAM 48 Mb / 1800 mA/h / Black / Weight 260 g / Bluetooth / 2 Sim cards / Dictophone',
        '/media/70686f6e65.jpg', 760.00, 4, 10)
     , (282262, 'AirBook PKV435007',
        'Monitor diagonal 6" / Matrix type: E lnk Carta / Resolution: 800x600 / Memory 7 GB / Weight 190 g',
        '/media/652d626f6f6b.jpg', 790.00, 1, 20)
     , (282265, 'PocketBook HK812529',
        'Monitor diagonal 8" / Matrix type: E lnk / Resolution: 1600x1200 / Memory 6 GB / Weight 200 g',
        '/media/652d626f6f6b.jpg', 2630.00, 1, 17)
     , (282273, 'Dell MVJ10578',
        'Monitor 10" / RAM 1 GB / HDD 530 GB / Silver / Weight 220 g / Webcam / USB / GPS / 3G',
        '/media/7461626c6574.jpg', 1350.00, 7, 1)
     , (282279, 'Asus SPQ87639', 'Monitor 9" / RAM 4 GB / HDD 720 GB / Blue / Weight 180 g / USB / WiFi / HDMI',
        '/media/7461626c6574.jpg', 2330.00, 7, 13)
     , (282283, 'Apple MQ357475',
        'Monitor 14" / Intel Core I3 (2.4 GHz) / RAM 15 GB / HDD 510 GB / Weight 3.6 kg / Bluetooth / Webcam / Intel HD Graphics / WiFi / DVD+/-RW / HDMI',
        '/media/6e6f7465626f6f6b.jpg', 1710.00, 3, 15)
     , (282287, 'Lenovo VT0326317',
        'Monitor 21" / Intel Core I5 (2.4 GHz) / RAM 9 GB / HDD 630 GB / Weight 4.0 kg / HDMI / USB / LAN / Bluetooth',
        '/media/6e6f7465626f6f6b.jpg', 2980.00, 3, 9)
     , (282297, 'EvroMedia SN451881',
        'Monitor diagonal 8" / Matrix type: E lnk Pearl / Resolution: 800x600 / Memory 10 GB / Weight 165 g',
        '/media/652d626f6f6b.jpg', 1570.00, 1, 12)
     , (282298, 'Lenovo GF5703423',
        'Monitor 22" / Intel Core I7 (3.2 GHz) / RAM 3 GB / HDD 290 GB / Weight 2.6 kg / Webcam / HDMI / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 1720.00, 3, 9)
     , (282301, 'Samsung FNV974973',
        'Monitor 8" / RAM 1 GB / HDD 720 GB / Blue / Weight 220 g / WiFi / Webcam / 3G / Bluetooth',
        '/media/7461626c6574.jpg', 2900.00, 7, 22)
     , (282310, 'PocketBook MSJ90141267',
        'Monitor 8" / RAM 2 GB / HDD 190 GB / Silver / Weight 220 g / HDMI / WiFi / Bluetooth',
        '/media/7461626c6574.jpg', 920.00, 7, 17)
     , (282318, 'Nokia DQO3187',
        'Monitor diagonal 5.0" / Camera: 3.0Mp / RAM: 1 Gb / Orange / 1500 mA/h / Weight 480 g / USB / 3G / WiFi',
        '/media/736d61727470686f6e65.jpg', 1290.00, 5, 25)
     , (282324, 'Apple TF55189726',
        'Memory 12 Gb / Weight 26 g / Blue / MP3 / AMV / FM receiver / AVI / Bluetooth / Dictophone / WMA / USB / SD slot / MPEG-4 / WAV',
        '/media/6d70332d706c61796572.jpg', 1230.00, 2, 15)
     , (282325, 'Fly ME886427',
        'Monitor diagonal 6.0" / Camera: 3.2Mp / RAM: 1 Gb / Silver / 1800 mA/h / Weight 720 g / 3G / FM receiver / USB / 2 Sim cards / WiFi',
        '/media/736d61727470686f6e65.jpg', 480.00, 5, 7)
     , (282328, 'FiiO CMK012445',
        'Memory 20 Gb / Weight 80 g / Silver / MP3 / WAV / WMA / AMV / Dictophone / SD slot / Bluetooth / MPEG-4 / AVI / OGG / FM receiver',
        '/media/6d70332d706c61796572.jpg', 2770.00, 2, 2)
     , (282332, 'Sony CE3450', 'Memory 12 Gb / Weight 56 g / Orange / MP3 / MPEG-4 / Dictophone / AVI / AMV',
        '/media/6d70332d706c61796572.jpg', 1970.00, 2, 8)
     , (282341, 'EvroMedia ENP2953122',
        'Monitor diagonal 9" / Matrix type: E lnk Carta / Resolution: 1600x1200 / Memory 10 GB / Weight 195 g',
        '/media/652d626f6f6b.jpg', 2110.00, 1, 12)
     , (282351, 'LG EF248310',
        'Monitor diagonal 3.8" / Camera: 3.0Mp / RAM: 512 Mb / White / 1900 mA/h / Weight 320 g / 3G / Bluetooth / 2 Sim cards / Dictophone / USB / FM receiver',
        '/media/736d61727470686f6e65.jpg', 1550.00, 5, 21)
     , (282353, 'Samsung MO4294',
        'Monitor diagonal 2.8" / Camera: 1.8Mp / RAM 64 Mb / 1300 mA/h / Silver / Weight 160 g / Dictophone / USB / Bluetooth',
        '/media/70686f6e65.jpg', 560.00, 4, 22)
     , (282360, 'FixiTime LH7156476',
        'Monitor diagonal 1.2" / RAM: 256 Mb / White / 1100 mA/h / Weight 140 g / Bluetooth / GPS / USB',
        '/media/736d6172747761746368.jpg', 2450.00, 6, 16)
     , (282367, 'LG ETB0255',
        'Monitor diagonal 4.4" / Camera: 3.2Mp / RAM: 4 Gb / Silver / 1500 mA/h / Weight 360 g / FM receiver / Dictophone / USB',
        '/media/736d61727470686f6e65.jpg', 2060.00, 5, 21)
     , (282371, 'PocketBook BP8245',
        'Monitor diagonal 10" / Matrix type: E lnk / Resolution: 800x600 / Memory 4 GB / Weight 200 g',
        '/media/652d626f6f6b.jpg', 420.00, 1, 17)
     , (282376, 'Samsung MH65122',
        'Monitor diagonal 3.8" / Camera: 2.2Mp / RAM: 512 Mb / Orange / 1300 mA/h / Weight 800 g / WiFi / USB / FM receiver / 3G / Bluetooth / GPS',
        '/media/736d61727470686f6e65.jpg', 2470.00, 5, 22)
     , (282383, 'Nokia IUR07143',
        'Monitor diagonal 3.8" / Camera: 3.0Mp / RAM: 4 Gb / White / 1100 mA/h / Weight 520 g / WiFi / 3G / USB / GPS',
        '/media/736d61727470686f6e65.jpg', 2230.00, 5, 25)
     , (282393, 'Fly RN15374582',
        'Monitor diagonal 4.4" / Camera: 2.2Mp / RAM: 4 Gb / White / 2000 mA/h / Weight 680 g / Bluetooth / GPS / FM receiver',
        '/media/736d61727470686f6e65.jpg', 1330.00, 5, 7)
     , (282403, 'Philips RDH80823590',
        'Monitor diagonal 2.6" / Camera: 2.2Mp / RAM 32 Mb / 1000 mA/h / Blue / Weight 180 g / Bluetooth / 2 Sim cards / Dictophone',
        '/media/70686f6e65.jpg', 1840.00, 4, 18)
     , (282413, 'Lenovo NPN65625',
        'Monitor 11" / Intel Core I3 (1.8 GHz) / RAM 2 GB / HDD 580 GB / Weight 3.2 kg / Webcam / DVD+/-RW / Intel HD Graphics / Bluetooth / WiFi / LAN / USB',
        '/media/6e6f7465626f6f6b.jpg', 800.00, 3, 9)
     , (282414, 'PocketBook OPD0654627',
        'Monitor 7" / RAM 1 GB / HDD 570 GB / Blue / Weight 220 g / Bluetooth / WiFi / USB / Webcam',
        '/media/7461626c6574.jpg', 880.00, 7, 17)
     , (282418, 'Sony KBB3565', 'Monitor 8" / RAM 2 GB / HDD 430 GB / Silver / Weight 140 g / 3G / Bluetooth / WiFi',
        '/media/7461626c6574.jpg', 2550.00, 7, 8)
     , (282426, 'Sony ONV64662703',
        'Monitor diagonal 5.6" / Camera: 2.2Mp / RAM: 512 Mb / Black / 1100 mA/h / Weight 680 g / USB / 3G / GPS',
        '/media/736d61727470686f6e65.jpg', 260.00, 5, 8)
     , (282432, 'Jeka BO20475', 'Memory 4 Gb / Weight 71 g / Blue / MP3 / USB / AVI / AMV',
        '/media/6d70332d706c61796572.jpg', 1450.00, 2, 6)
     , (282441, 'Prestigio QVD8610',
        'Monitor diagonal 2.2" / Camera: 2.6Mp / RAM 16 Mb / 1700 mA/h / White / Weight 400 g / 2 Sim cards / Dictophone / Bluetooth',
        '/media/70686f6e65.jpg', 450.00, 4, 10)
     , (282451, 'Amazon IQS12901977',
        'Monitor diagonal 8" / Matrix type: E lnk / Resolution: 1600x1200 / Memory 11 GB / Weight 195 g',
        '/media/652d626f6f6b.jpg', 2210.00, 1, 23)
     , (282455, 'Acer VQM085403',
        'Monitor 19" / Intel Core I3 (2.6 GHz) / RAM 6 GB / HDD 690 GB / Weight 6.4 kg / WiFi / DVD+/-RW / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 1650.00, 3, 14)
     , (282465, 'Dell HSP10434',
        'Monitor 7" / RAM 1 GB / HDD 90 GB / Black / Weight 260 g / Bluetooth / Webcam / 3G / WiFi / USB',
        '/media/7461626c6574.jpg', 1390.00, 7, 1)
     , (282474, 'Apple TG7750',
        'Monitor 20" / Intel Core I7 (2.4 GHz) / RAM 9 GB / HDD 190 GB / Weight 6.6 kg / Intel HD Graphics / USB / LAN',
        '/media/6e6f7465626f6f6b.jpg', 2240.00, 3, 15)
     , (282479, 'Apple KSE096584', 'Memory 4 Gb / Weight 47 g / Orange / MP3 / AMV / FM receiver / WAV',
        '/media/6d70332d706c61796572.jpg', 1200.00, 2, 15)
     , (282489, 'PocketBook TT84173',
        'Monitor diagonal 7" / Matrix type: E lnk / Resolution: 1600x1200 / Memory 5 GB / Weight 170 g',
        '/media/652d626f6f6b.jpg', 2250.00, 1, 17)
     , (282494, 'Amazon KT2071',
        'Monitor diagonal 8" / Matrix type: E lnk Carta / Resolution: 800x600 / Memory 12 GB / Weight 185 g',
        '/media/652d626f6f6b.jpg', 1350.00, 1, 23)
     , (282499, 'LG MV257328',
        'Monitor diagonal 4.4" / Camera: 3.2Mp / RAM: 4 Gb / Orange / 1100 mA/h / Weight 800 g / USB / GPS / WiFi',
        '/media/736d61727470686f6e65.jpg', 840.00, 5, 21)
     , (282507, 'Huawei SB50284',
        'Monitor diagonal 5.0" / Camera: 3.0Mp / RAM: 2 Gb / Black / 2000 mA/h / Weight 600 g / WiFi / GPS / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 1250.00, 5, 24)
     , (282513, 'Prestigio OT3720182',
        'Monitor diagonal 5.0" / Camera: 4.0Mp / RAM: 2 Gb / Orange / 1400 mA/h / Weight 480 g / Bluetooth / Dictophone / 2 Sim cards / FM receiver / GPS / USB',
        '/media/736d61727470686f6e65.jpg', 430.00, 5, 10)
     , (282520, 'Lenovo KJM398725',
        'Monitor 14" / Intel Core I3 (2.6 GHz) / RAM 12 GB / HDD 630 GB / Weight 3.8 kg / DVD+/-RW / WiFi / USB',
        '/media/6e6f7465626f6f6b.jpg', 780.00, 3, 9)
     , (282522, 'Dell EAU1552823',
        'Monitor 19" / Intel Core I5 (2.2 GHz) / RAM 5 GB / HDD 530 GB / Weight 3.4 kg / Intel HD Graphics / Bluetooth / LAN',
        '/media/6e6f7465626f6f6b.jpg', 1640.00, 3, 1)
     , (282529, 'Dell LKK23263', 'Monitor 7" / RAM 3 GB / HDD 240 GB / Blue / Weight 140 g / Bluetooth / GPS / HDMI',
        '/media/7461626c6574.jpg', 1030.00, 7, 1)
     , (282536, 'Dell NIQ6215',
        'Monitor 10" / RAM 3 GB / HDD 430 GB / Orange / Weight 180 g / Bluetooth / HDMI / 3G / GPS',
        '/media/7461626c6574.jpg', 2190.00, 7, 1)
     , (282538, 'LG FTH8730',
        'Monitor diagonal 2.6" / Camera: 1.8Mp / RAM 48 Mb / 1400 mA/h / Silver / Weight 240 g / Bluetooth / Dictophone / 2 Sim cards',
        '/media/70686f6e65.jpg', 1310.00, 4, 21)
     , (282548, 'HTC MF841777',
        'Monitor diagonal 5.0" / Camera: 3.2Mp / RAM: 1 Gb / Blue / 1300 mA/h / Weight 560 g / Dictophone / USB / 3G',
        '/media/736d61727470686f6e65.jpg', 1150.00, 5, 19)
     , (282553, 'AirOn RSM31300',
        'Monitor diagonal 1.7" / RAM: 1 Gb / White / 1000 mA/h / Weight 180 g / Bluetooth / GPS / USB',
        '/media/736d6172747761746368.jpg', 890.00, 6, 11)
     , (282560, 'Lenovo DL69385',
        'Monitor 10" / RAM 2 GB / HDD 610 GB / White / Weight 300 g / Webcam / USB / WiFi / 3G',
        '/media/7461626c6574.jpg', 1420.00, 7, 9)
     , (282570, 'Philips UHR67701058',
        'Monitor diagonal 2.2" / Camera: 2.2Mp / RAM 16 Mb / 1700 mA/h / White / Weight 140 g / SD / USB / 2 Sim cards',
        '/media/70686f6e65.jpg', 880.00, 4, 18)
     , (282575, 'EvroMedia IRH041008',
        'Monitor diagonal 9" / Matrix type: E lnk Pearl / Resolution: 1024x758 / Memory 10 GB / Weight 170 g',
        '/media/652d626f6f6b.jpg', 1670.00, 1, 12)
     , (282585, 'Sony OL12760215', 'Memory 8 Gb / Weight 35 g / Black / MP3 / USB / WMA / Dictophone',
        '/media/6d70332d706c61796572.jpg', 1400.00, 2, 8)
     , (282590, 'Samsung SN88323',
        'Monitor 10" / RAM 3 GB / HDD 670 GB / Blue / Weight 180 g / Webcam / USB / HDMI / Bluetooth',
        '/media/7461626c6574.jpg', 2230.00, 7, 22)
     , (282594, 'Amazon HEH1571',
        'Monitor diagonal 6" / Matrix type: E lnk / Resolution: 1024x758 / Memory 7 GB / Weight 190 g',
        '/media/652d626f6f6b.jpg', 610.00, 1, 23)
     , (282601, 'LG CH95351472',
        'Monitor diagonal 6.0" / Camera: 4.0Mp / RAM: 2 Gb / Orange / 1900 mA/h / Weight 680 g / 2 Sim cards / Bluetooth / 3G',
        '/media/736d61727470686f6e65.jpg', 1050.00, 5, 21)
     , (282608, 'Amazon JSA9467139',
        'Monitor diagonal 11" / Matrix type: E lnk Carta / Resolution: 800x600 / Memory 9 GB / Weight 195 g',
        '/media/652d626f6f6b.jpg', 2330.00, 1, 23)
     , (282610, 'EvroMedia BJK66294034',
        'Monitor diagonal 11" / Matrix type: E lnk / Resolution: 1200x800 / Memory 12 GB / Weight 185 g',
        '/media/652d626f6f6b.jpg', 1310.00, 1, 12)
     , (282620, 'Samsung PBT0916', 'Monitor 10" / RAM 1 GB / HDD 380 GB / White / Weight 180 g / Webcam / WiFi / GPS',
        '/media/7461626c6574.jpg', 1580.00, 7, 22)
     , (282630, 'Samsung ON695321',
        'Monitor 8" / RAM 3 GB / HDD 220 GB / Silver / Weight 60 g / HDMI / 3G / Webcam / Bluetooth / WiFi / USB',
        '/media/7461626c6574.jpg', 2200.00, 7, 22)
     , (282639, 'Apple SOH8736',
        'Monitor diagonal 4.4" / Camera: 3.2Mp / RAM: 4 Gb / Silver / 1400 mA/h / Weight 800 g / WiFi / Dictophone / USB',
        '/media/736d61727470686f6e65.jpg', 1440.00, 5, 15)
     , (282642, 'Sony KGF2887784',
        'Memory 16 Gb / Weight 71 g / Black / MP3 / Bluetooth / FM receiver / Dictophone / MPEG-4 / WAV / SD slot / WMA / OGG / AVI',
        '/media/6d70332d706c61796572.jpg', 310.00, 2, 8)
     , (282648, 'Lenovo HK8668891',
        'Monitor diagonal 6.0" / Camera: 3.2Mp / RAM: 2 Gb / Silver / 1700 mA/h / Weight 800 g / WiFi / FM receiver / GPS / USB',
        '/media/736d61727470686f6e65.jpg', 2360.00, 5, 9)
     , (282655, 'Lenovo MK6412',
        'Monitor 21" / Intel Core I7 (2.2 GHz) / RAM 4 GB / HDD 90 GB / Weight 6.2 kg / HDMI / DVD+/-RW / LAN',
        '/media/6e6f7465626f6f6b.jpg', 2150.00, 3, 9)
     , (282660, 'Prestigio PVG667380',
        'Monitor diagonal 3.2" / Camera: 2.2Mp / RAM: 2 Gb / Orange / 1400 mA/h / Weight 520 g / 3G / FM receiver / USB',
        '/media/736d61727470686f6e65.jpg', 1020.00, 5, 10)
     , (282670, 'Dell DI38153799',
        'Monitor 20" / Intel Core I3 (2.6 GHz) / RAM 9 GB / HDD 340 GB / Weight 4.0 kg / DVD+/-RW / HDMI / WiFi',
        '/media/6e6f7465626f6f6b.jpg', 260.00, 3, 1)
     , (282675, 'Asus AJ8441', 'Monitor 8" / RAM 1 GB / HDD 740 GB / Orange / Weight 300 g / 3G / Webcam / WiFi',
        '/media/7461626c6574.jpg', 400.00, 7, 13)
     , (282683, 'AirOn GO057075',
        'Monitor diagonal 1.5" / RAM: 1 Gb / Blue / 1700 mA/h / Weight 60 g / GPS / Bluetooth / USB',
        '/media/736d6172747761746368.jpg', 1690.00, 6, 11)
     , (282685, 'Apple CC23031302',
        'Monitor diagonal 1.5" / RAM: 512 Mb / White / 1900 mA/h / Weight 260 g / Bluetooth / GPS / Dictophone',
        '/media/736d6172747761746368.jpg', 910.00, 6, 15)
     , (282695, 'Jeka PF44470827', 'Memory 12 Gb / Weight 50 g / Black / MP3 / AVI / USB / AMV',
        '/media/6d70332d706c61796572.jpg', 340.00, 2, 6)
     , (282699, 'EvroMedia SEF998458',
        'Monitor diagonal 9" / Matrix type: E lnk Pearl / Resolution: 1600x1200 / Memory 10 GB / Weight 200 g',
        '/media/652d626f6f6b.jpg', 590.00, 1, 12)
     , (282707, 'LG HPE9631',
        'Monitor diagonal 5.0" / Camera: 4.0Mp / RAM: 1 Gb / Orange / 1700 mA/h / Weight 440 g / Bluetooth / USB / Dictophone / 2 Sim cards / GPS / WiFi',
        '/media/736d61727470686f6e65.jpg', 1150.00, 5, 21)
     , (282717, 'Samsung VP71677143',
        'Monitor 10" / RAM 2 GB / HDD 270 GB / Blue / Weight 220 g / GPS / WiFi / 3G / Webcam',
        '/media/7461626c6574.jpg', 2740.00, 7, 22)
     , (282719, 'PocketBook FU61813',
        'Monitor diagonal 11" / Matrix type: E lnk / Resolution: 1200x800 / Memory 5 GB / Weight 170 g',
        '/media/652d626f6f6b.jpg', 2700.00, 1, 17)
     , (282722, 'Prestigio MAR6101',
        'Monitor 10" / RAM 2 GB / HDD 260 GB / Silver / Weight 300 g / Bluetooth / 3G / WiFi',
        '/media/7461626c6574.jpg', 2970.00, 7, 10)
     , (282729, 'Gigabyte EF16194',
        'Monitor diagonal 2.0" / Camera: 2.6Mp / RAM 16 Mb / 2000 mA/h / White / Weight 360 g / Bluetooth / USB / 2 Sim cards',
        '/media/70686f6e65.jpg', 1010.00, 4, 4)
     , (282732, 'Prestigio QUB48808966',
        'Monitor diagonal 3.2" / Camera: 4.0Mp / RAM: 4 Gb / Silver / 1600 mA/h / Weight 760 g / FM receiver / 2 Sim cards / GPS / USB',
        '/media/736d61727470686f6e65.jpg', 440.00, 5, 10)
     , (282739, 'Prestigio VV60350269',
        'Monitor diagonal 4.4" / Camera: 4.0Mp / RAM: 1 Gb / Blue / 1400 mA/h / Weight 360 g / Dictophone / 3G / Bluetooth / GPS / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 380.00, 5, 10)
     , (282749, 'EvroMedia ARC7414800',
        'Monitor diagonal 9" / Matrix type: E lnk Carta / Resolution: 800x600 / Memory 12 GB / Weight 155 g',
        '/media/652d626f6f6b.jpg', 2000.00, 1, 12)
     , (282750, 'Apple EIP9454',
        'Monitor 14" / Intel Core I3 (2.2 GHz) / RAM 13 GB / HDD 700 GB / Weight 2.6 kg / HDMI / LAN / Intel HD Graphics',
        '/media/6e6f7465626f6f6b.jpg', 1710.00, 3, 15)
     , (282760, 'Lenovo OT4781704',
        'Monitor 7" / RAM 2 GB / HDD 120 GB / Orange / Weight 140 g / 3G / WiFi / HDMI / GPS / USB / Bluetooth',
        '/media/7461626c6574.jpg', 2070.00, 7, 9)
     , (282761, 'Prestigio CFR23701893',
        'Monitor diagonal 5.6" / Camera: 3.2Mp / RAM: 512 Mb / Black / 1400 mA/h / Weight 600 g / 3G / GPS / Dictophone / FM receiver / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 40.00, 5, 10)
     , (282764, 'LG AS80504661',
        'Monitor diagonal 3.8" / Camera: 3.2Mp / RAM: 4 Gb / Blue / 1200 mA/h / Weight 600 g / 3G / FM receiver / Dictophone / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 1320.00, 5, 21)
     , (282771, 'Apple CV163299', 'Monitor 7" / RAM 1 GB / HDD 630 GB / White / Weight 180 g / Webcam / USB / 3G',
        '/media/7461626c6574.jpg', 740.00, 7, 15)
     , (282777, 'Samsung HQP0225',
        'Monitor diagonal 2.2" / Camera: 2.6Mp / RAM 48 Mb / 1400 mA/h / Black / Weight 260 g / 2 Sim cards / SD / Dictophone',
        '/media/70686f6e65.jpg', 590.00, 4, 22)
     , (282783, 'Fly RF9259903',
        'Monitor diagonal 3.2" / Camera: 3.0Mp / RAM: 2 Gb / Black / 1900 mA/h / Weight 720 g / 2 Sim cards / 3G / USB / Dictophone / FM receiver / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 1120.00, 5, 7)
     , (282792, 'LG GEJ6547',
        'Monitor diagonal 6.0" / Camera: 4.0Mp / RAM: 1 Gb / Orange / 1600 mA/h / Weight 440 g / FM receiver / Dictophone / 2 Sim cards / WiFi / GPS / USB / Bluetooth',
        '/media/736d61727470686f6e65.jpg', 2350.00, 5, 21)
     , (282799, 'PocketBook PA59193',
        'Monitor diagonal 11" / Matrix type: E lnk Carta / Resolution: 800x600 / Memory 12 GB / Weight 155 g',
        '/media/652d626f6f6b.jpg', 2690.00, 1, 17)
     , (282804, 'PocketBook TEN25384',
        'Monitor diagonal 7" / Matrix type: E lnk Pearl / Resolution: 1600x1200 / Memory 12 GB / Weight 190 g',
        '/media/652d626f6f6b.jpg', 1460.00, 1, 17)
     , (282813, 'Lenovo BHS8925',
        'Monitor 15" / Intel Core I5 (2.0 GHz) / RAM 2 GB / HDD 260 GB / Weight 6.2 kg / DVD+/-RW / USB / Webcam / Bluetooth',
        '/media/6e6f7465626f6f6b.jpg', 1290.00, 3, 9)
     , (282816, 'Prestigio BSO104134',
        'Monitor diagonal 5.0" / Camera: 4.0Mp / RAM: 4 Gb / White / 1200 mA/h / Weight 600 g / WiFi / GPS / 2 Sim cards / Dictophone / USB / 3G',
        '/media/736d61727470686f6e65.jpg', 2630.00, 5, 10)
     , (282817, 'AirOn HBT86901713',
        'Monitor diagonal 1.3" / RAM: 1 Gb / Blue / 1200 mA/h / Weight 260 g / WiFi / Dictophone / Bluetooth',
        '/media/736d6172747761746368.jpg', 1350.00, 6, 11)
     , (282825, 'Gigabyte BJ7868',
        'Monitor diagonal 2.2" / Camera: 2.6Mp / RAM 48 Mb / 1600 mA/h / Blue / Weight 120 g / USB / SD / Bluetooth / Dictophone',
        '/media/70686f6e65.jpg', 1300.00, 4, 4)
     , (282832, 'PocketBook PIK8465',
        'Monitor diagonal 8" / Matrix type: E lnk / Resolution: 800x600 / Memory 7 GB / Weight 185 g',
        '/media/652d626f6f6b.jpg', 1090.00, 1, 17)
     , (282842, 'FiiO OC8287',
        'Memory 20 Gb / Weight 77 g / White / MP3 / MPEG-4 / USB / AMV / SD slot / Bluetooth / AVI',
        '/media/6d70332d706c61796572.jpg', 2830.00, 2, 2)
     , (282846, 'EvroMedia FJE4949',
        'Monitor diagonal 6" / Matrix type: E lnk Pearl / Resolution: 800x600 / Memory 5 GB / Weight 165 g',
        '/media/652d626f6f6b.jpg', 920.00, 1, 12)
     , (282853, 'Transcend UH8396490',
        'Memory 8 Gb / Weight 41 g / Blue / MP3 / WAV / AMV / Bluetooth / SD slot / AVI / USB / Dictophone / FM receiver / MPEG-4',
        '/media/6d70332d706c61796572.jpg', 980.00, 2, 5)
     , (282863, 'Philips UPE27784',
        'Monitor diagonal 1.8" / Camera: 2.2Mp / RAM 16 Mb / 1900 mA/h / Blue / Weight 340 g / USB / Bluetooth / 2 Sim cards',
        '/media/70686f6e65.jpg', 1590.00, 4, 18)
     , (282872, 'Transcend ON87094', 'Memory 20 Gb / Weight 68 g / Orange / MP3 / SD slot / WAV / AMV / Bluetooth',
        '/media/6d70332d706c61796572.jpg', 1620.00, 2, 5)
     , (282875, 'Lenovo RLV52847',
        'Monitor diagonal 6.0" / Camera: 4.0Mp / RAM: 4 Gb / Blue / 1500 mA/h / Weight 760 g / USB / FM receiver / Dictophone',
        '/media/736d61727470686f6e65.jpg', 2200.00, 5, 9)
     , (282881, 'Fly KU48740',
        'Monitor diagonal 5.6" / Camera: 3.2Mp / RAM: 4 Gb / Orange / 2000 mA/h / Weight 440 g / FM receiver / USB / Dictophone / GPS',
        '/media/736d61727470686f6e65.jpg', 1110.00, 5, 7)
     , (282884, 'Lenovo GK889445',
        'Monitor diagonal 5.0" / Camera: 4.0Mp / RAM: 1 Gb / Orange / 1800 mA/h / Weight 360 g / Bluetooth / FM receiver / GPS / WiFi / 3G / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 2900.00, 5, 9)
     , (282885, 'Jeka LP162270', 'Memory 20 Gb / Weight 53 g / Black / MP3 / FM receiver / OGG / USB / AVI',
        '/media/6d70332d706c61796572.jpg', 1580.00, 2, 6)
     , (282892, 'Lenovo HR02581',
        'Monitor 23" / Intel Core I7 (2.0 GHz) / RAM 10 GB / HDD 90 GB / Weight 5.8 kg / HDMI / LAN / Bluetooth / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 1030.00, 3, 9)
     , (282897, 'Prestigio TG6661', 'Monitor 9" / RAM 3 GB / HDD 230 GB / Orange / Weight 260 g / GPS / WiFi / 3G',
        '/media/7461626c6574.jpg', 470.00, 7, 10)
     , (282898, 'Apple LMS65384902', 'Monitor 10" / RAM 3 GB / HDD 710 GB / White / Weight 100 g / 3G / WiFi / Webcam',
        '/media/7461626c6574.jpg', 1840.00, 7, 15)
     , (282901, 'Samsung EG174988', 'Monitor 9" / RAM 3 GB / HDD 570 GB / Silver / Weight 300 g / Webcam / USB / HDMI',
        '/media/7461626c6574.jpg', 1730.00, 7, 22)
     , (282910, 'Philips CE1678546',
        'Monitor diagonal 2.2" / Camera: 2.2Mp / RAM 48 Mb / 1100 mA/h / Blue / Weight 300 g / Dictophone / USB / 2 Sim cards',
        '/media/70686f6e65.jpg', 2020.00, 4, 18)
     , (282918, 'Prestigio VG4017510', 'Monitor 10" / RAM 2 GB / HDD 290 GB / Silver / Weight 220 g / GPS / 3G / HDMI',
        '/media/7461626c6574.jpg', 1630.00, 7, 10)
     , (282925, 'Asus AO9551799',
        'Monitor 12" / Intel Core I7 (3.2 GHz) / RAM 7 GB / HDD 690 GB / Weight 3.0 kg / Bluetooth / WiFi / Webcam',
        '/media/6e6f7465626f6f6b.jpg', 1140.00, 3, 13)
     , (282934, 'Apple MV96870907',
        'Monitor 17" / Intel Core I3 (2.0 GHz) / RAM 11 GB / HDD 150 GB / Weight 6.2 kg / LAN / Bluetooth / DVD+/-RW',
        '/media/6e6f7465626f6f6b.jpg', 1650.00, 3, 15)
     , (282941, 'Apple RG43675514',
        'Monitor diagonal 3.2" / Camera: 2.2Mp / RAM: 512 Mb / Silver / 1600 mA/h / Weight 680 g / 2 Sim cards / FM receiver / Dictophone',
        '/media/736d61727470686f6e65.jpg', 10.00, 5, 15)
     , (282949, 'Huawei VQA50242',
        'Monitor diagonal 5.6" / Camera: 3.0Mp / RAM: 4 Gb / Black / 1400 mA/h / Weight 720 g / Bluetooth / GPS / FM receiver',
        '/media/736d61727470686f6e65.jpg', 620.00, 5, 24)
     , (282958, 'Samsung VS4230722',
        'Monitor diagonal 5.0" / Camera: 3.2Mp / RAM: 1 Gb / Blue / 1300 mA/h / Weight 440 g / 3G / FM receiver / GPS / 2 Sim cards / Dictophone',
        '/media/736d61727470686f6e65.jpg', 1380.00, 5, 22)
     , (282966, 'Prestigio GM05085',
        'Monitor 10" / RAM 2 GB / HDD 750 GB / White / Weight 180 g / 3G / WiFi / Bluetooth', '/media/7461626c6574.jpg',
        1860.00, 7, 10)
     , (282975, 'Fly LPK6834377',
        'Monitor diagonal 6.0" / Camera: 4.0Mp / RAM: 1 Gb / Black / 1400 mA/h / Weight 520 g / Dictophone / FM receiver / WiFi / USB / GPS / 2 Sim cards',
        '/media/736d61727470686f6e65.jpg', 170.00, 5, 7)
     , (282985, 'Lenovo QF04176944', 'Monitor 10" / RAM 4 GB / HDD 630 GB / Blue / Weight 220 g / WiFi / HDMI / GPS',
        '/media/7461626c6574.jpg', 1930.00, 7, 9)
     , (282994, 'Sony NDV2421532',
        'Monitor diagonal 5.0" / Camera: 4.0Mp / RAM: 512 Mb / Silver / 1100 mA/h / Weight 440 g / Bluetooth / 2 Sim cards / FM receiver / USB / 3G / GPS / Dictophone',
        '/media/736d61727470686f6e65.jpg', 1820.00, 5, 8)
     , (282998, 'Apple GD67503344',
        'Monitor 8" / RAM 2 GB / HDD 600 GB / Silver / Weight 220 g / Bluetooth / 3G / Webcam / USB',
        '/media/7461626c6574.jpg', 630.00, 7, 15)
     , (282999, 'Nokia EBE232533',
        'Monitor diagonal 6.0" / Camera: 3.0Mp / RAM: 512 Mb / Black / 1200 mA/h / Weight 440 g / Dictophone / WiFi / 3G',
        '/media/736d61727470686f6e65.jpg', 540.00, 5, 25)
     , (283003, 'Prestigio BT58894',
        'Monitor diagonal 6.0" / Camera: 3.0Mp / RAM: 1 Gb / Black / 1800 mA/h / Weight 760 g / 2 Sim cards / GPS / Dictophone',
        '/media/736d61727470686f6e65.jpg', 1120.00, 5, 10)
     , (283008, 'Apple TO0288582', 'Monitor 8" / RAM 1 GB / HDD 640 GB / White / Weight 260 g / Bluetooth / USB / HDMI',
        '/media/7461626c6574.jpg', 2950.00, 7, 15)
     , (283012, 'LG EB02175742',
        'Monitor diagonal 1.8" / Camera: 2.2Mp / RAM 48 Mb / 1900 mA/h / Silver / Weight 340 g / Bluetooth / USB / Dictophone',
        '/media/70686f6e65.jpg', 820.00, 4, 21)
     , (283021, 'LG HBF029146',
        'Monitor diagonal 3.8" / Camera: 4.0Mp / RAM: 1 Gb / Silver / 1800 mA/h / Weight 320 g / 2 Sim cards / FM receiver / WiFi / 3G / Dictophone',
        '/media/736d61727470686f6e65.jpg', 1360.00, 5, 21)
     , (283025, 'Philips HEH4629',
        'Monitor diagonal 1.8" / Camera: 1Mp / RAM 32 Mb / 1000 mA/h / Blue / Weight 180 g / Bluetooth / 2 Sim cards / Dictophone',
        '/media/70686f6e65.jpg', 1840.00, 4, 18);